import os
import re
from collections import defaultdict

def get_stats(vocab):
    pairs = defaultdict(int)
    for word, freq in vocab.items():
        symbols = word.split()
        for i in range(len(symbols)-1):
            pairs[symbols[i], symbols[i+1]] += freq
    return pairs

def merge_vocab(pair, v_in):
    v_out = {}
    bigram = re.escape(' '.join(pair))
    p = re.compile(r'(?<!\S)' + bigram + r'(?!\S)')
    for word in v_in:
        w_out = p.sub(''.join(pair), word)
        v_out[w_out] = v_in[word]
    return v_out

def train_bpe(corpus_path, num_merges=50):
    print(f"Loading corpus from {corpus_path}...")
    
    # Fallback to hardcoded corpus if file not found
    corpus = [
        "quantum entanglement and coherence",
        "topological quantum field theory",
        "majorana fermions parity matrices",
        "tensor networks e8 lattice structure",
        "hamiltonian mechanics of vesper model",
        "parity inversion in physics geometry",
        "superposition of topological states"
    ]
    
    if os.path.exists(corpus_path):
        with open(corpus_path, 'r', encoding='utf-8') as f:
            corpus = f.read().splitlines()
    else:
        print("Using internal physics domain sample corpus.")
            
    # Initialize vocab with characters and end-of-word tokens
    vocab = defaultdict(int)
    for sentence in corpus:
        words = sentence.strip().lower().split()
        for word in words:
            # only keep a-z
            word = re.sub(r'[^a-z]', '', word)
            if word:
                spaced_word = " ".join(list(word)) + " </w>"
                vocab[spaced_word] += 1
                
    print(f"Initial tokens mapping complete. Running {num_merges} BPE merges...")
    
    merges = {}
    for i in range(num_merges):
        pairs = get_stats(vocab)
        if not pairs:
            break
        best = max(pairs, key=pairs.get)
        vocab = merge_vocab(best, vocab)
        merges[best] = i
        print(f"Merge {i+1:02d}: '{best[0]}' + '{best[1]}' -> '{best[0]}{best[1]}'")
        
    print("\n--- BPE Training Complete ---")
    print(f"Total merges generated: {len(merges)}")
    
    # Generate Kotlin vocab mapping
    print("\nGenerated Kotlin Vocab Mapping for VesperBpeTokenizer.kt:\n")
    
    base_chars = "abcdefghijklmnopqrstuvwxyz"
    
    print("val vocab = mutableMapOf(")
    print('    "<pad>" to 0, "<unk>" to 1, "<s>" to 2, "</s>" to 3,')
    
    idx = 4
    # Print base chars in chunks of 5
    chars_list = []
    for char in base_chars:
        chars_list.append(f'"{char}" to {idx}')
        idx += 1
        
    for i in range(0, len(chars_list), 6):
        print("    " + ", ".join(chars_list[i:i+6]) + ",")
        
    # Print merges
    merge_lines = []
    for pair in merges:
        merged_token = (pair[0] + pair[1]).replace("</w>", "")
        if merged_token not in [m.split('"')[1] for m in merge_lines]: # avoid duplicate substring keys if end-of-word stripped
            merge_lines.append(f'"{merged_token}" to {idx}')
            idx += 1
            
    for i in range(0, len(merge_lines), 4):
        print("    " + ", ".join(merge_lines[i:i+4]) + ",")
        
    print(f'    "_" to {idx} // space separator')
    print(")")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Train BPE for physics domain.")
    parser.add_argument("--corpus", type=str, default="corpus.txt", help="Path to text corpus.")
    parser.add_argument("--merges", type=int, default=30, help="Number of BPE merges to perform.")
    args = parser.parse_args()
    
    train_bpe(args.corpus, args.merges)
