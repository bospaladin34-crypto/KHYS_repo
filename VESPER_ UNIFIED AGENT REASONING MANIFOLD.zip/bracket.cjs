const fs = require('fs');
const content = fs.readFileSync('./app/src/main/java/com/example/ui/VesperDashboard.kt', 'utf8');
let open = 0, closed = 0;
for (let char of content) {
    if (char === '{') open++;
    else if (char === '}') closed++;
}
console.log({ open, closed });
if (open > closed) {
    fs.appendFileSync('./app/src/main/java/com/example/ui/VesperDashboard.kt', '}\n'.repeat(open - closed));
    console.log("Appended", open - closed, "closing brackets");
}
