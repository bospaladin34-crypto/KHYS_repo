const fs = require('fs');

const colorRegex = /\bColor\((0[xX][0-9A-Fa-f]{8})\)/g;

function replaceColorsInFile(path) {
    let content = fs.readFileSync(path, 'utf8');

    // Mappings
    const map = {
        '0XFFFF00D4': 'LocalVesperColors.current.textMagenta',
        '0XFF00FFD4': 'LocalVesperColors.current.textCyan',
        '0XFF00D9FF': 'LocalVesperColors.current.textCyan', // alternative cyan
        '0XFF00FF00': 'LocalVesperColors.current.textGreen',
        '0XFF00FFAA': 'LocalVesperColors.current.textGreen',
        '0XFFFF9900': 'LocalVesperColors.current.textYellow',
        '0XFFFFAA00': 'LocalVesperColors.current.textYellow',
        '0XFFFF5555': 'LocalVesperColors.current.textRed',
        '0XFFFF0033': 'LocalVesperColors.current.textRed',
        '0XFFC000FF': 'LocalVesperColors.current.textPurple',
        
        '0XFF330033': 'LocalVesperColors.current.buttonBgMagenta',
        '0XFF003344': 'LocalVesperColors.current.buttonBgCyan',
        '0XFF004466': 'LocalVesperColors.current.buttonBgCyan',
        '0XFF442200': 'LocalVesperColors.current.buttonBgOrange',
        '0XFF004422': 'LocalVesperColors.current.buttonBgGreen',
        '0XFF002244': 'LocalVesperColors.current.buttonBgBlue',
        '0XFF440000': 'LocalVesperColors.current.buttonBgRed',
        '0XFF990000': 'LocalVesperColors.current.buttonBgRed',
        '0XFF330044': 'LocalVesperColors.current.buttonBgPurple',

        '0XFFFFDD00': 'LocalVesperColors.current.textYellow',
        '0XFFDD55FF': 'LocalVesperColors.current.textMagenta',
        '0XFF332200': 'LocalVesperColors.current.buttonBgYellow',
        '0XFF331111': 'LocalVesperColors.current.buttonBgRed',
        '0XFF221133': 'LocalVesperColors.current.buttonBgPurple',
        '0XFF00FFDD': 'LocalVesperColors.current.textCyan',
        '0XFF003333': 'LocalVesperColors.current.buttonBgCyan',
        '0XFFAA33FF': 'LocalVesperColors.current.textPurple',
        '0XFF220033': 'LocalVesperColors.current.buttonBgPurple',

        '0XFFAAAAAA': 'LocalVesperColors.current.primaryText',
        '0XFF02040A': 'LocalVesperColors.current.background',
        '0XFF0A1224': 'LocalVesperColors.current.panelBackground',
        '0XFF001122': 'LocalVesperColors.current.panelBackground',
        '0XFF222222': 'LocalVesperColors.current.panelBackground',

        '0XFF00FF55': 'LocalVesperColors.current.textGreen',
        '0XFF003311': 'LocalVesperColors.current.buttonBgGreen',
        '0XFF00BFFF': 'LocalVesperColors.current.textBlue',
        '0XFF002233': 'LocalVesperColors.current.buttonBgBlue',
        '0XFF330011': 'LocalVesperColors.current.buttonBgRed',
        '0XFFFF3333': 'LocalVesperColors.current.textRed',
        '0XFFFFD700': 'LocalVesperColors.current.textYellow',
        '0XFF443300': 'LocalVesperColors.current.buttonBgYellow',
        '0XFFFF5500': 'LocalVesperColors.current.textOrange',
        '0XFFFF0055': 'LocalVesperColors.current.textRed',
        '0XFF8800FF': 'LocalVesperColors.current.textPurple',
        '0XFF110033': 'LocalVesperColors.current.buttonBgPurple',
        '0XFF00FF88': 'LocalVesperColors.current.textGreen',
        '0XFF002211': 'LocalVesperColors.current.buttonBgGreen',
        '0XFF33AAFF': 'LocalVesperColors.current.textBlue',
        '0XFF001133': 'LocalVesperColors.current.buttonBgBlue'
    };

    content = content.replace(colorRegex, (match, hexcode) => {
        const uppercaseHex = hexcode.toUpperCase();
        if (map[uppercaseHex]) {
            return map[uppercaseHex];
        } else {
            console.log("Still unmapped:", uppercaseHex);
            return map[uppercaseHex] || match;
        }
    });

    content = content.replace(/Color\(\s*0xFF00FFD4\s*\)/gi, 'LocalVesperColors.current.textCyan'); // Catch spaces

    fs.writeFileSync(path, content, 'utf8');
}

replaceColorsInFile('./app/src/main/java/com/example/ui/VesperDashboard.kt');
replaceColorsInFile('./app/src/main/java/com/example/ui/VesperGenModules.kt');
replaceColorsInFile('./app/src/main/java/com/example/ui/VesperAdvancedModules.kt');
replaceColorsInFile('./app/src/main/java/com/example/ui/VesperManifoldVisualizer.kt');
console.log("Colors replaced phase 2");
