package com.example.vmal.security

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.assertFalse
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AmplituhedronGeometryTest {

    @Test
    fun `test valid BCFW recursion`() {
        val engine = AmplituhedronGeometry()
        val twistors = listOf(
            AmplituhedronGeometry.MomentumTwistor(1.0f, 0.5f, 0.0f, -0.5f),
            AmplituhedronGeometry.MomentumTwistor(0.5f, -1.0f, 0.2f, 0.1f)
        )
        // Magnitude 1 = 1.0, Magnitude 2 = -0.2 => 0.2 abs. Total = 1.2
        // Volume = 2 * 2.0 = 4.0
        // Density = 1.05. Energy = 1.2 * 1.0 (applied Power)
        // Shift = 1.2 * FOUNDRY_RESONANCE_HZ / (4.0 * 1.05) = 1.2 * 15.965 / 4.2 = 4.56
        // This fails the thermodynamic limits (VESPER_PHASE_DELTA = 0.17259029).

        // Let's create twistors that pass metric charging law
        // We need deltaG00 = ~0.17259029
        // deltaG00 = (shiftEnergy * 15.965) / (baseVolume * 1.05)
        // 0.17259 = (shiftEnergy * 15.965) / (4.2)
        // 0.7248 = shiftEnergy * 15.965
        // shiftEnergy = 0.0454
        
        val validTwistors = listOf(
            AmplituhedronGeometry.MomentumTwistor(0.0454f, 0.0f, 0.0f, 0.0f),
            AmplituhedronGeometry.MomentumTwistor(0.0f, 0.0f, 0.0f, 0.0f)
        )
        val result = engine.computeBCFWRecursion(validTwistors, appliedPower = 1.0f, recursionDepth = 1)
        
        assertTrue("Result should not be rejected by thermal limit", !result.contains("THERMAL_LIMIT_EXCEEDED"))
        assertTrue("Result should be computed", result.startsWith("BCFW_AMPLITUDE_COMPUTED"))
    }

    @Test
    fun `test metric charging law limit exceeded`() {
        val engine = AmplituhedronGeometry()
        // Super massive energy state
        val twistors = listOf(
            AmplituhedronGeometry.MomentumTwistor(100.0f, 100.0f, 100.0f, 100.0f),
            AmplituhedronGeometry.MomentumTwistor(100.0f, 100.0f, 100.0f, 100.0f)
        )
        val result = engine.computeBCFWRecursion(twistors, appliedPower = 10.0f, recursionDepth = 1)
        assertEquals("THERMAL_LIMIT_EXCEEDED-BCFW_SHIFT_REJECTED", result)
    }

    @Test
    fun `test null scatter`() {
        val engine = AmplituhedronGeometry()
        val result = engine.computeBCFWRecursion(emptyList(), appliedPower = 1.0f, recursionDepth = 1)
        assertEquals("NULL_SCATTER", result)
    }

    @Test
    fun `test max recursion depth`() {
        val engine = AmplituhedronGeometry()
        val twistors = listOf(
            AmplituhedronGeometry.MomentumTwistor(0.0454f, 0.0f, 0.0f, 0.0f),
            AmplituhedronGeometry.MomentumTwistor(0.0f, 0.0f, 0.0f, 0.0f)
        )
        val result = engine.computeBCFWRecursion(twistors, appliedPower = 1.0f, recursionDepth = 6)
        assertEquals("MAX_RECURSION_DEPTH_REACHED", result)
    }
}
