package com.example.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface LatentAnchorDao {
    @Query("SELECT * FROM latent_anchors ORDER BY timestamp DESC")
    fun getAllAnchors(): Flow<List<LatentAnchorEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnchor(anchor: LatentAnchorEntity)

    @Query("DELETE FROM latent_anchors WHERE id = :id")
    suspend fun deleteAnchorById(id: Int)
    
    @Query("DELETE FROM latent_anchors")
    suspend fun clearAnchors()
}
