package com.example.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "model_weights")
data class ModelWeightEntity(
    @PrimaryKey val id: String,
    val equationContext: String,
    val trainedEpochs: Int,
    val finalLoss: Float,
    val parameterBlob: String, // Represents local weights (e.g., base64 or serialized json)
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "computation_sessions")
data class ComputationSessionEntity(
    @PrimaryKey val id: String,
    val command: String,
    val targetEquation: String,
    val iterations: Int,
    val resultOutput: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "terminal_sessions")
data class TerminalSessionEntity(
    @PrimaryKey val id: String,
    val title: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "doi_provenance")
data class DoiProvenanceEntity(
    @PrimaryKey val url: String,
    val doi: String?,
    val platform: String,
    val citationMetadata: String?,
    val associatedProjectIdentifier: String? = "VESPER_CORE",
    val associatedConcepts: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "pinn_parameters")
data class PinnParameterEntity(
    @PrimaryKey val parameterName: String,
    val parameterValue: Double,
    val units: String?,
    val timestamp: Long = System.currentTimeMillis()
)
