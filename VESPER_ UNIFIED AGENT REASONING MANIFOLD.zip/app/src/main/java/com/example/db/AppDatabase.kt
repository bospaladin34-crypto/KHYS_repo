package com.example.db

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [ModelWeightEntity::class, TerminalSessionEntity::class, PinnParameterEntity::class, LatentAnchorEntity::class, GeometricStateEntity::class, ComputationSessionEntity::class, DoiProvenanceEntity::class], version = 7, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun modelWeightDao(): ModelWeightDao
    abstract fun computationSessionDao(): ComputationSessionDao
    abstract fun terminalSessionDao(): TerminalSessionDao
    abstract fun pinnParameterDao(): PinnParameterDao
    abstract fun latentAnchorDao(): LatentAnchorDao
    abstract fun geometricStateDao(): GeometricStateDao
    abstract fun doiProvenanceDao(): DoiProvenanceDao
}
