package com.example.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ModelWeightDao {
    @Query("SELECT * FROM model_weights ORDER BY timestamp DESC")
    fun getAllWeights(): Flow<List<ModelWeightEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveWeights(weight: ModelWeightEntity)

    @Query("DELETE FROM model_weights WHERE id = :id")
    suspend fun deleteWeights(id: String)
}

@Dao
interface ComputationSessionDao {
    @Query("SELECT * FROM computation_sessions ORDER BY timestamp DESC")
    fun getAllComputations(): Flow<List<ComputationSessionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveComputation(computation: ComputationSessionEntity)

    @Query("DELETE FROM computation_sessions WHERE id = :id")
    suspend fun deleteComputation(id: String)
}

@Dao
interface TerminalSessionDao {
    @Query("SELECT * FROM terminal_sessions ORDER BY timestamp DESC")
    fun getAllSessions(): Flow<List<TerminalSessionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSession(session: TerminalSessionEntity)
}

@Dao
interface DoiProvenanceDao {
    @Query("SELECT * FROM doi_provenance ORDER BY timestamp DESC")
    fun getAllProvenance(): Flow<List<DoiProvenanceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProvenance(entity: DoiProvenanceEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(entities: List<DoiProvenanceEntity>)

    @Query("DELETE FROM doi_provenance WHERE url = :url")
    suspend fun deleteProvenance(url: String)
}

@Dao
interface PinnParameterDao {
    @Query("SELECT * FROM pinn_parameters")
    fun getAllParameters(): Flow<List<PinnParameterEntity>>

    @Query("SELECT * FROM pinn_parameters WHERE parameterName = :name LIMIT 1")
    suspend fun getParameterByName(name: String): PinnParameterEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertParameter(parameter: PinnParameterEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertParameters(parameters: List<PinnParameterEntity>)
}
