package com.example.db

import kotlinx.coroutines.flow.Flow
import com.example.pinn.VesperInvariants

class PinnRepository(
    private val modelWeightDao: ModelWeightDao,
    private val computationSessionDao: ComputationSessionDao,
    private val terminalSessionDao: TerminalSessionDao,
    private val pinnParameterDao: PinnParameterDao,
    private val latentAnchorDao: LatentAnchorDao,
    private val geometricStateDao: GeometricStateDao,
    private val doiProvenanceDao: DoiProvenanceDao
) {
    val allWeights: Flow<List<ModelWeightEntity>> = modelWeightDao.getAllWeights()
    val allComputations: Flow<List<ComputationSessionEntity>> = computationSessionDao.getAllComputations()
    val allSessions: Flow<List<TerminalSessionEntity>> = terminalSessionDao.getAllSessions()
    val allParameters: Flow<List<PinnParameterEntity>> = pinnParameterDao.getAllParameters()
    val allAnchors: Flow<List<LatentAnchorEntity>> = latentAnchorDao.getAllAnchors()
    val allDoiProvenance: Flow<List<DoiProvenanceEntity>> = doiProvenanceDao.getAllProvenance()
    
    val geometricState: Flow<GeometricStateEntity?> = geometricStateDao.getState()

    suspend fun saveGeometricState(state: GeometricStateEntity) = geometricStateDao.saveState(state)

    suspend fun saveAnchor(anchor: LatentAnchorEntity) = latentAnchorDao.insertAnchor(anchor)
    suspend fun clearAnchors() = latentAnchorDao.clearAnchors()

    suspend fun saveWeight(weight: ModelWeightEntity) = modelWeightDao.saveWeights(weight)
    suspend fun deleteWeight(id: String) = modelWeightDao.deleteWeights(id)
    suspend fun saveComputation(comp: ComputationSessionEntity) = computationSessionDao.saveComputation(comp)
    suspend fun deleteComputation(id: String) = computationSessionDao.deleteComputation(id)
    suspend fun saveSession(session: TerminalSessionEntity) = terminalSessionDao.saveSession(session)
    
    suspend fun saveDoiProvenance(entity: DoiProvenanceEntity) = doiProvenanceDao.insertProvenance(entity)
    suspend fun saveAllDoiProvenance(entities: List<DoiProvenanceEntity>) = doiProvenanceDao.insertAll(entities)
    suspend fun deleteDoiProvenance(url: String) = doiProvenanceDao.deleteProvenance(url)
    
    suspend fun getParameter(name: String): PinnParameterEntity? {
        return pinnParameterDao.getParameterByName(name)
    }

    suspend fun updateParameter(name: String, value: Double, units: String? = null) {
        val entity = PinnParameterEntity(
            parameterName = name,
            parameterValue = value,
            units = units
        )
        pinnParameterDao.insertParameter(entity)
    }

    suspend fun saveDefaultInvariants() {
        val defaultParams = listOf(
            PinnParameterEntity("f0", VesperInvariants.F0_HZ, "Hz"),
            PinnParameterEntity("nu_p", VesperInvariants.NU_P, "dimensionless"),
            PinnParameterEntity("phi", VesperInvariants.GOLDEN_RATIO_PHI, "dimensionless"),
            PinnParameterEntity("c_eff", VesperInvariants.C_EFF_M_S, "m/s"),
            PinnParameterEntity("m_phi", VesperInvariants.PHASON_MASS_KG, "kg"),
            PinnParameterEntity("ghost_logic_energy", VesperInvariants.GHOST_LOGIC_ENERGY_J, "J"),
            PinnParameterEntity("info_capacity", VesperInvariants.INFO_CAPACITY_BITS, "bits"),
            PinnParameterEntity("alpha_mev", VesperInvariants.ALPHA_PARTICLE_ENERGY_MEV, "MeV"),
            PinnParameterEntity("aperiodic_slope_chi", VesperInvariants.APERIODIC_SLOPE_CHI, "dimensionless"),
            PinnParameterEntity("majorana_parity_p", VesperInvariants.MAJORANA_PARITY_P.toDouble(), "dimensionless"),
            PinnParameterEntity("cef_min_coherence", VesperInvariants.CEF_MIN_COHERENCE, "dimensionless")
        )
        pinnParameterDao.insertParameters(defaultParams)
    }
}
