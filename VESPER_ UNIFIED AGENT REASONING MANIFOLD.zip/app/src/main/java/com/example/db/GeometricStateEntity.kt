package com.example.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "geometric_state")
data class GeometricStateEntity(
    @PrimaryKey val id: Int = 1,
    val showP3: Boolean = true,
    val showE8: Boolean = true,
    val showPolytope: Boolean = true,
    val lastRotationAngle: Float = 0f,
    val lastGlobalPhase: Float = 0f
)
