package com.example.db

object DoiParser {

    /**
     * Parses a DOI URL and returns a DoiProvenanceEntity.
     */
    fun parseUrl(url: String, metadata: String? = null): DoiProvenanceEntity {
        val platform = when {
            url.contains("orcid.org") -> "ORCID"
            url.contains("osf.io") -> "OSF"
            url.contains("zenodo") -> "Zenodo"
            url.contains("tdcommons.org") -> "TDCommons"
            else -> "Unknown"
        }

        val doi = when {
            url.contains("doi.org/") -> url.substringAfter("doi.org/")
            url.contains("zenodo.") -> "10.5281/zenodo." + url.substringAfter("zenodo.")
            else -> null // Some URLs may not contain an explicit DOI
        }

        return DoiProvenanceEntity(
            url = url,
            doi = doi,
            platform = platform,
            citationMetadata = metadata,
            timestamp = System.currentTimeMillis()
        )
    }
}
