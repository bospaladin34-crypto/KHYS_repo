package com.example.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "latent_anchors")
data class LatentAnchorEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val x: Float,
    val y: Float,
    val note: String,
    val timestamp: Long = System.currentTimeMillis()
)
