package com.example.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface GeometricStateDao {
    @Query("SELECT * FROM geometric_state WHERE id = 1 LIMIT 1")
    fun getState(): Flow<GeometricStateEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveState(state: GeometricStateEntity)
}
