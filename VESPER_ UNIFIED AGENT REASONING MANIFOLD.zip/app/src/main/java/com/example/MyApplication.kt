package com.example

import android.app.Application
import androidx.room.Room
import com.example.db.AppDatabase
import com.example.db.PinnRepository
import kotlinx.coroutines.launch

class MyApplication : Application() {
    lateinit var database: AppDatabase
        private set
        
    lateinit var repository: PinnRepository
        private set

    override fun onCreate() {
        super.onCreate()
        database = Room.databaseBuilder(
            this,
            AppDatabase::class.java,
            "vesper_database"
        ).fallbackToDestructiveMigration(dropAllTables = true).build()
        repository = PinnRepository(database.modelWeightDao(), database.computationSessionDao(), database.terminalSessionDao(), database.pinnParameterDao(), database.latentAnchorDao(), database.geometricStateDao(), database.doiProvenanceDao())

        // Prepopulate DOIs
        kotlinx.coroutines.GlobalScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val dois = listOf(
                "https://orcid.org/0009-0008-7546-6952",
                "https://osf.io/svb36/",
                "https://doi.org/10.17605/OSF.IO/5F6XV",
                "https://doi.org/10.17605/OSF.IO/RGYZQ",
                "https://doi.org/10.5281/zenodo.20315546",
                "https://doi.org/10.5281/zenodo.20263400",
                "https://doi.org/10.5281/zenodo.19874412",
                "https://www.tdcommons.org/dpubs_series/10026/"
            )
            val doiFetcher = com.example.service.DoiMetadataFetcher(repository)
            doiFetcher.fetchMetadataForUrls(dois)
            
            // Map concepts extracted from "Vesper-Sovereign Topological Monism and 10/1 Reset"
            val conceptMap = mapOf(
                "https://orcid.org/0009-0008-7546-6952" to "15.965Hz Sync, Baseline Homeostasis",
                "https://osf.io/svb36/" to "Aperiodic Scaling, Golden Ratio via Pi, KAM Theorem",
                "https://doi.org/10.17605/OSF.IO/5F6XV" to "Lunar Recession Geometric Requirement",
                "https://doi.org/10.17605/OSF.IO/RGYZQ" to "Tensegrity, Planetary Dynamic Tension Network",
                "https://doi.org/10.5281/zenodo.20315546" to "10/1 Reset Phase Transition",
                "https://doi.org/10.5281/zenodo.20263400" to "Vesper-Sovereign Topological Monism",
                "https://doi.org/10.5281/zenodo.19874412" to "The Gregorian Gap, Temporal Friction",
                "https://www.tdcommons.org/dpubs_series/10026/" to "Artificial Manifold Calculation, Topological Snap-Back"
            )
            doiFetcher.mapConceptsToExistingDois(conceptMap)
            
            launch {
                doiFetcher.startPeriodicRefresh()
            }
            repository.saveDefaultInvariants()
        }
    }
}
