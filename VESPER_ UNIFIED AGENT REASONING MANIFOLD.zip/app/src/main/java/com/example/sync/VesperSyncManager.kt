package com.example.sync

import com.example.vmal.security.AmplituhedronGeometry
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlin.random.Random

/**
 * Centralized state-management service synchronizing Vesper HUD data streams,
 * Amplituhedron engine execution, and the performance dashboard telemetry.
 */
object VesperSyncManager {

    // Amplituhedron Engine Instance
    private val amplituhedronEngine = AmplituhedronGeometry()

    // BCFW Execution State
    private val _lastBcfwResult = MutableStateFlow<String>("IDLE")
    val lastBcfwResult: StateFlow<String> = _lastBcfwResult.asStateFlow()

    private val _bcfwExecutionTimeMs = MutableStateFlow<Long>(0L)
    val bcfwExecutionTimeMs: StateFlow<Long> = _bcfwExecutionTimeMs.asStateFlow()

    // Dashboard Telemetry streams
    private val _cpuUsage = MutableStateFlow<Float>(0f)
    val cpuUsage: StateFlow<Float> = _cpuUsage.asStateFlow()

    private val _memoryUsageMB = MutableStateFlow<Long>(0L)
    val memoryUsageMB: StateFlow<Long> = _memoryUsageMB.asStateFlow()

    private val _syncActive = MutableStateFlow<Boolean>(false)
    val syncActive: StateFlow<Boolean> = _syncActive.asStateFlow()

    // Telemetry Coroutine Scope
    private val syncScope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Default + kotlinx.coroutines.SupervisorJob())

    init {
        // Background telemetry sync loop
        syncScope.launch {
            while (true) {
                if (_syncActive.value) {
                    val runtime = Runtime.getRuntime()
                    val usedMem = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)
                    _memoryUsageMB.value = usedMem
                    _cpuUsage.value = Random.nextFloat() * 100f // Simulated CPU
                }
                delay(1000)
            }
        }
    }

    fun setSyncActive(active: Boolean) {
        _syncActive.value = active
    }

    fun executeAmplituhedronCycle(depth: Int) {
        syncScope.launch {
            val startTime = System.currentTimeMillis()
            
            // Generate synthetic external twistors for the BCFW cycle
            val twistors = List(4) {
                AmplituhedronGeometry.MomentumTwistor(
                    z1 = Random.nextFloat(),
                    z2 = Random.nextFloat(),
                    z3 = Random.nextFloat(),
                    z4 = Random.nextFloat()
                )
            }
            
            val result = amplituhedronEngine.computeBCFWRecursion(
                externalTwistors = twistors,
                appliedPower = 1.0f,
                recursionDepth = depth
            )
            
            val endTime = System.currentTimeMillis()
            
            _lastBcfwResult.value = result
            _bcfwExecutionTimeMs.value = endTime - startTime
        }
    }
}
