package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.api.Content
import com.example.api.GenerateContentRequest
import com.example.api.Part
import com.example.api.RetrofitClient
import com.example.api.Tool
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import com.example.ui.NotificationManager

class PhysicsSearchViewModel : ViewModel() {
    private val _searchStatus = MutableStateFlow("Ready to search.")
    val searchStatus: StateFlow<String> = _searchStatus

    private val _searchResult = MutableStateFlow("")
    val searchResult: StateFlow<String> = _searchResult

    fun searchPhysicsConcept(query: String) {
        if (query.isBlank()) return

        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank()) {
            val errorMsg = "Error: GEMINI_API_KEY is missing. Please add it to the Secrets Panel."
            _searchStatus.value = errorMsg
            NotificationManager.emit(errorMsg)
            return
        }

        _searchStatus.value = "Searching Google Knowledge Graph..."
        _searchResult.value = ""

        viewModelScope.launch {
            try {
                // Formatting request utilizing Google Search Tool for accurate physics definitions.
                val request = GenerateContentRequest(
                    contents = listOf(
                        Content(parts = listOf(Part(text = "Please explain the following physics concept, give its definition, and its standard formula if applicable. Be concise and authoritative. Concept: $query")))
                    ),
                    tools = listOf(Tool(googleSearch = emptyMap()))
                )

                val response = RetrofitClient.service.generateContent(
                    model = "gemini-3.5-flash", 
                    apiKey = apiKey, 
                    request = request
                )
                
                val candidate = response.candidates?.firstOrNull()
                val textResponse = candidate?.content?.parts?.firstOrNull()?.text
                
                if (textResponse != null) {
                    _searchResult.value = textResponse
                    _searchStatus.value = "Search complete. Ground truth loaded."
                } else {
                    _searchResult.value = "No results found or unrecognized format."
                    _searchStatus.value = "Search failed."
                    NotificationManager.emit("Search API returned no legible response.")
                }
            } catch (e: Exception) {
                Log.e("PhysicsSearch", "Error searching", e)
                val errorMessage = "Network/API Connectivity Error: ${e.message}"
                _searchStatus.value = errorMessage
                _searchResult.value = ""
                NotificationManager.emit(errorMessage)
            }
        }
    }
}
