package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.vmal.FOUNDRY_RESONANCE_HZ
import com.example.vmal.TensorState
import com.example.vmal.TensorStateRenderer
import com.example.vmal.evolveLagrangian
import kotlin.math.sin

@Composable
fun VmalPlaygroundScreen(modifier: Modifier = Modifier) {
    // Instantiate a TensorState to demonstrate the Mathematical Abstraction Layer
    val testTensor = remember {
        TensorState(
            initialState = 0f,
            mass = 1.2f,
            volume = 0.8f,
            density = 1.5f
        )
    }

    var iteration by remember { mutableIntStateOf(0) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "VMAL STATE RENDERER",
            color = Color(0xFF00FFCC),
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp
        )

        Text(
            text = "Interactive visualization of the Virtual Mathematical Abstraction Layer.",
            color = Color.White.copy(alpha = 0.7f),
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp
        )

        // The specific requested State Renderer
        TensorStateRenderer(
            tensorState = testTensor,
            label = "PRIMARY TOPOLOGY STATE"
        )
        
        // Control Panel
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Button(
                onClick = {
                    iteration++
                    // Apply a transformation adhering to the metric charging law
                    // Ψ (wave function), Power (P_a), dt
                    testTensor.applyTransformation(
                        waveFunctionPsi = sin(iteration.toFloat()) * 5f,
                        appliedPower = 10f,
                        dt = 1f / FOUNDRY_RESONANCE_HZ
                    ) { current ->
                        current + 0.1f
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00FFCC).copy(alpha = 0.2f)),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text("APPLY TRANSFORMATION", color = Color(0xFF00FFCC), fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            }
            
            Button(
                onClick = {
                    // Drive to high entropy quickly to see coherence drop
                    iteration++
                    testTensor.applyTransformation(
                        waveFunctionPsi = 50f,
                        appliedPower = 100f,
                        dt = 1f
                    ) { current ->
                        current - 0.5f // Destabilize
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.2f)),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text("INDUCE ENTROPY", color = Color.Red, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Button(
                onClick = {
                    iteration++
                    // Apply a Lagrangian physics evolution
                    testTensor.evolveLagrangian(
                        velocity = { 2.5f * sin(iteration.toFloat()) },
                        potentialEnergy = { 10f }, // Constant potential well for this demo
                        dt = 1f / FOUNDRY_RESONANCE_HZ
                    ) { current ->
                        current + 0.05f
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00BFFF).copy(alpha = 0.2f)),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text("EVOLVE (LAGRANGIAN)", color = Color(0xFF00BFFF), fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            }
        }
    }
}
