package com.example.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SemanticGeometryVisualizer(modifier: Modifier = Modifier) {
    var phrase by remember { mutableStateOf("consciousness is a pattern that recognizes itself") }
    var displayedPhrase by remember { mutableStateOf("consciousness is a pattern that recognizes itself") }
    
    val keyboardController = LocalSoftwareKeyboardController.current

    val infiniteTransition = rememberInfiniteTransition()
    val globalRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(20000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )
    
    // Hash based metrics
    val hash = displayedPhrase.hashCode()
    val seed = hash.toLong()
    val random = java.util.Random(seed)
    
    val shapesCount = displayedPhrase.length.coerceIn(5, 25)
    val S_val = kotlin.math.abs(hash % 1000)
    val T_val = kotlin.math.abs((hash / 100) % 1000)
    val E8_val = kotlin.math.abs((hash / 10000) % 100)
    
    Box(modifier = modifier.fillMaxSize().background(Color(0xFF0A0A0E))) {
        
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            
            val radius = size.minDimension / 4f
            
            for (i in 0 until shapesCount) {
                // Generate a shape
                val sides = random.nextInt(4) + 3 // 3, 4, 5, 6
                val angleIdx = (i.toFloat() / shapesCount) * 360f + globalRotation

                val colorH = (angleIdx % 360f)
                val color = Color.hsv(hue = colorH, saturation = 0.8f, value = 0.9f, alpha = 200f / 255f)
                
                val shapeRadius = radius * (0.6f + random.nextFloat() * 0.4f)
                val innerRadius = shapeRadius * 0.7f
                
                // Determine placement based on phrase length: ring or abstract layout
                
                val centerOffset = if (displayedPhrase.length < 15) {
                    // Circular ring style
                    val rad = Math.toRadians(angleIdx.toDouble())
                    Offset(
                        (cx + cos(rad) * radius).toFloat(),
                        (cy + sin(rad) * radius).toFloat()
                    )
                } else {
                    // Abstract Layout (chevron/line style)
                    // We arrange them in a zig zag line
                    val xOffset = cx + (i - shapesCount/2) * (shapeRadius * 1.5f)
                    val varianceY = if (i % 2 == 0) shapeRadius * 0.5f else -shapeRadius * 0.5f
                    Offset(
                        xOffset,
                        cy + varianceY
                    )
                }
                
                val rotationOffset = random.nextFloat() * 360f + globalRotation * 0.5f

                val path = Path()
                for (v in 0 until sides) {
                    val vRad = Math.toRadians((v.toFloat() / sides * 360f + rotationOffset).toDouble())
                    val vx = centerOffset.x + cos(vRad).toFloat() * innerRadius
                    val vy = centerOffset.y + sin(vRad).toFloat() * innerRadius
                    if (v == 0) path.moveTo(vx, vy) else path.lineTo(vx, vy)
                }
                path.close()
                
                // Draw filled shape and stroke
                drawPath(path = path, color = color)
                drawPath(path = path, color = Color.Black, style = Stroke(width = 4f))
            }
        }
        
        // Center text container
        val isCircle = displayedPhrase.length < 15
        
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .then(
                    if (isCircle) Modifier.clip(CircleShape).background(Color(0xFF111115).copy(alpha = 0.9f))
                    else Modifier.background(Color(0xFF111115).copy(alpha = 0.6f))
                )
                .padding(if (isCircle) 32.dp else 16.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                BasicTextField(
                    value = phrase,
                    onValueChange = { phrase = it },
                    textStyle = TextStyle(
                        color = Color.White,
                        fontSize = 18.sp,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.Center
                    ),
                    cursorBrush = SolidColor(Color.White),
                    keyboardOptions = KeyboardOptions.Default.copy(
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            displayedPhrase = phrase
                            keyboardController?.hide()
                        }
                    ),
                    modifier = Modifier.widthIn(min = 100.dp, max = 300.dp)
                )
                
                Spacer(modifier = Modifier.height(6.dp))
                
                Text(
                    text = "S$S_val • T$T_val • E8:$E8_val • v𝜙=0.17259029",
                    color = Color.Gray,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
        
        Text(
            text = "v𝜙=0.17259029 VESPER-01",
            color = Color.DarkGray,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 32.dp)
        )
    }
}
