package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OmniboxUniversal(
    modifier: Modifier = Modifier,
    onCommandSubmit: (String) -> Unit,
    recentOutputs: List<String> = emptyList(),
    isExpanded: Boolean,
    onExpandedChange: (Boolean) -> Unit
) {
    var inputText by remember { mutableStateOf("") }
    val focusRequester = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    var isFocused by remember { mutableStateOf(false) }

    val availableCommands = listOf(
        "/search" to "Ground responses with web context",
        "/fast" to "Use flash-lite model",
        "/think" to "High analytical mode",
        "/parse" to "Compile native UI diff eq",
        "/rust" to "Rust fast-path processing",
        "/weights" to "List local PINN weights",
        "/save_session" to "Persist terminal session",
        "/history" to "View saved results",
        "/sim" to "Launch background iterations",
        "/clear" to "Clear terminal output"
    )

    val filteredSuggestions = remember(inputText) {
        if (inputText.startsWith("/")) {
            availableCommands.filter { it.first.startsWith(inputText) }
        } else {
            emptyList()
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .shadow(
                elevation = if (isExpanded || isFocused) 16.dp else 0.dp,
                shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
            )
            .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            .background(Color(0xFF0A0C10).copy(alpha = 0.95f))
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF00FF00).copy(alpha = 0.5f), Color.Transparent)
                ),
                shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
            )
    ) {
        // Expand/Collapse Handle
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onExpandedChange(!isExpanded) }
                .padding(vertical = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isExpanded) Icons.Default.KeyboardArrowDown else Icons.Default.KeyboardArrowUp,
                contentDescription = if (isExpanded) "Collapse" else "Expand",
                tint = Color(0xFF00FF00).copy(alpha = 0.5f),
                modifier = Modifier.size(20.dp)
            )
        }

        // Expanded Area (History & Suggestions)
        AnimatedVisibility(
            visible = isExpanded || (isFocused && filteredSuggestions.isNotEmpty()),
            enter = expandVertically(animationSpec = tween(300)),
            exit = shrinkVertically(animationSpec = tween(300))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 250.dp)
            ) {
                if (isFocused && filteredSuggestions.isNotEmpty()) {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f, fill = false)
                            .background(Color(0xFF161A22))
                    ) {
                        items(filteredSuggestions) { (cmd, desc) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        inputText = "$cmd "
                                        focusRequester.requestFocus()
                                    }
                                    .padding(horizontal = 16.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(cmd, color = Color(0xFF00FF00), fontFamily = FontFamily.Monospace, fontSize = 14.sp)
                                Text(desc, color = Color.Gray, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                            }
                            HorizontalDivider(color = Color.DarkGray.copy(alpha = 0.3f))
                        }
                    }
                } else if (isExpanded && recentOutputs.isNotEmpty()) {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f, fill = false)
                            .padding(horizontal = 16.dp),
                        reverseLayout = true
                    ) {
                        items(recentOutputs.asReversed()) { output ->
                            Text(
                                text = output,
                                color = if (output.startsWith(">")) Color(0xFF00FF00) else Color(0xFFAAAAAA),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }

        // Input Field Area
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "VESPER>",
                color = Color(0xFF00FF00),
                fontFamily = FontFamily.Monospace,
                fontSize = 14.sp,
                modifier = Modifier.padding(end = 8.dp)
            )
            
            TextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier
                    .weight(1f)
                    .focusRequester(focusRequester)
                    .onFocusChanged { isFocused = it.isFocused },
                textStyle = LocalTextStyle.current.copy(
                    color = Color.White,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 14.sp
                ),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    cursorColor = Color(0xFF00FF00)
                ),
                placeholder = {
                    Text(
                        "Command or prompt...",
                        color = Color.DarkGray,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 14.sp
                    )
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(
                    onSend = {
                        if (inputText.isNotBlank()) {
                            onCommandSubmit(inputText)
                            inputText = ""
                            focusManager.clearFocus()
                        }
                    }
                ),
                singleLine = true
            )

            IconButton(
                onClick = {
                    if (inputText.isNotBlank()) {
                        onCommandSubmit(inputText)
                        inputText = ""
                        focusManager.clearFocus()
                    }
                }
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Submit",
                    tint = if (inputText.isNotBlank()) Color(0xFF00FF00) else Color.DarkGray
                )
            }
        }
    }
}
