package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pinn.LullianEngine
import kotlinx.coroutines.delay

@Composable
fun LullianEngineVisualizer(modifier: Modifier = Modifier) {
    var globalPhase by remember { mutableStateOf(0f) }
    
    // Track Quantum Walk State
    var walkState by remember { 
        mutableStateOf(LullianEngine.QuantumWalkState(0, emptyList())) 
    }
    
    var projectedRoots by remember { mutableStateOf(emptyList<Pair<Float, Float>>()) }
    val animationsEnabled = LocalAnimationsEnabled.current
    
    LaunchedEffect(animationsEnabled) {
        if (!animationsEnabled) return@LaunchedEffect
        while (true) {
            val currentPhase = globalPhase + 0.01f
            var nextWalkState = walkState
            
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
                // Advance walk every 5 frames
                if ((currentPhase * 100).toInt() % 5 == 0) {
                    nextWalkState = LullianEngine.stepQuantumWalk(nextWalkState)
                }
                
                val newProjectedRoots = LullianEngine.e8Roots.map { root ->
                    LullianEngine.projectTo2D(root, currentPhase, scale = 120f)
                }
                
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    globalPhase = currentPhase
                    walkState = nextWalkState
                    projectedRoots = newProjectedRoots
                }
            }
            
            delay(33L) // ~30 FPS frame rate locked
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(16.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height / 2f

            // Draw Adinkra graph connectivity edges (Lattice Mesh Links)
            val edgeColor = Color(0xFF38bdf8).copy(alpha = 0.05f) // Very dim blue/cyan
            LullianEngine.adinkraEdges.forEach { edge ->
                val p1 = projectedRoots.getOrNull(edge.first)
                val p2 = projectedRoots.getOrNull(edge.second)
                if (p1 != null && p2 != null) {
                    drawLine(
                        color = edgeColor,
                        start = Offset(cx + p1.first, cy + p1.second),
                        end = Offset(cx + p2.first, cy + p2.second),
                        strokeWidth = 0.5f.dp.toPx()
                    )
                }
            }

            // Draw Lattice Mesh (all E8 Roots)
            projectedRoots.forEachIndexed { i, (x, y) ->
                // Highlight the active quantum walk node
                if (i == walkState.currentNodeIndex) {
                    drawCircle(
                        color = Color(0xFFa78bfa), // Bright purple
                        radius = 8.dp.toPx(),
                        center = Offset(cx + x, cy + y)
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 4.dp.toPx(),
                        center = Offset(cx + x, cy + y)
                    )
                } else if (walkState.history.contains(i)) {
                    // History trail
                    drawCircle(
                        color = Color(0xFFf472b6).copy(alpha = 0.6f), // Pink trail
                        radius = 3.dp.toPx(),
                        center = Offset(cx + x, cy + y)
                    )
                } else {
                    // Standard inactive roots
                    drawCircle(
                        color = Color(0xFF7dd3fc).copy(alpha = 0.3f), // Dim cyan
                        radius = 2.dp.toPx(),
                        center = Offset(cx + x, cy + y)
                    )
                }
            }
            
            // Draw Adinkra active node connectivity edges (Quantum Walk Potentials)
            val activeNeighbors = LullianEngine.getNeighbors(walkState.currentNodeIndex)
            val activeNode = projectedRoots.getOrNull(walkState.currentNodeIndex)
            if (activeNode != null) {
                val activeEdgeColor = Color(0xFFa78bfa).copy(alpha = 0.4f)
                activeNeighbors.forEach { neighborIdx ->
                    val neighborNode = projectedRoots.getOrNull(neighborIdx)
                    if (neighborNode != null) {
                        drawLine(
                            color = activeEdgeColor,
                            start = Offset(cx + activeNode.first, cy + activeNode.second),
                            end = Offset(cx + neighborNode.first, cy + neighborNode.second),
                            strokeWidth = 1.dp.toPx()
                        )
                    }
                }
            }
            
            // Draw walk path lines
            val history = walkState.history
            if (history.isNotEmpty() && projectedRoots.isNotEmpty()) {
                val pathColor = Color(0xFFa78bfa).copy(alpha = 0.5f)
                var prevPoint = projectedRoots[history.first()]
                for (j in 1 until history.size) {
                    val currPoint = projectedRoots[history[j]]
                    drawLine(
                        color = pathColor,
                        start = Offset(cx + prevPoint.first, cy + prevPoint.second),
                        end = Offset(cx + currPoint.first, cy + currPoint.second),
                        strokeWidth = 2.dp.toPx()
                    )
                    prevPoint = currPoint
                }
                // Connect last history to current
                val currPoint = projectedRoots[walkState.currentNodeIndex]
                drawLine(
                    color = Color.White,
                    start = Offset(cx + prevPoint.first, cy + prevPoint.second),
                    end = Offset(cx + currPoint.first, cy + currPoint.second),
                    strokeWidth = 3.dp.toPx()
                )
            }
        }
        
        // HUD Overlay
        Text(
            text = "LULLIAN ENGINE: E8 240-ROOT QUANTUM WALK\nACTIVE NODE: ${walkState.currentNodeIndex}\nHISTORY TRAIL: ${walkState.history.size}",
            color = Color(0xFFa78bfa),
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(8.dp)
        )
    }
}
