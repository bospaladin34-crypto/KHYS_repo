package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.pinn.VesperInvariants
import kotlin.math.cos
import kotlin.math.sin
import com.example.ui.LocalAnimationsEnabled

@Composable
fun LiveTensorVisualizer(modifier: Modifier = Modifier) {
    var time by remember { mutableFloatStateOf(0f) }
    
    val animationsEnabled = LocalAnimationsEnabled.current

    LaunchedEffect(animationsEnabled) {
        if (!animationsEnabled) return@LaunchedEffect
        val startTime = withFrameMillis { it }
        while (true) {
            val frameTime = withFrameMillis { it }
            time = (frameTime - startTime) / 1000f
            kotlinx.coroutines.delay(33L) // 30 FPS cap
        }
    }

    Canvas(modifier = modifier.fillMaxWidth().height(150.dp)) {
        val width = size.width
        val height = size.height
        val centerY = height / 2f
        
        val path = Path()
        
        val f0 = VesperInvariants.F0_HZ.toFloat()
        val nuP = VesperInvariants.NU_P.toFloat()
        
        // Draw the field Phi and its modulation
        for (x in 0..width.toInt() step 5) {
            val t = time + (x / width) * 2f // spatial phase
            
            // Equation: Phi = nu_p * sin(2 * pi * f0 * t)
            val phi = sin(2 * Math.PI.toFloat() * (f0 / 10f) * t) // Scaled down freq for visibility
            val mod = 1f + nuP * cos(2 * Math.PI.toFloat() * (f0 / 10f) * t)
            
            val y = centerY - (phi * mod * 40f) // Scale amplitude
            
            if (x == 0) {
                path.moveTo(x.toFloat(), y)
            } else {
                path.lineTo(x.toFloat(), y)
            }
        }
        
        drawPath(
            path = path,
            color = Color.Cyan,
            style = Stroke(
                width = 3f,
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )
        
        // Draw the Dark Energy Coupled Curvature (secondary wave)
        val path2 = Path()
        for (x in 0..width.toInt() step 5) {
            val t = time - (x / width) * 1.5f
            val curve = cos(2 * Math.PI.toFloat() * (f0 / 15f) * t) * (1f - nuP)
            val y = centerY + (curve * 30f)
            
            if (x == 0) {
                path2.moveTo(x.toFloat(), y)
            } else {
                path2.lineTo(x.toFloat(), y)
            }
        }
        
        drawPath(
            path = path2,
            color = Color.Magenta,
            style = Stroke(
                width = 2f,
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )
    }
}
