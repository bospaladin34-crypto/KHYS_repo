package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pinn.ColorTheoryMapper
import com.example.pinn.LatentCoordinateSystem
import com.example.pinn.Polytope7777D
import kotlinx.coroutines.delay

import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.LatentMapViewModel
import com.example.GeometricStateViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.LocalAnimationsEnabled

@Composable
fun P3Visualizer(modifier: Modifier = Modifier, latentViewModel: LatentMapViewModel = viewModel(), geometricViewModel: GeometricStateViewModel = viewModel()) {
    val polytope = remember { Polytope7777D() }
    val projectionMatrix = remember { polytope.createProjectionMatrix() }
    var polytopeVertices by remember { mutableStateOf(emptyList<Pair<Float, Float>>()) }
    
    var e8Roots by remember { mutableStateOf(emptyList<Pair<Float, Float>>()) }
    var e7Roots by remember { mutableStateOf(emptyList<Pair<Float, Float>>()) }
    var e6Roots by remember { mutableStateOf(emptyList<Pair<Float, Float>>()) }
    var p3Points by remember { mutableStateOf(emptyList<Pair<Float, Float>>()) }
    
    val geometricState by geometricViewModel.state.collectAsStateWithLifecycle()
    
    var showPolytope by remember(geometricState) { mutableStateOf(geometricState?.showPolytope ?: true) }
    var showP3 by remember(geometricState) { mutableStateOf(geometricState?.showP3 ?: true) }
    var showE8 by remember(geometricState) { mutableStateOf(geometricState?.showE8 ?: true) }
    
    var rotationAngle by remember(geometricState) { mutableStateOf(geometricState?.lastRotationAngle ?: 0f) }

    var frameCount by remember { mutableStateOf(0) }
    
    val savedAnchors by latentViewModel.anchors.collectAsStateWithLifecycle()
    
    val animationsEnabled = LocalAnimationsEnabled.current

    LaunchedEffect(animationsEnabled) {
        if (!animationsEnabled) return@LaunchedEffect
        val rawVertices = polytope.generateBoundaryVertices(150)
        while (true) {
            val rotMatrix = Array(polytope.dimensions) { FloatArray(2) }
            val angleBase = rotationAngle
            
            // Move heavy calculations to background dispatcher to keep UI thread smooth
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
                for (d in 0 until polytope.dimensions) {
                    val angle = angleBase + (d * 0.005f)
                    rotMatrix[d][0] = projectionMatrix[d][0] * kotlin.math.cos(angle) - projectionMatrix[d][1] * kotlin.math.sin(angle)
                    rotMatrix[d][1] = projectionMatrix[d][0] * kotlin.math.sin(angle) + projectionMatrix[d][1] * kotlin.math.cos(angle)
                }
                
                try {
                    val newVertices = rawVertices.map { polytope.projectTo2D(it, rotMatrix) }
                    val newE8 = LatentCoordinateSystem.generateE8(scale = 180f, phaseShift = angleBase)
                    val newE7 = LatentCoordinateSystem.generateE7(scale = 130f, phaseShift = -angleBase * 1.5f)
                    val newE6 = LatentCoordinateSystem.generateE6(scale = 80f, phaseShift = angleBase * 2f)
                    val newP3 = LatentCoordinateSystem.generatePenroseP3Grid(scale = 40f, gridDensity = 4, phase = angleBase * 0.5f)
                    
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                        polytopeVertices = newVertices
                        e8Roots = newE8
                        e7Roots = newE7
                        e6Roots = newE6
                        p3Points = newP3
                    }
                } catch (e: Exception) {
                    // Safety catch
                }
            }

            rotationAngle += 0.02f
            frameCount++
            if (frameCount % 60 == 0) { // save every ~2 seconds
                geometricViewModel.saveState(showP3, showE8, showPolytope, rotationAngle, geometricState?.lastGlobalPhase ?: 0f)
            }
            delay(33L) // ~30 FPS frame rate locked
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF020409))
            .padding(16.dp)
    ) {
        Text(
            text = "GEOMETRIC LATENT SPACE COORD SYSTEM",
            color = Color(0xFFa78bfa),
            fontFamily = FontFamily.Monospace,
            fontSize = 16.sp,
            modifier = Modifier.padding(bottom = 2.dp)
        )
        Text(
            text = "Grassmannian Bounds / Lie Group Coxeter Map",
            color = Color(0xFF94a3b8),
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
            Checkbox(
                checked = showP3, 
                onCheckedChange = { showP3 = it },
                colors = CheckboxDefaults.colors(checkedColor = Color(0xFF9ca3af), checkmarkColor = Color.Black)
            )
            Text("Penrose P3 Lattices", color = Color(0xFF9ca3af), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            
            Spacer(Modifier.width(8.dp))
            Checkbox(
                checked = showE8, 
                onCheckedChange = { showE8 = it },
                colors = CheckboxDefaults.colors(checkedColor = Color(0xFFfde047), checkmarkColor = Color.Black)
            )
            Text("E6/E7/E8 Roots", color = Color(0xFFfde047), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            
            Spacer(Modifier.width(8.dp))
            Checkbox(
                checked = showPolytope, 
                onCheckedChange = { showPolytope = it },
                colors = CheckboxDefaults.colors(checkedColor = Color(0xFF7dd3fc), checkmarkColor = Color.Black)
            )
            Text("7777D Boundary", color = Color(0xFF7dd3fc), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            
            Spacer(Modifier.weight(1f))
            androidx.compose.material3.TextButton(onClick = { latentViewModel.clearAnchors() }) {
                Text("Clear Anchors", color = Color(0xFFef4444), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
        }
        
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color.Black)
        ) {
            Canvas(modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        val cx = size.width / 2f
                        val cy = size.height / 2f
                        // Store relative coordinate to the center
                        latentViewModel.addAnchor(offset.x - cx, offset.y - cy, "Anchor added at tap")
                    }
                }
            ) {
                val cx = size.width / 2f
                val cy = size.height / 2f
                
                // Draw Saved Anchors
                savedAnchors.forEach { anchor ->
                    drawCircle(
                        color = Color.White,
                        radius = 4.dp.toPx(),
                        center = Offset(cx + anchor.x, cy + anchor.y)
                    )
                    drawCircle(
                        color = Color(0xFFa78bfa).copy(alpha = 0.5f),
                        radius = 8.dp.toPx(),
                        center = Offset(cx + anchor.x, cy + anchor.y),
                        style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx())
                    )
                }

                // 1. Draw P3 Lattices
                if (showP3) {
                    p3Points.forEachIndexed { index, (x, y) ->
                        val t = index.toFloat() / p3Points.size
                        val p3Color = ColorTheoryMapper.mapValueToColor(t, ColorTheoryMapper.ColorScale.CYMATIC_SPECTRUM, alpha = 0.4f)
                        drawCircle(
                            color = p3Color,
                            radius = 1.5.dp.toPx(),
                            center = Offset(cx + x, cy + y)
                        )
                    }
                }

                // 2. Draw 7777D Polytope Bound Structure
                if (showPolytope) {
                    val scale = size.minDimension / 4f
                    val vertexOffsets = polytopeVertices.map { (x, y) -> Offset(cx + x * scale, cy + y * scale) }
                    
                    for (i in 0 until vertexOffsets.size step 2) {
                        if (i + 5 < vertexOffsets.size) {
                            val lineT = i.toFloat() / vertexOffsets.size
                            val lineColor = ColorTheoryMapper.mapValueToColor(lineT, ColorTheoryMapper.ColorScale.SHEAF_DENSITY, alpha = 0.15f)
                            drawLine(
                                color = lineColor,
                                start = vertexOffsets[i],
                                end = vertexOffsets[i+5],
                                strokeWidth = 1.dp.toPx()
                            )
                        }
                    }
                    vertexOffsets.forEachIndexed { index, it ->
                        val pointT = index.toFloat() / vertexOffsets.size
                        val pointColor = ColorTheoryMapper.mapValueToColor(pointT, ColorTheoryMapper.ColorScale.SHEAF_DENSITY, alpha = 0.4f)
                        drawCircle(
                            color = pointColor,
                            radius = 1.dp.toPx(),
                            center = it
                        )
                    }
                }

                // 3. Draw E6 / E7 / E8 Lie Roots overlaid on top
                if (showE8) {
                    e8Roots.forEachIndexed { i, (x, y) ->
                        val t = i.toFloat() / e8Roots.size
                        val rootColor = ColorTheoryMapper.mapValueToColor(t, ColorTheoryMapper.ColorScale.E8_ROOT_WEIGHT, alpha = 0.85f)
                        drawCircle(color = rootColor, radius = 2.5.dp.toPx(), center = Offset(cx + x, cy + y))
                    }
                    e7Roots.forEachIndexed { i, (x, y) ->
                        val t = i.toFloat() / e7Roots.size
                        val rootColor = ColorTheoryMapper.mapValueToColor(1f - t, ColorTheoryMapper.ColorScale.E8_ROOT_WEIGHT, alpha = 0.85f)
                        drawCircle(color = rootColor, radius = 3.dp.toPx(), center = Offset(cx + x, cy + y))
                    }
                    e6Roots.forEachIndexed { i, (x, y) ->
                        val t = (i.toFloat() / e6Roots.size + 0.5f) % 1f
                        val rootColor = ColorTheoryMapper.mapValueToColor(t, ColorTheoryMapper.ColorScale.E8_ROOT_WEIGHT, alpha = 0.85f)
                        drawCircle(color = rootColor, radius = 3.5.dp.toPx(), center = Offset(cx + x, cy + y))
                    }
                }
            }
        }
    }
}
