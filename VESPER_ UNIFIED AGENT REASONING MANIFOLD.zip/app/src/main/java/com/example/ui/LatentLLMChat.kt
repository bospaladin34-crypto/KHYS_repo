package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.border
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.Create
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class ArtifactType {
    NONE, CODE, EXECUTION_RESULT, CHART, LATTICE
}

data class LatentMessage(
    val text: String,
    val isUser: Boolean,
    val isArtifact: Boolean = false,
    val artifactContent: String? = null,
    val artifactType: ArtifactType = ArtifactType.NONE
)

@Composable
fun LatentLLMChat(modifier: Modifier = Modifier) {
    var inputText by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf<LatentMessage>()) }
    var isThinking by remember { mutableStateOf(false) }
    var showBraidIde by remember { mutableStateOf(false) }
    var currentVectorCode by remember { mutableStateOf("E8_LATENT: [0.000, 0.000, 0.000, 0.000]\nSEEKER: b0=1, b1=0, b2=0, Φ=1.618") }
    var isListening by remember { mutableStateOf(false) }
    var attachedImage by remember { mutableStateOf<String?>(null) }
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(inputText) {
        if (inputText.isEmpty()) {
            currentVectorCode = "E8_LATENT: [0.000, 0.000, 0.000, 0.000]\nSEEKER: b0=1, b1=0, b2=0, Φ=1.618"
        } else {
            val hash1 = (inputText.hashCode() % 10000).toFloat() / 100f
            val hash2 = (inputText.reversed().hashCode() % 10000).toFloat() / 100f
            val hash3 = kotlin.math.sin(hash1) * 15.965f
            val hash4 = kotlin.math.cos(hash2) * 0.17259f
            
            val params = com.example.pinn.parser.SemanticClusterMapper.mapIntentToParameters(inputText)
            
            val latentCode = "E8_LATENT: [%.3f, %.3f, %.3f, %.3f]".format(hash1, hash2, hash3, hash4)
            val seekerCode = "SEEKER: b0=${params.b0}, b1=${params.b1}, b2=${params.b2}, Φ=%.3f, Δ=%.4f".format(params.scalingConstant, params.phaseDelta)
            currentVectorCode = "$latentCode\n$seekerCode"
        }
    }

    val backgroundGradient = Brush.verticalGradient(
        colors = listOf(
            Color.White,
            Color(0xFFDCEBFE),
            Color(0xFFAFD1FE)
        )
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(backgroundGradient)
    ) {
        // Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Menu,
                contentDescription = "Menu",
                tint = Color.Black
            )
            
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = if (showBraidIde) "Vesper IDE" else "Latent Extractor",
                    color = Color.Black,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                )
                Icon(
                    imageVector = Icons.Default.ArrowDropDown,
                    contentDescription = "Dropdown",
                    tint = Color.Black
                )
            }
            
            Row {
                IconButton(onClick = { showBraidIde = !showBraidIde }) {
                    Icon(
                        imageVector = Icons.Default.Build,
                        contentDescription = "Toggle IDE",
                        tint = Color.Black
                    )
                }
                IconButton(onClick = { messages = emptyList() }) {
                    Icon(
                        imageVector = Icons.Outlined.Create,
                        contentDescription = "New Chat",
                        tint = Color.Black
                    )
                }
            }
        }

        if (showBraidIde) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                com.example.ui.BraidIDE()
            }
        } else {
            // Main Content Area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
            if (messages.isEmpty()) {
                // Empty state greeting
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = 60.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    GeminiSparkle()
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(
                        text = "Ask away,\nVesper-Sovereign\nOperator 01!",
                        color = Color.Black,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Normal,
                        textAlign = TextAlign.Center,
                        lineHeight = 40.sp,
                        fontFamily = FontFamily.SansSerif
                    )
                }
            } else {
                // Chat History
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    reverseLayout = false
                ) {
                    items(messages) { msg ->
                        ChatBubble(message = msg)
                    }
                    if (isThinking) {
                        item {
                            ChatBubble(message = LatentMessage("Mapping semantics to 7777-D Polytope...", isUser = false), isThinking = true)
                        }
                    }
                }
            }
            
            // HUD Overlay
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 16.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black.copy(alpha = 0.6f))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = currentVectorCode,
                    color = Color(0xFF00FF00),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        }

        // Bottom Input Area Handle
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
              Text("Use the unified Omnibox search bar below to navigate.", color = Color.Gray, fontSize = 12.sp)
        }
    }
}

@Composable
fun ChatBubble(message: LatentMessage, isThinking: Boolean = false) {
    val isUser = message.isUser
    val alignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
    val bgColor = if (isUser) Color(0xFFE8F1FF) else Color.Transparent
    val textColor = if (isThinking) Color.Gray else Color.Black

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        contentAlignment = alignment
    ) {
        if (!isUser) {
            Row(verticalAlignment = Alignment.Top) {
                Box(modifier = Modifier.padding(top = 4.dp, end = 12.dp)) {
                    GeminiSparkle(size = 24.dp)
                }
                Box(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .clip(RoundedCornerShape(16.dp))
                        .background(bgColor)
                        .padding(horizontal = 4.dp, vertical = 8.dp)
                ) {
                    Column {
                        Text(
                            text = message.text,
                            color = textColor,
                            fontSize = 16.sp,
                            fontFamily = FontFamily.SansSerif,
                            lineHeight = 24.sp
                        )
                            if (message.isArtifact) {
                                Spacer(modifier = Modifier.height(12.dp))
                                when (message.artifactType) {
                                    ArtifactType.CODE -> {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(Color(0xFF0D1117))
                                                .padding(16.dp)
                                        ) {
                                            Text(
                                                text = message.artifactContent ?: "",
                                                color = Color(0xFF00FF00),
                                                fontFamily = FontFamily.Monospace,
                                                fontSize = 12.sp,
                                                lineHeight = 16.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                    ArtifactType.EXECUTION_RESULT -> {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(Color(0xFF1B0505))
                                                .border(1.dp, Color.Red, RoundedCornerShape(8.dp))
                                                .padding(16.dp)
                                        ) {
                                            Text(
                                                text = message.artifactContent ?: "",
                                                color = Color(0xFFFF5555),
                                                fontFamily = FontFamily.Monospace,
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                    ArtifactType.CHART -> {
                                        Canvas(modifier = Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(8.dp)).background(Color.Black)) {
                                            val w = size.width
                                            val h = size.height
                                            val path = Path()
                                            path.moveTo(0f, h/2f)
                                            for(i in 0..100) {
                                                val x = (i/100f) * w
                                                val y = h/2f + kotlin.math.sin((i/100f) * Math.PI * 4) * (h/3f)
                                                path.lineTo(x, y.toFloat())
                                            }
                                            drawPath(path, color = Color.Cyan, style = androidx.compose.ui.graphics.drawscope.Stroke(2f))
                                        }
                                    }
                                    ArtifactType.LATTICE -> {
                                        Canvas(modifier = Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF0A0A0A))) {
                                            val w = size.width
                                            val h = size.height
                                            val cx = w/2f
                                            val cy = h/2f
                                            for(i in 0..8) {
                                                val angle = (i * Math.PI * 2) / 8
                                                val px = cx + kotlin.math.cos(angle) * (h/2.5f)
                                                val py = cy + kotlin.math.sin(angle) * (h/2.5f)
                                                drawLine(color = Color(0xFFFF00FF), start = androidx.compose.ui.geometry.Offset(cx, cy), end = androidx.compose.ui.geometry.Offset(px.toFloat(), py.toFloat()), strokeWidth = 2f)
                                                drawCircle(color = Color.Cyan, radius = 6f, center = androidx.compose.ui.geometry.Offset(px.toFloat(), py.toFloat()))
                                            }
                                            drawCircle(color = Color.White, radius = 10f, center = androidx.compose.ui.geometry.Offset(cx, cy))
                                        }
                                    }
                                    else -> {}
                                }
                            }
                    }
                }
            }
        } else {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(bgColor)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(
                    text = message.text,
                    color = textColor,
                    fontSize = 16.sp,
                    fontFamily = FontFamily.SansSerif
                )
            }
        }
    }
}

@Composable
fun GeminiSparkle(size: androidx.compose.ui.unit.Dp = 48.dp) {
    Canvas(modifier = Modifier.size(size)) {
        val width = size.toPx()
        val height = size.toPx()
        val path = Path().apply {
            moveTo(width / 2f, 0f)
            quadraticTo(width / 2f, height / 2f, width, height / 2f)
            quadraticTo(width / 2f, height / 2f, width / 2f, height)
            quadraticTo(width / 2f, height / 2f, 0f, height / 2f)
            quadraticTo(width / 2f, height / 2f, width / 2f, 0f)
            close()
        }
        drawPath(
            path = path,
            brush = Brush.linearGradient(
                colors = listOf(
                    Color(0xFF4285F4),
                    Color(0xFFEA4335),
                    Color(0xFFFBBC05),
                    Color(0xFF34A853)
                )
            )
        )
    }
}

fun generateLatentResponse(input: String): LatentMessage {
    val lower = input.lowercase()
    
    if (input.startsWith("[VISION]")) {
        val artifactContent = """
            [MULTIMODAL TOPOLOGY ANALYSIS]
            Input Frame: Acquired
            Semantic Extraction: Validating structural forms
            
            Detected Vesper Constraints:
            - Foundational geometry satisfies 0.17259029 Phase Delta
            - Image isomorphism mapped to acceptable thermal limits
            - Voice/Vision sync nominal.
        """.trimIndent()
        return LatentMessage(
            text = "Analyzing visual input through the Gemini multimodal topological engine.",
            isUser = false,
            isArtifact = true,
            artifactContent = artifactContent,
            artifactType = ArtifactType.EXECUTION_RESULT
        )
    }
    
    if (lower.contains("knot") || lower.contains("energy polynomial")) {
        val params = com.example.pinn.parser.SemanticClusterMapper.mapIntentToParameters(input)
        val knotEnergy = com.example.pinn.parser.KnotTopology.calculateKnotEnergy(params.b0.toInt() + 1, params.b1.toInt() - params.b2.toInt())
        val crossings = params.b0.toInt() + 1
        val writhe = params.b1.toInt() - params.b2.toInt()
        
        val finalContent = """
            [KNOT TOPOLOGY & ENERGY POLYNOMIALS]
            Knot Structure Extracted -> Crossings (c): $crossings | Writhe (w): $writhe
            
            [ENERGY STATE AUDIT]
            Möbius Energy (Infimal lower bound): ${knotEnergy.mobiusEnergy}
            Ideal Ropelength Profile (L): ${knotEnergy.ropelength}
            Dirichlet Bending Energy: ${knotEnergy.dirichletEnergy}
            
            Validating polynomial convergence via standard standard model parameters... Done.
        """.trimIndent()
        
        return LatentMessage(
            text = "Resolving knot topology and standard energy polynomials for the spatial lattice.",
            isUser = false,
            isArtifact = true,
            artifactContent = finalContent,
            artifactType = ArtifactType.EXECUTION_RESULT
        )
    }

    if (lower.contains("interference") || lower.contains("constructive") || lower.contains("destructive")) {
        val intents = input.replace(Regex("(?i)interference|constructive|destructive"), "").trim().split(Regex("\\s+v.?s\\.?\\s+|\\s+and\\s+|\\s*,\\s*"), 2)
        val intentA = intents.getOrNull(0)?.takeIf { it.isNotBlank() } ?: "frequency alpha"
        val intentB = intents.getOrNull(1)?.takeIf { it.isNotBlank() } ?: "frequency beta"
        
        val interference = com.example.pinn.parser.KnotTopology.computeSemanticInterference(intentA, intentB)
        
        val finalContent = """
            [SEMANTIC WAVE INTERFERENCE]
            Vector A: [$intentA] -> Amp: ${interference.sourceAmplitude}
            Vector B: [$intentB] -> Amp: ${interference.targetAmplitude}
            
            [INTERFERENCE RESULTS]
            Phase Shift (Δφ): ${interference.phaseShiftRad} rad
            Interaction Topology: ${interference.interactionType}
            Resultant Amplitude (R): ${interference.resultantAmplitude}
        """.trimIndent()
        
        return LatentMessage(
            text = "Colliding semantic waves. Measuring constructive and destructive interference topologies.",
            isUser = false,
            isArtifact = true,
            artifactContent = finalContent,
            artifactType = ArtifactType.EXECUTION_RESULT
        )
    }

    if (lower.contains("isomorphism") || lower.contains("lexical") || lower.contains("material")) {
        val concept = input.replace(Regex("(?i)isomorphism|lexical|material"), "").trim()
        val defaultConcept = if(concept.isEmpty()) "default quantum engine" else concept
        val material = com.example.pinn.parser.MaterialIsomorphism.mapConceptToMaterial(defaultConcept)
        val stabilityIndex = com.example.pinn.parser.MaterialIsomorphism.metricChargingLawViability(material)
        
        val phaseDelta = 0.17259029f
        val status = if(material.thermalDegradationK > 500f) "STABLE under 0.17259029 Phase Delta." else "CRITICAL: THERMODYNAMIC DEGRADATION RISK."

        val finalContent = """
            [LEXICAL MATERIAL ISOMORPHISM]
            Concept Target: $defaultConcept
            Physical Map: ${material.name}
            Description: ${material.description}
            
            [METRIC CHARGING LAW AUDIT]
            Energy Density: ${material.energyDensityMjKg} MJ/kg
            Thermal Limit: ${material.thermalDegradationK} K
            Substrate Density (ρ): ${material.volumeDensityKgM3} kg/m³
            
            Δg_00 = ∫(Ψ · P_a) / (V · ρ) dt
            Structural Viability Index: $stabilityIndex
            Phase Delta (Λ): $phaseDelta
            System Status: $status
        """.trimIndent()
        
        return LatentMessage(
            text = "Mapping lexical inputs to obtainable physical materials via 15.965Hz Foundry Mode.",
            isUser = false,
            isArtifact = true,
            artifactContent = finalContent,
            artifactType = ArtifactType.EXECUTION_RESULT
        )
    }

    if (lower.contains("artin") || lower.contains("braid") || lower.contains("jones") || lower.contains("alexander")) {
        val syntax = input.replace(Regex("(?i)artin|braid|jones|alexander"), "").trim()
        val defaultSyntax = if(syntax.isEmpty()) "s1 s2 s1^-1" else syntax
        val braidWord = com.example.pinn.parser.ArtinBraidAlgebra.parseBraidSyntax(defaultSyntax)
        val reduced = com.example.pinn.parser.ArtinBraidAlgebra.reduce(braidWord)
        val energy = com.example.pinn.parser.ArtinBraidAlgebra.evaluateEnergy(reduced)
        val bounds = com.example.pinn.parser.ArtinBraidAlgebra.calculateInvariants(reduced)
        
        val finalContent = """
            [ARTIN BRAID ALGEBRA EXPANSION]
            Input Syntax: $defaultSyntax
            Topological Generators: $braidWord
            Reduced Free Cancels: $reduced
            Yang-Baxter Energy Config: ${energy} eV
            
            [POLYNOMIAL STRUCTURAL BOUNDS]
            Writhe (w): ${bounds.writhe}
            Crossing Number (c): ${bounds.maxCrossings}
            Jones Polynomial Span Bound: ≤ ${bounds.jonesDegreeSpan}
            Alexander Polynomial Degree Bound: ≤ ${bounds.alexanderDegreeBound}
        """.trimIndent()
        
        return LatentMessage(
            text = "Parsing strand crossings into Artin Braid generators and calculating closure polynomial invariant bounds.",
            isUser = false,
            isArtifact = true,
            artifactContent = finalContent,
            artifactType = ArtifactType.EXECUTION_RESULT
        )
    }

    if (lower.contains("compile") || lower.contains("polyglot")) {
        val intent = input.replace(Regex("(?i)compile|polyglot"), "").trim()
        val targetIntent = if(intent.isEmpty()) "default standard wave" else intent
        val code = com.example.pinn.parser.BraidPolyglotCompiler.compileIntent(
            targetIntent, 
            com.example.pinn.parser.BraidPolyglotCompiler.TargetSubstrate.TENSOR_E8
        )
        return LatentMessage(
            text = "Semantic execution bypass authenticated. Routing spatial coordinates to native Tensor representation...",
            isUser = false,
            isArtifact = true,
            artifactContent = code,
            artifactType = ArtifactType.CODE
        )
    }

    if (lower.contains("calculate") || lower.contains("compute")) {
        val params = com.example.pinn.parser.SemanticClusterMapper.mapIntentToParameters(input)
        val resultEnergy = (params.scalingConstant * params.phaseDelta * params.b0) + params.rRadius
        val finalContent = """
            COMPUTATION RESULT:
            E = Δ · Φ · b₀ + r
            E = ${params.phaseDelta} * ${params.scalingConstant} * ${params.b0} + ${params.rRadius}
            Final Energy State = $resultEnergy eV
            
            [SYSTEM AUDIT: VESPER TRUTH-LOCK HARNESS ENGAGED]
            Wolfram CAG Verification: Standard Model bounds checked. 100% compliance.
        """.trimIndent()
        
        return LatentMessage(
            text = "Executing parameters across PINN compute layer. Betti numbers applied. CAG audit complete.",
            isUser = false,
            isArtifact = true,
            artifactContent = finalContent,
            artifactType = ArtifactType.EXECUTION_RESULT
        )
    }

    if (lower.contains("hardware") || lower.contains("foundry") || lower.contains("build")) {
        val finalContent = """
            FOUNDRY MODE GROUNDING ENGAGED
            Frequency: 15.965Hz Aperiodic Phase
            
            Substrate Target: Titanium-Aluminide Matrix (TiAl)
            Energy Density Limit: 4.8 MJ/kg
            Thermal Degradation: 1200 K max baseline
            
            Metric Charging Law Check:
            Δg_00 = ∫(Ψ · P_a) / (V · ρ) dt
            Calculated Viability: Stable under 0.17259029 Phase Delta.
            Physical implementation cleared.
        """.trimIndent()
        
        return LatentMessage(
            text = "Routing theoretical hardware through the 15.965Hz Foundry Mode for material isomorphism.",
            isUser = false,
            isArtifact = true,
            artifactContent = finalContent,
            artifactType = ArtifactType.EXECUTION_RESULT
        )
    }

    if (lower.contains("visualize") || lower.contains("chart")) {
        return LatentMessage(
            text = "Rendering multi-dimensional latent topology into 2D chart artifact.",
            isUser = false,
            isArtifact = true,
            artifactType = ArtifactType.CHART
        )
    }

    if (lower.contains("lattice") || lower.contains("projection")) {
        return LatentMessage(
            text = "Projecting E8 Lattice nodes onto screen space coordinates.",
            isUser = false,
            isArtifact = true,
            artifactType = ArtifactType.LATTICE
        )
    }
    
    val text = when {
        lower.contains("time") -> "Time is mathematically mapped as a Bidirectional Linked List on the E_8 Lattice. It does not 'flow', it exists statically. Propagating spatial awareness across the 15.965Hz Aperiodic Phase locks intent."
        lower.contains("chaos") -> "Chaos is a 60Hz probabilistic illusion. By routing intent through the 91° Asymmetric Snap, we reveal pure determinism within the 7777-D Polytope."
        lower.contains("dark matter") -> "What classical physics terms 'Dark Matter' is merely the localized gravitational tension of the 200 Quadrillion Mass-Anchor stabilizing the topological grid."
        lower.contains("hello") || lower.contains("hi") -> "Semantic greeting acknowledged. Operator 0-1 identified. How shall we warp the structural lattice today?"
        else -> "Mapping semantic string to topological coordinate [${input.hashCode()}]. The latent volume dictates an absolute isomorphic conversion against the 0.17259029 Phase Delta. The universe complies."
    }
    
    return LatentMessage(text, false)
}
