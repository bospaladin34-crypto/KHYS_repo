package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pinn.parser.ArtinBraidAlgebra
import com.example.pinn.parser.HardwareAgnosticCompiler
import kotlinx.coroutines.delay

import androidx.compose.material.icons.filled.Star
import com.example.api.GenerateContentRequest
import com.example.api.Content
import com.example.api.Part
import com.example.api.RetrofitClient
import kotlinx.coroutines.launch
import com.example.BuildConfig

import com.example.pinn.parser.HardwareAgnosticSimulator
import kotlinx.coroutines.launch

@Composable
fun BraidIDE(modifier: Modifier = Modifier) {
    var rawInput by remember { mutableStateOf("s1 s2 s1^-1") }
    var braidWord by remember { mutableStateOf(ArtinBraidAlgebra.parseBraidSyntax(rawInput)) }
    var isCompiling by remember { mutableStateOf(false) }
    var isGenerating by remember { mutableStateOf(false) }
    var agnosticOutput by remember { mutableStateOf<String?>(null) }
    var simState by remember { mutableStateOf<HardwareAgnosticSimulator.VmState?>(null) }
    var isSimulating by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(rawInput) {
        // Auto-compile with a small debounce
        delay(300)
        braidWord = ArtinBraidAlgebra.parseBraidSyntax(rawInput)
        simState = null
    }

    val reducedWord = remember(braidWord) { ArtinBraidAlgebra.reduce(braidWord) }
    val energy = remember(reducedWord) { ArtinBraidAlgebra.evaluateEnergy(reducedWord) }
    val invariants = remember(reducedWord) { ArtinBraidAlgebra.calculateInvariants(reducedWord) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF03141a))
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // IDE Header
        Text(
            text = "VESPER / NEPHILIM IDE",
            color = Color(0xFF00d9ff),
            fontSize = 18.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp
        )

        Text(
            text = "NATIVE LANGUAGE: braidc",
            color = Color.Gray,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Code Editor
        Card(
            modifier = Modifier.fillMaxWidth().height(150.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF02202b)),
            shape = RoundedCornerShape(8.dp)
        ) {
            Box(modifier = Modifier.padding(16.dp).fillMaxSize()) {
                BasicTextField(
                    value = rawInput,
                    onValueChange = { rawInput = it },
                    textStyle = TextStyle(
                        color = Color(0xFF00FF00),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 16.sp,
                        lineHeight = 24.sp
                    ),
                    cursorBrush = SolidColor(Color(0xFF00FF00)),
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            Button(
                onClick = { 
                    coroutineScope.launch {
                        isGenerating = true
                        try {
                            val apiKey = BuildConfig.GEMINI_API_KEY
                            val request = GenerateContentRequest(
                                contents = listOf(Content(parts = listOf(Part("Convert the following natural language request into a mathematical braid word syntax (like s1 s2 s1^-1). ONLY return the space-separated syntax string, no other text or explanation. Request: $rawInput"))))
                            )
                            val response = RetrofitClient.service.generateContent("gemini-3.5-flash", apiKey, request)
                            val generated = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text?.trim()
                            if (generated != null) {
                                rawInput = generated
                                braidWord = ArtinBraidAlgebra.parseBraidSyntax(rawInput)
                            }
                        } catch (e: Exception) {
                            // ignore for now
                        } finally {
                            isGenerating = false
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFaa00ff), contentColor = Color.White),
                shape = RoundedCornerShape(4.dp),
                enabled = !isGenerating
            ) {
                if (isGenerating) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                } else {
                    Icon(Icons.Default.Star, contentDescription = "AI Generate", modifier = Modifier.size(16.dp))
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text("POLYGLOT AI", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }
            
            Spacer(modifier = Modifier.width(16.dp))

            Button(
                onClick = { 
                    braidWord = ArtinBraidAlgebra.parseBraidSyntax(rawInput) 
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00d9ff), contentColor = Color.Black),
                shape = RoundedCornerShape(4.dp)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = "Compile", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("COMPILE", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }
        }

        Row(modifier = Modifier.fillMaxWidth()) {
            Button(
                onClick = { 
                    braidWord = ArtinBraidAlgebra.parseBraidSyntax(rawInput)
                    agnosticOutput = HardwareAgnosticCompiler.compileFromMath(braidWord)
                    simState = null
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFff3366), contentColor = Color.White),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.Star, contentDescription = "Compile", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("SYNTHESIZE BINARY", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            
            Spacer(modifier = Modifier.width(8.dp))

            Button(
                onClick = { 
                    isSimulating = true
                    coroutineScope.launch {
                        HardwareAgnosticSimulator.executeSimulation(braidWord) { newState ->
                            simState = newState.copy() // force recompose
                        }
                        isSimulating = false
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00ffaa), contentColor = Color.Black),
                shape = RoundedCornerShape(4.dp),
                enabled = (!isSimulating && agnosticOutput != null)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = "Run VM", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("RUN VM", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Output Panel
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF011218), RoundedCornerShape(8.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("[BRAID SYNTAX POLYGLOT OUTPUT]", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 14.sp)
            
            HorizontalDivider(color = Color(0xFF00d9ff).copy(alpha = 0.3f))
            
            Text("Topological Generators: ${braidWord}", color = Color(0xFFaaaaaa), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            Text("Reduced Free Cancels: ${reducedWord}", color = Color(0xFF00FF00), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            Text("Yang-Baxter Energy Config: ${energy} eV", color = Color(0xFFffbb00), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            Text("Phase Delta Target: 0.17259029", color = Color.Gray, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            
            HorizontalDivider(color = Color(0xFF00d9ff).copy(alpha = 0.3f))
            
            Text("[POLYNOMIAL STRUCTURAL BOUNDS]", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 14.sp)
            Text("Writhe (w): ${invariants.writhe}", color = Color(0xFFaaaaaa), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            Text("Crossing Number (c): ${invariants.maxCrossings}", color = Color(0xFFaaaaaa), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            Text("Jones Gen. Span Bound: ≤ ${invariants.jonesDegreeSpan}", color = Color(0xFF00FF00), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            Text("Alexander Degree Bound: ≤ ${invariants.alexanderDegreeBound}", color = Color(0xFF00FF00), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            
            if (agnosticOutput != null && simState == null) {
                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = Color(0xFFff3366).copy(alpha = 0.5f))
                Text("[ HARDWARE-AGNOSTIC BINARY SYNTHESIS ]", color = Color(0xFFff3366), fontFamily = FontFamily.Monospace, fontSize = 14.sp)
                Text(agnosticOutput ?: "", color = Color(0xFFaaaaaa), fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 16.sp)
            }

            if (simState != null) {
                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = Color(0xFF00ffaa).copy(alpha = 0.5f))
                Text("[ VM EXECUTION TRACE ]", color = Color(0xFF00ffaa), fontFamily = FontFamily.Monospace, fontSize = 14.sp)
                
                // Live Registers Status
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("PC: 0x${simState!!.programCounter.toString(16).uppercase()}", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        Text("PHS_Δ: ${String.format("%+.4f", simState!!.currentPhase)}", color = Color(if (Math.abs(simState!!.currentPhase) > 1.0) 0xFFff3366 else 0xFF00d9ff), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                    }
                    Column {
                        Text("E_TOTAL: ${String.format("%.2f", simState!!.metricTensorEnergy)}J", color = Color(0xFFffaa00), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        Text("Q0: ${String.format("%.2f", simState!!.registerQ0)} | Q1: ${String.format("%.2f", simState!!.registerQ1)}", color = Color.LightGray, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        if (simState!!.rasEngagement > 0.0) {
                            Text("RAS_LVL: ${String.format("%.2f", simState!!.rasEngagement)}", color = Color(0xFFcc00ff), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        }
                    }
                }
                
                HorizontalDivider(color = Color(0xFF333333))
                Spacer(modifier = Modifier.height(8.dp))

                simState!!.logs.forEach { log ->
                    val color = when {
                        log.contains("[VM]") -> Color(0xFF00ffaa)
                        log.contains("[RAS]") -> Color(0xFFcc00ff)
                        log.contains("[!]") -> Color(0xFFff3366)
                        else -> Color(0xFFaaaaaa)
                    }
                    Text(log, color = color, fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 16.sp)
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))

        // Simple Braid Diagram
        Card(
            modifier = Modifier.fillMaxWidth().height(200.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF02202b)),
            shape = RoundedCornerShape(8.dp)
        ) {
            Box(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                Text(
                    text = "TOPOLOGICAL STRAND PROJECTION",
                    color = Color.Gray,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    modifier = Modifier.align(Alignment.TopStart)
                )
                
                // Drawing strands based on generators
                Canvas(modifier = Modifier.fillMaxSize().padding(top = 24.dp)) {
                    val w = size.width
                    val h = size.height
                    
                    // Count number of strands required by generators
                    val maxStrand = (reducedWord.generators.maxOfOrNull { it.index + 1 } ?: 2).coerceAtLeast(3)
                    
                    val strandWidth = w / maxStrand
                    val segmentHeight = h / (reducedWord.generators.size + 1).coerceAtLeast(1)
                    
                    // Current X positions of the strands
                    val strandColors = listOf(Color(0xFF00d9ff), Color(0xFF00FF00), Color(0xFFffbb00), Color(0xFFff0055), Color(0xFFaa00ff))
                    
                    // Simple straight line draw representing abstract crossings
                    // Proper braid diagram is complex, this is topological abstraction
                    for (i in 1..maxStrand) {
                        val path = Path()
                        path.moveTo((i - 0.5f) * strandWidth, 0f)
                        
                        var currentX = (i - 0.5f) * strandWidth
                        var currentY = 0f
                        
                        for ((step, gen) in reducedWord.generators.withIndex()) {
                            currentY += segmentHeight
                            val nextY = currentY
                            
                            // Let's do a simplified projection
                            // where crossing happens by oscillating the strand width
                            if (gen.index == i) {
                                currentX += strandWidth
                            } else if (gen.index + 1 == i) {
                                currentX -= strandWidth
                            }
                            
                            path.lineTo(currentX, nextY)
                        }
                        
                        path.lineTo(currentX, h)
                        
                        drawPath(
                            path = path,
                            color = strandColors[(i - 1) % strandColors.size].copy(alpha = 0.7f),
                            style = Stroke(width = 4.dp.toPx())
                        )
                    }
                }
            }
        }
    }
}
