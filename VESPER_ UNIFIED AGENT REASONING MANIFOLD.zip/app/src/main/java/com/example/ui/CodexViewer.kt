package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.db.DoiProvenanceEntity
import com.example.pinn.CodexText
import com.example.pinn.ResearchArchives

@Composable
fun CodexViewer(
    modifier: Modifier = Modifier,
    dois: List<DoiProvenanceEntity> = emptyList(),
    onClose: () -> Unit
) {
    var selectedDoi by remember { mutableStateOf<DoiProvenanceEntity?>(null) }
    
    val conceptsToHighlight = remember(selectedDoi) {
        selectedDoi?.associatedConcepts?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() } ?: emptyList()
    }

    fun highlightText(text: String): androidx.compose.ui.text.AnnotatedString {
        if (conceptsToHighlight.isEmpty()) return buildAnnotatedString { append(text) }
        
        return buildAnnotatedString {
            var currentIndex = 0
            val lowerText = text.lowercase()
            
            // Very basic multi-keyword highlighting logic
            val matches = mutableListOf<Pair<Int, Int>>()
            for (concept in conceptsToHighlight) {
                var idx = lowerText.indexOf(concept.lowercase())
                while (idx >= 0) {
                    matches.add(idx to idx + concept.length)
                    idx = lowerText.indexOf(concept.lowercase(), idx + concept.length)
                }
            }
            
            matches.sortBy { it.first }
            
            var lastEnd = 0
            for ((start, end) in matches) {
                if (start >= lastEnd) {
                    append(text.substring(lastEnd, start))
                    withStyle(style = SpanStyle(background = Color.Yellow, color = Color.Black, fontWeight = FontWeight.Bold)) {
                        append(text.substring(start, end))
                    }
                    lastEnd = end
                }
            }
            if (lastEnd < text.length) {
                append(text.substring(lastEnd))
            }
        }
    }

    Row(modifier = modifier.fillMaxSize().background(Color(0xFF001100))) {
        // DOI List Sidebar
        Column(
            modifier = Modifier
                .weight(0.3f)
                .fillMaxHeight()
                .background(Color(0xFF002200))
                .padding(8.dp)
        ) {
            Text(
                "DOI PROVENANCE",
                color = Color.Green,
                fontFamily = FontFamily.Monospace,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(dois) { doi ->
                    val isSelected = selectedDoi == doi
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable { 
                                selectedDoi = if (isSelected) null else doi 
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) Color(0xFF005500) else Color(0xFF003300)
                        )
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Text(
                                doi.platform,
                                color = Color.Yellow,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                doi.url,
                                color = Color.Green,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                maxLines = 2
                            )
                        }
                    }
                }
            }
        }

        // Document Viewer
        Column(
            modifier = Modifier
                .weight(0.7f)
                .fillMaxHeight()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "VESPER-SANTOS CODEX & ARCHIVES",
                    color = Color.Green,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Button(
                    onClick = onClose,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003300))
                ) {
                    Text("CLOSE", color = Color.Green, fontFamily = FontFamily.Monospace)
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            LazyColumn(
                modifier = Modifier.weight(1f)
            ) {
                item {
                    Text(
                        text = highlightText(CodexText.FULL_TEXT),
                        color = Color(0xFF55FF55),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                    Spacer(modifier = Modifier.height(32.dp))
                    Text(
                        "--- INTEGRATED RESEARCH ARCHIVES ---",
                        color = Color(0xFFFFD700),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                }
                items(ResearchArchives.documents) { doc ->
                    Text(
                        text = "◆ ${doc.title.uppercase()}",
                        color = Color(0xFF00D9FF),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = highlightText(doc.content),
                        color = Color(0xFFAAAAAA),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}

