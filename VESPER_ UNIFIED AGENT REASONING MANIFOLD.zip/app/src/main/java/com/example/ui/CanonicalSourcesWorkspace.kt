package com.example.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.LocalVesperColors

data class CanonicalSource(
    val title: String,
    val url: String,
    val description: String = ""
)

@Composable
fun CanonicalSourcesWorkspace() {
    val colors = LocalVesperColors.current
    val context = LocalContext.current
    
    val sources = listOf(
        CanonicalSource("Vesper-01 (GitHub)", "https://github.com/bospaladin34-crypto/Vesper-01", "Core Vesper architecture."),
        CanonicalSource("Vesper Quartz Reservoir (GitHub)", "https://github.com/bospaladin34-crypto/vesper_quartz_reservoir", "Hardware simulation and physics data."),
        CanonicalSource("KHYS Repo (GitHub)", "https://github.com/bospaladin34-crypto/KHYS_repo", "Key hierarchy and cryptographic primitives."),
        CanonicalSource("Santos-Sync (GitHub)", "https://github.com/bospaladin34-crypto/Santos-Sync", "Synchronization protocol implementations."),
        CanonicalSource("openAIRE", "https://explore.openaire.eu/search/result?pid=10.5281%2Fzenodo.19502225", "Open science data index."),
        CanonicalSource("Software Heritage", "https://archive.softwareheritage.org/browse/directory/189ecd6366901cc3aad2d1b507f7a44ba2c51e5e/?origin_url=https://doi.org/10.5281/zenodo.19502224&path=bospaladin34-crypto-KHYS_repo-49da4ae&release=1&snapshot=cb4b65b350d066519688b9187796fe91118b7883", "Source code archive tracking."),
        CanonicalSource("Zenodo", "https://doi.org/10.5281/zenodo.20315546", "Academic publication record."),
        CanonicalSource("Facebook", "https://www.facebook.com/Vesper0.17259029", "Social engagement and community updates."),
        CanonicalSource("YouTube", "https://youtube.com/@vesper01-v1k?si=QDDfHPCzBuWuxt5E", "Video demonstrations and lectures.")
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "CANONICAL SOURCES & GITHUB",
            color = colors.textCyan,
            fontSize = 18.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        
        Text(
            text = "Verified external repositories, academic publications, and community links associated with the Vesper ecosystem.",
            color = colors.primaryText.copy(alpha = 0.8f),
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace
        )

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(sources) { source ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, colors.borderCyan, RoundedCornerShape(8.dp))
                        .background(colors.panelBackground)
                        .clickable {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(source.url))
                            context.startActivity(intent)
                        }
                        .padding(16.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = source.title,
                            color = colors.primaryText,
                            fontSize = 14.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = source.description,
                            color = colors.primaryText.copy(alpha = 0.7f),
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = source.url,
                            color = colors.textCyan,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            textDecoration = TextDecoration.Underline
                        )
                    }
                }
            }
        }
    }
}
