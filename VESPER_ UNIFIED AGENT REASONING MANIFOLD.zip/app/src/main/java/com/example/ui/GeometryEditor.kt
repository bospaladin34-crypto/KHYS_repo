package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.LanguageToGeometryMapper
import android.content.Context
import androidx.compose.ui.platform.LocalContext
import org.json.JSONObject
import org.json.JSONArray
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun GeometryEditor(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val sharedPreferences = remember { context.getSharedPreferences("geometry_workspace", Context.MODE_PRIVATE) }

    val phrase by remember { mutableStateOf("toroidal containment") }
    
    val geometry by remember { 
        mutableStateOf(LanguageToGeometryMapper.mapLanguageToGeometry(phrase)) 
    }
    
    var editedPoints by remember(geometry) {
        mutableStateOf(geometry.points.toList())
    }

    var boundsMultiplier by remember { mutableStateOf(1.0f) }
    var rotationY by remember { mutableStateOf(0f) }
    var rotationX by remember { mutableStateOf(0f) }
    
    var selectedIndex by remember { mutableStateOf<Int?>(null) }
    
    var snapToGrid by remember { mutableStateOf(false) }

    var latexConstraint by remember { mutableStateOf("z = x^2 + y^2") }
    var enforceLatex by remember { mutableStateOf(false) }

    LaunchedEffect(enforceLatex, latexConstraint) {
        if (enforceLatex) {
            val str = latexConstraint.lowercase().replace(" ", "")
            val isParaboloid = str.contains("z=x^2+y^2")
            val isSphere = str.contains("x^2+y^2+z^2=")
            val isWave = str.contains("sin")
            val isNephilim = str.contains("nephilim") || str.contains("manifold") || str.contains("vesper")
            val isKhys = str.contains("khys") || str.contains("snap") || str.contains("attention")

            while (true) {
                var changed = false
                val newPoints = editedPoints.mapIndexed { idx, p ->
                    if (idx == selectedIndex) return@mapIndexed p // Don't enforce constraint on actively manipulated point (maybe we want to, but this makes dragging easier)
                    var nx = p.first
                    var ny = p.second
                    var nz = p.third
                    
                    var pChanged = false
                    if (isKhys) {
                        val r = kotlin.math.sqrt(nx*nx + ny*ny)
                        val angle = kotlin.math.atan2(ny.toDouble(), nx.toDouble())
                        // Shearing constraint: limit phase to 91 degrees or orthogonal harmonics
                        val snapAngle = kotlin.math.round(angle / (Math.PI / 2.0)) * (Math.PI / 2.0) + (91.0 * Math.PI / 180.0)
                        
                        val targetX = (r * kotlin.math.cos(snapAngle)).toFloat()
                        val targetY = (r * kotlin.math.sin(snapAngle)).toFloat()
                        
                        if (kotlin.math.abs(targetX - nx) > 0.05f || kotlin.math.abs(targetY - ny) > 0.05f) {
                            nx += (targetX - nx) * 0.05f
                            ny += (targetY - ny) * 0.05f
                            pChanged = true
                        }
                    } else if (isNephilim) {
                        // Apply Nephilim's high-dimensional manifold constraint
                        val (dx, dy, dz) = com.example.service.NephilimManifoldEngine.calculateConstraintDelta(nx, ny, nz)
                        if (kotlin.math.abs(dx) > 0.001f || kotlin.math.abs(dy) > 0.001f || kotlin.math.abs(dz) > 0.001f) {
                            nx += dx
                            ny += dy
                            nz += dz
                            pChanged = true
                        }
                    } else if (isSphere) {
                        val d = kotlin.math.sqrt(nx*nx + ny*ny + nz*nz)
                        if (kotlin.math.abs(d - 1.0f) > 0.05f && d > 0.001f) {
                            nx += (nx/d - nx) * 0.05f
                            ny += (ny/d - ny) * 0.05f
                            nz += (nz/d - nz) * 0.05f
                            pChanged = true
                        }
                    } else if (isParaboloid) {
                        val targetZ = (nx*nx + ny*ny).coerceIn(-5f, 5f)
                        if (kotlin.math.abs(targetZ - nz) > 0.05f) {
                            nz += (targetZ - nz) * 0.05f
                            pChanged = true
                        }
                    } else if (isWave) {
                        val targetZ = kotlin.math.sin(nx * 3f).toFloat() * kotlin.math.cos(ny * 3f).toFloat()
                        if (kotlin.math.abs(targetZ - nz) > 0.05f) {
                            nz += (targetZ - nz) * 0.05f
                            pChanged = true
                        }
                    }
                    if (pChanged) changed = true
                    Triple(nx, ny, nz)
                }
                
                if (changed) {
                    editedPoints = newPoints
                }
                kotlinx.coroutines.delay(16)
            }
        }
    }
    
    Box(modifier = modifier.fillMaxSize().background(Color(0xFF0A0A11))) {
        Canvas(modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    rotationY += dragAmount.x * 0.01f
                    rotationX += dragAmount.y * 0.01f
                }
            }
        ) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val scale = (size.minDimension / 2f) / (geometry.bounds * boundsMultiplier) * 0.8f
            
            for (i in editedPoints.indices) {
                val p = editedPoints[i]
                
                val x1 = p.first * cos(rotationY) - p.third * sin(rotationY)
                val z1 = p.first * sin(rotationY) + p.third * cos(rotationY)
                
                val y2 = p.second * cos(rotationX) - z1 * sin(rotationX)
                val z2 = p.second * sin(rotationX) + z1 * cos(rotationX)
                
                val screenX = cx + x1 * scale
                val screenY = cy + y2 * scale
                
                val depth = (z2 + geometry.bounds) / (2 * geometry.bounds)
                val alpha = (0.2f + 0.8f * depth).coerceIn(0.1f, 1.0f)
                
                val color = if (i == selectedIndex) Color.Red else Color(0xFF00FFCC).copy(alpha = alpha)
                val radius = if (i == selectedIndex) 8f else 3.5f
                
                drawCircle(
                    color = color,
                    radius = radius,
                    center = Offset(screenX.toFloat(), screenY.toFloat())
                )
            }
        }

        // Modular Dashboard Overlay
        GeometryDashboard(
            points = editedPoints,
            latexConstraint = latexConstraint,
            enforceLatex = enforceLatex,
            bounds = geometry.bounds * boundsMultiplier,
            modifier = Modifier.align(Alignment.TopStart).padding(16.dp)
        )

        // Overlay Editor Controls
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .fillMaxHeight(0.65f)
                .fillMaxWidth(0.6f)
                .background(Color.Black.copy(alpha = 0.85f))
                .padding(16.dp)
        ) {
            Text(
                "MANUAL GEOMETRY TWEAK",
                color = Color.Yellow,
                fontFamily = FontFamily.Monospace,
                fontSize = 14.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            
            Text("Scale Bounds Multiplier: %.2f".format(boundsMultiplier), color = Color.White, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            Slider(
                value = boundsMultiplier,
                onValueChange = { boundsMultiplier = it },
                valueRange = 0.1f..3.0f
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Text("Selected Vertex: ${selectedIndex ?: "None"}", color = Color.White, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                Button(onClick = { 
                    selectedIndex = if (selectedIndex == null || selectedIndex == 0) editedPoints.size - 1 else selectedIndex!! - 1 
                }) { Text("< Prev Vertex") }
                
                Button(onClick = { 
                    selectedIndex = if (selectedIndex == null || selectedIndex == editedPoints.size - 1) 0 else selectedIndex!! + 1 
                }) { Text("Next Vertex >") }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Row(verticalAlignment = Alignment.CenterVertically) {
                androidx.compose.material3.Switch(
                    checked = snapToGrid,
                    onCheckedChange = { snapToGrid = it }
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Snap to Grid (0.25)", color = Color.White, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            }

            Spacer(modifier = Modifier.height(8.dp))
            
            Text("LaTeX PHYSICS CONSTRAINT", color = Color(0xFFAAAAFF), fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            
            androidx.compose.foundation.text.BasicTextField(
                value = latexConstraint,
                onValueChange = { latexConstraint = it },
                textStyle = androidx.compose.ui.text.TextStyle(
                    color = Color.White,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                ),
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions.Default.copy(
                    imeAction = androidx.compose.ui.text.input.ImeAction.Done
                ),
                modifier = Modifier.fillMaxWidth().background(Color(0xFF222233)).padding(8.dp)
            )
            
            Row(verticalAlignment = Alignment.CenterVertically) {
                androidx.compose.material3.Switch(
                    checked = enforceLatex,
                    onCheckedChange = { enforceLatex = it }
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Enforce RT Constraint", color = Color.White, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            }

            Spacer(modifier = Modifier.height(8.dp))
            
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Button(onClick = { 
                    val root = JSONObject()
                    root.put("latexConstraint", latexConstraint)
                    root.put("enforceLatex", enforceLatex)
                    root.put("boundsMultiplier", boundsMultiplier.toDouble())
                    val ptsArray = JSONArray()
                    for (p in editedPoints) {
                        val pt = JSONObject()
                        pt.put("x", p.first.toDouble())
                        pt.put("y", p.second.toDouble())
                        pt.put("z", p.third.toDouble())
                        ptsArray.put(pt)
                    }
                    root.put("points", ptsArray)
                    sharedPreferences.edit().putString("workspace_json", root.toString()).apply()
                }) { Text("Save WS") }
                
                Button(onClick = { 
                    val jsonStr = sharedPreferences.getString("workspace_json", null)
                    if (jsonStr != null) {
                        try {
                            val root = JSONObject(jsonStr)
                            latexConstraint = root.optString("latexConstraint", latexConstraint)
                            enforceLatex = root.optBoolean("enforceLatex", enforceLatex)
                            boundsMultiplier = root.optDouble("boundsMultiplier", boundsMultiplier.toDouble()).toFloat()
                            val ptsArray = root.optJSONArray("points")
                            if (ptsArray != null) {
                                val newList = mutableListOf<Triple<Float, Float, Float>>()
                                for (i in 0 until ptsArray.length()) {
                                    val pt = ptsArray.getJSONObject(i)
                                    newList.add(Triple(pt.getDouble("x").toFloat(), pt.getDouble("y").toFloat(), pt.getDouble("z").toFloat()))
                                }
                                editedPoints = newList
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                }) { Text("Load WS") }
            }

            Spacer(modifier = Modifier.height(8.dp))
            
            if (selectedIndex != null) {
                val sp = editedPoints[selectedIndex!!]
                
                Text("X Coordinate: %.3f".format(sp.first), color = Color.Red, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                Slider(
                    value = sp.first,
                    onValueChange = { nv ->
                        val nList = editedPoints.toMutableList()
                        nList[selectedIndex!!] = Triple(nv, sp.second, sp.third)
                        editedPoints = nList
                    },
                    valueRange = -5f..5f,
                    steps = if (snapToGrid) 39 else 0
                )
                
                Text("Y Coordinate: %.3f".format(sp.second), color = Color.Green, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                Slider(
                    value = sp.second,
                    onValueChange = { nv ->
                        val nList = editedPoints.toMutableList()
                        nList[selectedIndex!!] = Triple(sp.first, nv, sp.third)
                        editedPoints = nList
                    },
                    valueRange = -5f..5f,
                    steps = if (snapToGrid) 39 else 0
                )
                
                Text("Z Coordinate: %.3f".format(sp.third), color = Color(0xFF66AAFF), fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                Slider(
                    value = sp.third,
                    onValueChange = { nv ->
                        val nList = editedPoints.toMutableList()
                        nList[selectedIndex!!] = Triple(sp.first, sp.second, nv)
                        editedPoints = nList
                    },
                    valueRange = -5f..5f,
                    steps = if (snapToGrid) 39 else 0
                )
            } else {
                Text("Select a vertex to edit its coordinates.", color = Color.Gray, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
fun GeometryDashboard(
    points: List<Triple<Float, Float, Float>>,
    latexConstraint: String,
    enforceLatex: Boolean,
    bounds: Float,
    modifier: Modifier = Modifier
) {
    val stats = remember(points, latexConstraint, enforceLatex, bounds) {
        val volume = (4.0 / 3.0) * Math.PI * Math.pow(bounds.toDouble(), 3.0)
        val surfaceArea = 4.0 * Math.PI * Math.pow(bounds.toDouble(), 2.0)
        val density = points.size / volume
        val activeConstraint = if (enforceLatex) latexConstraint else "None (Freeform)"
        val resonance = com.example.service.NephilimManifoldEngine.evaluateResonance(points)

        mapOf(
            "Vrtx Count" to "${points.size}",
            "Act. Constr" to activeConstraint,
            "Volume" to String.format("%.3f µ³", volume),
            "Surf Area" to String.format("%.3f µ²", surfaceArea),
            "Density" to String.format("%.2f p/µ³", density),
            "B-Radius" to String.format("%.2f µ", bounds),
            "Resonance" to String.format("%.4f", resonance)
        )
    }

    Column(
        modifier = modifier
            .background(Color(0xFF0D0D19).copy(alpha = 0.85f))
            .padding(12.dp)
            .width(200.dp)
    ) {
        Text(
            "WORKSPACE DASHBOARD",
            color = Color(0xFF00FFCC),
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        stats.forEach { (label, value) ->
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = label,
                    color = Color.Gray,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp
                )
                Text(
                    text = value,
                    color = Color.White,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp
                )
            }
        }
    }
}
