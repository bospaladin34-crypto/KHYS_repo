package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pinn.VesperInvariants
import com.example.pinn.GeometricLatentSpace
import com.example.pinn.ColorTheoryMapper
import com.example.pinn.CellularSheafDataManager
import kotlinx.coroutines.delay
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.GeometricStateViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import com.example.ui.LocalAnimationsEnabled

import com.example.VesperCoreViewModel

// Archimedes Palimpsest - Cellular Sheaf Network Visualizer
// Binds local geometric data points across the latent space defined by the 7777D Polytope

@Composable
fun CellularSheafVisualizer(
    modifier: Modifier = Modifier, 
    geometricViewModel: GeometricStateViewModel = viewModel(),
    vesperViewModel: VesperCoreViewModel = viewModel()
) {
    val geometricState by geometricViewModel.state.collectAsStateWithLifecycle()
    var globalPhase by remember(geometricState) { mutableStateOf(geometricState?.lastGlobalPhase ?: 0f) }
    var frameCount by remember { mutableStateOf(0) }
    
    val agenticState by vesperViewModel.agenticState.collectAsStateWithLifecycle()
    val manifoldEnergy by vesperViewModel.manifoldEnergy.collectAsStateWithLifecycle()
    
    // Generate abstract physical data points representing vectors across the 7777D Polytope
    val mockDataPoints = remember {
        List(GeometricLatentSpace.ARCHIMEDES_SHEAF_PAGE) { i -> floatArrayOf(kotlin.math.sin(i.toFloat()), kotlin.math.cos(i.toFloat()), 0.5f) }
    }
    
    // Generate the Sheaf Topology by feeding data into the Data Manager
    val network by remember(globalPhase) { 
        mutableStateOf(CellularSheafDataManager.buildSheafNetwork(mockDataPoints, globalPhase)) 
    }
    
    // Rendering state
    data class SheafRenderState(
        val edges: List<Pair<Offset, Offset>>,
        val nodes: List<Offset>,
        val stalkVectors: List<Pair<Offset, Offset>>,
        val nodeColors: List<Float>,
        val edgeMapT: List<Float>
    )
    var renderState by remember { mutableStateOf(SheafRenderState(emptyList(), emptyList(), emptyList(), emptyList(), emptyList())) }
    
    val animationsEnabled = LocalAnimationsEnabled.current

    LaunchedEffect(animationsEnabled) {
        if (!animationsEnabled) return@LaunchedEffect
        while (true) {
            val startPhase = globalPhase
            // Mathematical calculations moved off the main thread to Dispatchers.Default for asynchronous rendering
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
                val newEdges = mutableListOf<Pair<Offset, Offset>>()
                val newNodes = mutableListOf<Offset>()
                val newStalks = mutableListOf<Pair<Offset, Offset>>()
                val newNodeColors = mutableListOf<Float>()
                val newEdgeMapT = mutableListOf<Float>()
                
                val currentNetwork = CellularSheafDataManager.buildSheafNetwork(mockDataPoints, startPhase)
                
                // Pre-compute canvas scale assumptions - we don't have exact canvas size in LaunchedEffect
                // But we can compute relative coordinates from -cx to cx, -cy to cy
                // and offset later
                
                currentNetwork.nodes.forEach { node ->
                    val phi = VesperInvariants.GOLDEN_RATIO_PHI.toFloat()
                    val baseRadius = (node.id.toFloat() / currentNetwork.nodes.size) * 300f + 50f
                    val baseAngle = node.id * phi * Math.PI.toFloat() * 2f
                    
                    val aperiodicDistortion = sin(startPhase + node.id * 0.1f) * 15f
                    val currentRadius = baseRadius + aperiodicDistortion
                    val currentAngle = baseAngle + startPhase * 0.05f
                    
                    val x1 = currentRadius * cos(currentAngle)
                    val y1 = currentRadius * sin(currentAngle)
                    
                    val p1 = Offset(x1, y1)
                    newNodes.add(p1)
                    newNodeColors.add(node.id.toFloat() / currentNetwork.nodes.size)
                    
                    val vectorMagnitude = sqrt(node.stalk.vectorValues.map { it * it }.sum())
                    val stalkLength = 20f + sin(node.stalk.pilotWavePhase + baseAngle) * (10f * vectorMagnitude)
                    val stalkAngle = currentAngle + Math.PI.toFloat() / 2f
                    
                    val sx = x1 + stalkLength * cos(stalkAngle)
                    val sy = y1 + stalkLength * sin(stalkAngle)
                    newStalks.add(p1 to Offset(sx, sy))

                    node.connectedNodeIds.forEach { targetId ->
                        val targetNode = currentNetwork.nodes[targetId]
                        val tBaseRadius = (targetNode.id.toFloat() / currentNetwork.nodes.size) * 300f + 50f
                        val tBaseAngle = targetNode.id * phi * Math.PI.toFloat() * 2f
                        
                        val tAperiodicDistortion = sin(startPhase + targetNode.id * 0.1f) * 15f
                        val tRadius = tBaseRadius + tAperiodicDistortion
                        val tAngle = tBaseAngle + startPhase * 0.05f
                        
                        val x2 = tRadius * cos(tAngle)
                        val y2 = tRadius * sin(tAngle)
                        
                        newEdges.add(p1 to Offset(x2, y2))
                        newEdgeMapT.add((node.id.toFloat() + targetId.toFloat()) / (currentNetwork.nodes.size * 2f))
                    }
                }
                
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    renderState = SheafRenderState(newEdges, newNodes, newStalks, newNodeColors, newEdgeMapT)
                    globalPhase += 0.02f
                    frameCount++
                    if (frameCount % 60 == 0) { // save every ~2 seconds
                        geometricViewModel.saveState(
                            geometricState?.showP3 ?: true, 
                            geometricState?.showE8 ?: true, 
                            geometricState?.showPolytope ?: true, 
                            geometricState?.lastRotationAngle ?: 0f, 
                            globalPhase
                        )
                    }
                }
            }
            delay(33L) // roughly 30fps refresh representing the 15Hz discrete steps
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF030508)) // Very deep void color
    ) {
        // Background Palimpsest Faded Text
        Column(
            modifier = Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.SpaceEvenly,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val textBlocks = listOf(
                "Δ(E, φ) = κ · exp( -|E - G30| / Φ10Hz ) · ∮ ( dS / S8/9 )",
                "∇_μ (J_N^μ) + ΔΔ · (8/9 ω_rot) = 0",
                "π1(MSC) ≅ π1(HUP)",
                "Iτ = ∮ A · dl"
            )
            textBlocks.forEach { block ->
                Text(
                    text = block,
                    color = Color(0xFF1E293B).copy(alpha = 0.4f), // Faded slate (Palimpsest)
                    fontFamily = FontFamily.Serif,
                    fontSize = 24.sp,
                    letterSpacing = 4.sp
                )
            }
        }

        // Foreground Sheaf Network
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp)
        ) {
            Text(
                text = "CELLULAR SHEAF NETWORK (ARCHIMEDES' PALIMPSEST)",
                color = Color(0xFFe879f9), // Violet/Magenta tint for esoteric rendering
                fontFamily = FontFamily.Monospace,
                fontSize = 16.sp,
                modifier = Modifier.padding(bottom = 4.dp)
            )
            Text(
                text = "Mapping Local Vector Stalks across Latent P3/7777D Topology",
                color = Color(0xFF94a3b8),
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                modifier = Modifier.padding(bottom = 4.dp)
            )
            Text(
                text = "Agentic Substrate: $agenticState \nManifold Excitation: ${String.format(java.util.Locale.US, "%.4f", manifoldEnergy)} E",
                color = if (manifoldEnergy > 20f || manifoldEnergy < 0.5f) Color(0xFFFF3366) else Color(0xFF00FFCC),
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                val cx = size.width / 2f
                val cy = size.height / 2f
                
                // Draw Restriction Maps (Edges) calculated asynchronously
                renderState.edges.forEachIndexed { i, edge ->
                    val p1 = Offset(cx + edge.first.x, cy + edge.first.y)
                    val p2 = Offset(cx + edge.second.x, cy + edge.second.y)
                    
                    val mapT = renderState.edgeMapT[i]
                    val edgeColor = ColorTheoryMapper.mapValueToColor(mapT, ColorTheoryMapper.ColorScale.SHEAF_DENSITY, alpha = 0.3f)

                    drawLine(
                        color = edgeColor,
                        start = p1,
                        end = p2,
                        strokeWidth = 1.dp.toPx()
                    )
                }

                // Draw Base Spaces (Nodes)
                renderState.nodes.forEachIndexed { i, nodeOffset ->
                    val p1 = Offset(cx + nodeOffset.x, cy + nodeOffset.y)
                    val nodeColor = ColorTheoryMapper.mapValueToColor(renderState.nodeColors[i], ColorTheoryMapper.ColorScale.CYMATIC_SPECTRUM, alpha = 0.9f)
                    
                    drawCircle(
                        color = nodeColor,
                        radius = 3.dp.toPx(),
                        center = p1
                    )
                }
                
                // Draw Stalk Vectors
                renderState.stalkVectors.forEachIndexed { i, stalkOffsets ->
                    val p1 = Offset(cx + stalkOffsets.first.x, cy + stalkOffsets.first.y)
                    val sx = cx + stalkOffsets.second.x
                    val sy = cy + stalkOffsets.second.y
                    
                    val stalkColor = ColorTheoryMapper.mapValueToColor(1f - renderState.nodeColors[i], ColorTheoryMapper.ColorScale.E8_ROOT_WEIGHT, alpha = 0.8f)

                    drawLine(
                        color = stalkColor,
                        start = p1,
                        end = Offset(sx, sy),
                        strokeWidth = 1.5.dp.toPx()
                    )
                }
            }
        }
    }
}
