package com.example.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.withStyle

class EquationVisualTransformation : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val originalText = text.text
        
        val operators = setOf('+', '-', '*', '/', '=', '(', ')', '[', ']', '{', '}', '∂', '∇', '×', '·', '∫', '^')
        val constants = setOf('c', 'G', 'ℏ', 'h', 'π', 'e', 'i', 'ε', 'μ', '₀')
        val variables = setOf(
            'Ψ', 'ψ', 't', 'm', 'E', 'V', 'r', 'ρ', 'B', 'J', 'Λ', 'R', 'g', 'T', 'f', 'γ', 'α', 'β', 'δ', 'λ', 'σ', 'η', 'ω', 'Ω'
        )

        val annotatedString = buildAnnotatedString {
            for (i in originalText.indices) {
                val char = originalText[i]
                when {
                    char in operators -> {
                        withStyle(SpanStyle(color = Color(0xFFFF5555))) { // Red for operators
                            append(char.toString())
                        }
                    }
                    char in constants -> {
                        withStyle(SpanStyle(color = Color(0xFF55FFFF))) { // Cyan for constants
                            append(char.toString())
                        }
                    }
                    char in variables -> {
                        withStyle(SpanStyle(color = Color(0xFFFFFF55))) { // Yellow for variables/Greek letters
                            append(char.toString())
                        }
                    }
                    char.isDigit() -> {
                        withStyle(SpanStyle(color = Color(0xFF55FF55))) { // Green for numbers
                            append(char.toString())
                        }
                    }
                    else -> {
                        if (char.isLetter()) {
                            if (originalText.startsWith("/")) {
                                // Commands
                                val words = originalText.split(" ")
                                val firstWord = words.firstOrNull()
                                if (firstWord != null && i < firstWord.length) {
                                    withStyle(SpanStyle(color = Color(0xFFB388FF))) { // Purple for the command portion
                                        append(char.toString())
                                    }
                                } else {
                                    withStyle(SpanStyle(color = Color(0xFFCCCCCC))) { // Light gray for normal letters
                                        append(char.toString())
                                    }
                                }
                            } else {
                                withStyle(SpanStyle(color = Color(0xFFCCCCCC))) { // Light gray for normal letters
                                    append(char.toString())
                                }
                            }
                        } else {
                            // Default (spaces, other punctuation)
                            append(char.toString())
                        }
                    }
                }
            }
        }
        return TransformedText(annotatedString, OffsetMapping.Identity)
    }
}
