package com.example.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

/**
 * App-wide E8 Lattice Compression Stabilizer
 * Provides a subtle background stabilizing quantum walk to visually represent
 * the E8 compression algorithm structurally maintaining application integrity.
 */
@Composable
fun E8StabilizationWrapper(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "E8Stabilization")
    
    // Animate the E8 root projection rotation or "stabilization pulse"
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(20000, easing = LinearEasing), // Slow drift
            repeatMode = RepeatMode.Restart
        ),
        label = "E8Phase"
    )
    
    val compressionAlpha by infiniteTransition.animateFloat(
        initialValue = 0.02f,
        targetValue = 0.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "E8Pulse"
    )

    // Generate a subset of E8 projections to keep performance high
    val roots = remember { generateE8RootsSubset() }

    Box(modifier = modifier.fillMaxSize()) {
        // Subtle E8 Lattice Background Stabilizer
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val maxRadius = maxOf(cx, cy) * 1.5f // cover corners
            
            val cosP = cos(phase)
            val sinP = sin(phase)
            val cosPAuth = cos(phase * 0.618f)
            val sinPAuth = sin(phase * 0.618f)
            
            roots.forEach { root ->
                // Apply a simple 4D to 2D projection rotation based on phase
                val x = root[0] * cosP - root[1] * sinP
                val y = root[2] * cosPAuth + root[3] * sinPAuth
                
                val px = cx + x * maxRadius * 0.4f
                val py = cy + y * maxRadius * 0.4f
                
                drawLine(
                    color = Color(0xFF00FFCC).copy(alpha = compressionAlpha),
                    start = Offset(cx, cy),
                    end = Offset(px, py),
                    strokeWidth = Stroke.HairlineWidth
                )
                
                drawCircle(
                    color = Color(0xFFFF00FF).copy(alpha = compressionAlpha * 2f),
                    radius = 2f,
                    center = Offset(px, py)
                )
            }
        }
        
        // Render the actual app content on top of the E8 stabilizing manifold
        content()
    }
}

// Generates a limited subset of 240 E8 roots for ambient UI performance
// In physical terms: this anchors the structural UI into the true 8D lattice
private fun generateE8RootsSubset(): List<FloatArray> {
    val roots = mutableListOf<FloatArray>()
    // Generate permutations of (+/-1, +/-1, 0, 0, 0, 0, 0, 0) in the first 4 dims
    for (i in 0 until 4) {
        for (j in i+1 until 4) {
            for (si in listOf(-1f, 1f)) {
                for (sj in listOf(-1f, 1f)) {
                    val root = FloatArray(4)
                    root[i] = si
                    root[j] = sj
                    roots.add(root)
                }
            }
        }
    }
    // Generate 1/2(+/-1, ... +/-1) subset where prod is 1
    val signs = listOf(-1f, 1f)
    for (s0 in signs) {
        for (s1 in signs) {
            for (s2 in signs) {
                for (s3 in signs) {
                    if (s0 * s1 * s2 * s3 > 0) {
                        roots.add(floatArrayOf(s0 * 0.5f, s1 * 0.5f, s2 * 0.5f, s3 * 0.5f))
                    }
                }
            }
        }
    }
    return roots.take(120) // Only take 120 so visualization is fast across the entire app architecture
}
