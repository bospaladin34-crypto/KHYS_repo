package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.LocalVesperColors

@Composable
fun GlyphGalleryScreen(modifier: Modifier = Modifier) {
    val glyphs = listOf(
        R.drawable.glyph_1,
        R.drawable.glyph_2,
        R.drawable.glyph_3,
        R.drawable.glyph_4,
        R.drawable.glyph_5,
        R.drawable.glyph_6,
        R.drawable.glyph_7,
        R.drawable.glyph_8,
        R.drawable.glyph_9
    )

    var selectedGlyph by remember { mutableStateOf<Int?>(null) }

    Box(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Text(
                text = "SYSTEM MANIFOLD GALLERY",
                color = LocalVesperColors.current.textMagenta,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Text(
                text = "Accessing digital glyph matrices. 9 semantic resonance topologies detected.",
                color = LocalVesperColors.current.primaryText.copy(alpha = 0.7f),
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
                modifier = Modifier.padding(bottom = 16.dp)
            )
            
            Text(
                text = "Notice: To view generated math geometries, upload your provided images to the 'app/src/main/res/drawable' directory in the IDE to overwrite these placeholder files.",
                color = LocalVesperColors.current.textCyan,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(glyphs) { glyphResId ->
                    Box(
                        modifier = Modifier
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.dp, LocalVesperColors.current.textMagenta.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .clickable { selectedGlyph = glyphResId },
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = glyphResId),
                            contentDescription = "Glyph",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = selectedGlyph != null,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xE0000000))
                    .clickable { selectedGlyph = null },
                contentAlignment = Alignment.Center
            ) {
                selectedGlyph?.let { resId ->
                    Image(
                        painter = painterResource(id = resId),
                        contentDescription = "Expanded Glyph",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .border(2.dp, LocalVesperColors.current.textCyan, RoundedCornerShape(16.dp))
                    )
                }
            }
        }
    }
}
