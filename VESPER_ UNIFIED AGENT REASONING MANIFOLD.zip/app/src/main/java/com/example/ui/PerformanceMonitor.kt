package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.DecimalFormat

@Composable
fun ComputePerformanceMonitor(modifier: Modifier = Modifier) {
    var usedMemory by remember { mutableStateOf(0L) }
    var totalMemory by remember { mutableStateOf(0L) }
    var maxMemory by remember { mutableStateOf(0L) }
    var simulatedVramUsed by remember { mutableStateOf(14.2f) }
    var simulatedVramMax by remember { mutableStateOf(24.0f) }
    
    val animationsEnabled = LocalAnimationsEnabled.current

    LaunchedEffect(animationsEnabled) {
        if (!animationsEnabled) return@LaunchedEffect
        while (true) {
            val runtime = Runtime.getRuntime()
            usedMemory = runtime.totalMemory() - runtime.freeMemory()
            totalMemory = runtime.totalMemory()
            maxMemory = runtime.maxMemory()
            // Jitter VRAM a bit
            val jitter = (Math.random() * 0.2 - 0.1).toFloat()
            simulatedVramUsed = (simulatedVramUsed + jitter).coerceIn(12.0f, 22.0f)
            delay(1000)
        }
    }

    val mbFormat = DecimalFormat("#.##")
    val usedMb = mbFormat.format(usedMemory / (1024.0 * 1024.0))
    val maxMb = mbFormat.format(maxMemory / (1024.0 * 1024.0))
    val vramStr = mbFormat.format(simulatedVramUsed)
    val vramMaxStr = mbFormat.format(simulatedVramMax)

    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xFF030D12), RoundedCornerShape(4.dp))
            .border(1.dp, Color(0xFF00FF00).copy(alpha = 0.3f), RoundedCornerShape(4.dp))
            .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("CPU HEAP", color = Color.Gray, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            Text("${usedMb}MB / ${maxMb}MB", color = Color(0xFF00FF00), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("VRAM (SIM)", color = Color.Gray, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            Text("${vramStr}GB / ${vramMaxStr}GB", color = Color.Cyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("CORE TEMP", color = Color.Gray, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            Text("42°C", color = Color.Yellow, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("FPS", color = Color.Gray, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            Text("60.0", color = Color.Green, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        }
    }
}
