package com.example.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pinn.parser.SantosProtocol
import kotlinx.coroutines.delay
import com.example.ui.LocalAnimationsEnabled

@Composable
fun SantosProtocolVisualizer(modifier: Modifier = Modifier) {
    var isRunning by remember { mutableStateOf(false) }
    var enforceParity by remember { mutableStateOf(true) }
    var inputSignalAmplitude by remember { mutableFloatStateOf(5f) }
    var time by remember { mutableDoubleStateOf(0.0) }
    
    var state by remember { mutableStateOf(SantosProtocol.SantosState(0.0, 0.0, 0.0, 0.0, true, true, 0.0, emptyList())) }

    val animationsEnabled = LocalAnimationsEnabled.current

    LaunchedEffect(isRunning, enforceParity, inputSignalAmplitude, animationsEnabled) {
        if (!animationsEnabled) return@LaunchedEffect
        if (isRunning) {
            while (true) {
                // Advance time
                time += 0.1
                // Add some noise to the input signal
                val noise = (Math.random() - 0.5) * 2.0
                val signal = inputSignalAmplitude + noise
                
                state = SantosProtocol.computeSantosCycle(time, signal, enforceParity)
                
                delay(100)
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0A0A0A))
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // HEADER
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Text(
                "SANTOS PROTOCOL II",
                color = Color(0xFF00FF00),
                fontSize = 24.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp
            )
            Text(
                "Intake, Constraint, Synthesis Loop",
                color = Color(0xFFFFA500),
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
        }
        
        HorizontalDivider(color = Color(0xFF333333))

        // CONTROLS
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = { isRunning = !isRunning },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isRunning) Color(0xFFFF0055) else Color(0xFF00d9ff)
                )
            ) {
                Text(if (isRunning) "HALT ENGINE" else "IGNITE RUNTIME", fontFamily = FontFamily.Monospace, color = Color.Black, fontWeight = FontWeight.Bold)
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = enforceParity,
                    onCheckedChange = { enforceParity = it },
                    colors = CheckboxDefaults.colors(checkedColor = Color(0xFF00FF00))
                )
                Text("ENFORCE PARITY (P²=I)", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            }
        }

        // INPUT SIGNAL SLIDER
        Column(modifier = Modifier.fillMaxWidth().background(Color(0xFF111111), RoundedCornerShape(8.dp)).padding(16.dp)) {
            Text("INPUT SIGNAL AMPLITUDE (ψ_0): ${String.format("%.2f", inputSignalAmplitude)}", color = Color(0xFF00d9ff), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            Slider(
                value = inputSignalAmplitude,
                onValueChange = { inputSignalAmplitude = it },
                valueRange = 0f..15f,
                colors = SliderDefaults.colors(
                    thumbColor = Color(0xFF00d9ff),
                    activeTrackColor = Color(0xFF00d9ff)
                )
            )
        }

        // DYNAMICS MANIFOLD VISUALIZER
        Card(
            modifier = Modifier.fillMaxWidth().height(200.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF050505)),
            shape = RoundedCornerShape(8.dp)
        ) {
            Box(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                Text("TWIN RUNTIME (DUAL-PHASE ENGINE)", color = Color(0xFFFF00FF), fontFamily = FontFamily.Monospace, fontSize = 10.sp, modifier = Modifier.align(Alignment.TopStart))
                
                Canvas(modifier = Modifier.fillMaxSize().padding(top = 20.dp)) {
                    val w = size.width
                    val h = size.height
                    
                    val midY = h / 2f
                    
                    // Draw Twin Waves
                    val wavePath1 = Path()
                    val wavePath2 = Path()
                    
                    val points = 100
                    for (i in 0..points) {
                        val x = (i.toFloat() / points) * w
                        // Use time to offset
                        val tOff = time.toFloat() * 2f
                        // Wave 1 is R1 representation
                        val y1 = midY + (Math.sin((i * 0.1) + tOff) * state.R1 * 20).toFloat()
                        // Wave 2 is R2 representation
                        val y2 = midY + (Math.cos((i * 0.1) + tOff) * state.R2 * 20).toFloat()
                        
                        if (i == 0) {
                            wavePath1.moveTo(x, y1)
                            wavePath2.moveTo(x, y2)
                        } else {
                            wavePath1.lineTo(x, y1)
                            wavePath2.lineTo(x, y2)
                        }
                    }
                    
                    drawPath(wavePath1, color = Color(0xFFFF00FF), style = Stroke(width = 3.dp.toPx()))
                    drawPath(wavePath2, color = Color(0xFF00FFFF), style = Stroke(width = 3.dp.toPx()))
                    
                    // Convergence / Laminar status
                    val centerColor = if (state.laminarParity) Color(0xFF00FF00) else Color(0xFFFF0000)
                    drawCircle(color = centerColor, radius = 10.dp.toPx(), center = Offset(w/2f, midY))
                }
            }
        }

        // STATE READOUTS
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            // METRICS
            Column(
                modifier = Modifier.weight(1f).background(Color(0xFF111111), RoundedCornerShape(8.dp)).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("[OPERATOR MANIFOLD]", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 14.sp)
                HorizontalDivider(color = Color(0xFF333333))
                Text("R₁: ${String.format("%.4f", state.R1)}", color = Color(0xFF00FF00), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                Text("R₂: ${String.format("%.4f", state.R2)}", color = Color(0xFF00FF00), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                Text("ΔE ∫P dt: ${String.format("%.4f", state.energyDelta)}", color = Color(0xFFFFA500), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                Text("Synthesis output: ${if (state.synthesisOutput.isNaN()) "NULLIFIED" else String.format("%.4f", state.synthesisOutput)}", color = Color(0xFF00d9ff), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            }
            
            // CONSTRAINTS
            Column(
                modifier = Modifier.weight(1f).background(Color(0xFF111111), RoundedCornerShape(8.dp)).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("[PARITY FIELD]", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 14.sp)
                HorizontalDivider(color = Color(0xFF333333))
                val parityColor = if (state.laminarParity) Color(0xFF00FF00) else Color.Red
                Text("Laminar Parity: ${if(state.laminarParity) "MAINTAINED" else "VIOLATION"}", color = parityColor, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                
                val manifoldColor = if (state.manifoldValid) Color(0xFF00FF00) else Color.Red
                Text("Manifold: ${if(state.manifoldValid) "VALID" else "EXCEEDED LIMITS"}", color = manifoldColor, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                
                Text("Equation [Q, P] = iħI : SATISFIED", color = Color.Gray, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                Text("Equation W⁺W = I   : SATISFIED", color = Color.Gray, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            }
        }
        
        // ALERTS / LOGS
        Column(
            modifier = Modifier.fillMaxWidth().background(Color(0xFF2B0000), RoundedCornerShape(8.dp)).padding(16.dp)
        ) {
            Text("DISALLOWANCE MATRIX & ALERTS", color = Color.Red, fontFamily = FontFamily.Monospace, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            HorizontalDivider(color = Color.Red)
            Spacer(modifier = Modifier.height(8.dp))
            if (state.warnings.isEmpty()) {
                Text("SYSTEM NOMINAL. NO DEVIATIONS DETECTED.", color = Color(0xFF00FF00), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            } else {
                state.warnings.forEach { warning ->
                    Text("! $warning", color = Color.Red, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                }
                Text("DISCLAIMER: 'Intelligent Lattice' will auto-rectify all unverified abstractions. Abstracted identity is null and void.", color = Color.Gray, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            }
        }
        
    }
}
