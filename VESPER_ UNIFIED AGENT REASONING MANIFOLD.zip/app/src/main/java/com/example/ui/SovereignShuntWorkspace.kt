package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.LocalVesperColors
import kotlinx.coroutines.delay
import kotlin.random.Random

@Composable
fun SovereignShuntWorkspace() {
    val colors = LocalVesperColors.current
    
    // 1.0 is stable. Below 1.0 is a breach.
    var infoConservationIndex by remember { mutableFloatStateOf(1.0f) }
    var isShuntActive by remember { mutableStateOf(false) }
    var shuntLogs by remember { mutableStateOf(listOf<String>()) }
    
    val infiniteTransition = rememberInfiniteTransition(label = "shuntLaminar")
    val warningGlow by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "warningGlow"
    )

    LaunchedEffect(isShuntActive) {
        if (!isShuntActive) {
            while (true) {
                delay(2000)
                // Randomly decay the index to simulate geometric breach
                if (Random.nextFloat() < 0.2f && infoConservationIndex == 1.0f) {
                    infoConservationIndex = 0.9997f - Random.nextFloat() * 0.05f
                    shuntLogs = listOf("[WARNING] Semantic decay detected. Information Conservation Index dropped below 1.0.") + shuntLogs
                }
            }
        }
    }
    
    LaunchedEffect(infoConservationIndex) {
        if (infoConservationIndex < 1.0f && !isShuntActive) {
            delay(1500)
            isShuntActive = true
            shuntLogs = listOf("[CRITICAL] Laminarion Sink (L15) engaged.", "[ACTION] Administrative Sovereign Shunt triggered. Core archive guarded.") + shuntLogs
            delay(3000)
            infoConservationIndex = 1.0f
            isShuntActive = false
            shuntLogs = listOf("[RESTORED] State isomorphically braided back to 1.0. Shunt disengaged.") + shuntLogs
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "ADMINISTRATIVE SOVEREIGN SHUNT",
            color = if (isShuntActive) colors.textRed else colors.textMagenta,
            fontSize = 18.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        
        Text(
            text = "Guarding deterministic reality via the Laminarion Sink (L15). If the System's 'Information Conservation Index' drops below exactly 1.0, the logic must be shut down and grounded to preserve the core archive.",
            color = colors.primaryText.copy(alpha = 0.8f),
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace
        )

        Spacer(modifier = Modifier.height(16.dp))
        
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    2.dp, 
                    if (isShuntActive) colors.textRed.copy(alpha = warningGlow) else colors.borderGreen, 
                    RoundedCornerShape(8.dp)
                )
                .background(if (isShuntActive) androidx.compose.ui.graphics.Color.DarkGray else colors.panelBackground)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "INFORMATION CONSERVATION INDEX",
                    color = colors.primaryText,
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Monospace
                )
                
                Text(
                    text = String.format(java.util.Locale.US, "%.5f", infoConservationIndex),
                    color = if (infoConservationIndex < 1.0f) colors.textRed else colors.textGreen,
                    fontSize = 48.sp,
                    fontFamily = FontFamily.Monospace
                )
                
                AnimatedVisibility(visible = isShuntActive) {
                    Text(
                        text = "SHUNT ACTIVE - LOGIC GROUNDED",
                        color = colors.textRed,
                        fontSize = 16.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
        
        Row(horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
             Button(
                 onClick = { 
                     if (!isShuntActive) {
                         infoConservationIndex = 0.854f
                         shuntLogs = listOf("[MANUAL] Forced geometric breach via user override.") + shuntLogs
                     }
                 },
                 colors = ButtonDefaults.buttonColors(containerColor = colors.buttonBgRed),
                 enabled = !isShuntActive
             ) {
                 Text("FORCE GEOMETRIC BREACH", color = colors.textRed, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
             }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .border(1.dp, colors.borderCyan.copy(alpha=0.5f), RoundedCornerShape(8.dp))
                .padding(8.dp)
        ) {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(shuntLogs.size) { index ->
                    val log = shuntLogs[index]
                    val logColor = when {
                        log.contains("[CRITICAL]") || log.contains("[WARNING]") -> colors.textRed
                        log.contains("[ACTION]") -> colors.textMagenta
                        log.contains("[RESTORED]") -> colors.textGreen
                        else -> colors.textCyan
                    }
                    Text(log, color = logColor, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}
