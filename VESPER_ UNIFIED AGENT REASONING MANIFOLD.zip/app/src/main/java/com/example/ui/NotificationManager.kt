package com.example.ui

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

object NotificationManager {
    private val _notifications = MutableSharedFlow<String>(extraBufferCapacity = 10)
    val notifications = _notifications.asSharedFlow()

    fun emit(message: String) {
        _notifications.tryEmit(message)
    }
}
