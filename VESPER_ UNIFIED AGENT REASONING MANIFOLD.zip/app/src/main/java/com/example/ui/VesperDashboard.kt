package com.example.ui

import androidx.compose.foundation.text.BasicTextField
import com.example.ui.theme.NeonCyberpunkColors
import com.example.ui.theme.DarkSlateTerminalColors
import com.example.ui.theme.OledRedBlackColors
import com.example.ui.theme.VesperTheme
import com.example.ui.theme.VesperThemeMode

import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.TextStyle
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Brush
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.IconButton
import com.example.ui.theme.LocalVesperColors
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.ui.text.style.TextAlign
import com.example.pinn.VesperConstants
import com.example.viewmodel.OracleViewModel
import com.example.VesperCoreViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import android.app.Application
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random
import com.example.ui.NotificationManager

@Composable
fun NotificationLayer() {
    var currentNotification by remember { mutableStateOf<String?>(null) }
    
    LaunchedEffect(Unit) {
        NotificationManager.notifications.collect { message ->
            currentNotification = message
            delay(4000)
            currentNotification = null
        }
    }
    
    AnimatedVisibility(
        visible = currentNotification != null,
        enter = fadeIn() + slideInVertically(initialOffsetY = { -80 }),
        exit = fadeOut() + slideOutVertically(targetOffsetY = { -80 }),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 32.dp)
    ) {
        if (currentNotification != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xD0200000), RoundedCornerShape(8.dp))
                    .border(1.dp, Color(0xFFFF4444), RoundedCornerShape(8.dp))
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = currentNotification!!,
                    color = Color(0xFFFF8888),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VesperOracleTerminal(
    modifier: Modifier = Modifier,
    oracleViewModel: OracleViewModel = viewModel(),
    manifoldState: String,
    selectedTab: Int = 0
) {
    val status by oracleViewModel.status.collectAsState()
    val generatedText by oracleViewModel.generatedText.collectAsState()

    var modelPathInput by remember { mutableStateOf("/data/local/tmp/gemma-2b-it-cpu-int4.bin") }
    var userQuery by remember { mutableStateOf("What is the current manifold frequency telling us?") }

    Column(modifier = modifier.fillMaxWidth().padding(8.dp)) {
        if (selectedTab == 0) {
            Text(
                text = "ORACLE TRANSDUCER (Gemma/Vesper)",
                color = LocalVesperColors.current.textMagenta,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Text(
                text = "Enter 'vesper' to use native simulation, or provide Gemma path.",
                color = LocalVesperColors.current.primaryText,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            OutlinedTextField(
                value = modelPathInput,
                onValueChange = { modelPathInput = it },
                label = { Text("Model Path (or 'vesper')", color = LocalVesperColors.current.primaryText.copy(alpha=0.6f), fontSize = 10.sp) },
                textStyle = androidx.compose.ui.text.TextStyle(color = LocalVesperColors.current.primaryText, fontFamily = FontFamily.Monospace, fontSize = 10.sp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = LocalVesperColors.current.textMagenta,
                    unfocusedBorderColor = LocalVesperColors.current.textMagenta.copy(alpha = 0.5f),
                ),
                modifier = Modifier.fillMaxWidth().height(60.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Button(
                onClick = { oracleViewModel.bindModel(modelPathInput) },
                colors = ButtonDefaults.buttonColors(containerColor = LocalVesperColors.current.buttonBgMagenta),
                modifier = Modifier.fillMaxWidth().height(36.dp)
            ) {
                Text("BIND MANIFOLD TO MODEL", color = LocalVesperColors.current.textMagenta, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(text = "Status: $status", color = LocalVesperColors.current.textGreen, fontSize = 10.sp, fontFamily = FontFamily.Monospace)

            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = userQuery,
                onValueChange = { userQuery = it },
                label = { Text("Query Vector", color = LocalVesperColors.current.primaryText.copy(alpha=0.6f), fontSize = 10.sp) },
                textStyle = androidx.compose.ui.text.TextStyle(color = LocalVesperColors.current.primaryText, fontFamily = FontFamily.Monospace, fontSize = 10.sp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = LocalVesperColors.current.textCyan,
                    unfocusedBorderColor = LocalVesperColors.current.textCyan.copy(alpha = 0.5f),
                ),
                modifier = Modifier.fillMaxWidth().height(60.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Button(
                onClick = { oracleViewModel.consult(userQuery, manifoldState) },
                colors = ButtonDefaults.buttonColors(containerColor = LocalVesperColors.current.buttonBgCyan),
                modifier = Modifier.fillMaxWidth().height(36.dp)
            ) {
                Text("CONSULT ORACLE", color = LocalVesperColors.current.textCyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }

            if (generatedText.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, LocalVesperColors.current.textMagenta.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = generatedText,
                        color = LocalVesperColors.current.primaryText,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp
                    )
                }
            }
        }

        if (modelPathInput.trim().equals("vesper", ignoreCase = true)) {
            if (selectedTab == 1) { // Engine & Optics
                Spacer(modifier = Modifier.height(16.dp))
                VesperAccordion(title = "MANIFOLD PARAMETERS", initiallyExpanded = true, statusColor = LocalVesperColors.current.textCyan) {
                    val temp by oracleViewModel.vesperTemperature.collectAsState()
                    val topK by oracleViewModel.vesperTopK.collectAsState()
                    val topP by oracleViewModel.vesperTopP.collectAsState()
                    val repPen by oracleViewModel.vesperRepPenalty.collectAsState()
                    val phaseHarm by oracleViewModel.vesperPhaseHarmonic.collectAsState()
                    
                    Column {
                        Row(modifier = Modifier.fillMaxWidth().padding(bottom = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Temperature: ${String.format(java.util.Locale.US, "%.2f", temp)}", color = LocalVesperColors.current.primaryText, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                        Slider(
                            value = temp,
                            onValueChange = { oracleViewModel.updateVesperParameters(it, topK, topP, repPen, phaseHarm) },
                            valueRange = 0.1f..2.0f,
                            modifier = Modifier.height(24.dp)
                        )
                        
                        Row(modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Top-K: $topK", color = LocalVesperColors.current.primaryText, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                        Slider(
                            value = topK.toFloat(),
                            onValueChange = { oracleViewModel.updateVesperParameters(temp, it.toInt(), topP, repPen, phaseHarm) },
                            valueRange = 1f..100f,
                            modifier = Modifier.height(24.dp)
                        )
                        
                        Row(modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Top-P: ${String.format(java.util.Locale.US, "%.2f", topP)}", color = LocalVesperColors.current.primaryText, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                        Slider(
                            value = topP,
                            onValueChange = { oracleViewModel.updateVesperParameters(temp, topK, it, repPen, phaseHarm) },
                            valueRange = 0.1f..1.0f,
                            modifier = Modifier.height(24.dp)
                        )
                        
                        Row(modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Repetition Penalty: ${String.format(java.util.Locale.US, "%.2f", repPen)}", color = LocalVesperColors.current.primaryText, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                        Slider(
                            value = repPen,
                            onValueChange = { oracleViewModel.updateVesperParameters(temp, topK, topP, it, phaseHarm) },
                            valueRange = 1.0f..2.0f,
                            modifier = Modifier.height(24.dp)
                        )

                        Row(modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Phase Harmonic (νp): ${String.format(java.util.Locale.US, "%.5f", phaseHarm)}", color = LocalVesperColors.current.primaryText, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                        Slider(
                            value = phaseHarm,
                            onValueChange = { oracleViewModel.updateVesperParameters(temp, topK, topP, repPen, it) },
                            valueRange = 0.0f..1.0f,
                            modifier = Modifier.height(24.dp)
                        )
                    }
                }
                
                EngineWorkspace(oracleViewModel)
            } else if (selectedTab == 2) {
                MeshWorkspace(oracleViewModel)
            } else if (selectedTab == 3) {
                SystemWorkspace(oracleViewModel)
            } else if (selectedTab == 4) {
                VisualsWorkspace(oracleViewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VesperTerminalSection(
    modifier: Modifier = Modifier,
    onCommandSelected: (String) -> Unit
) {
    val cliCommands = remember {
        listOf(
            "/search <query>", "/fast <query>", "/think <query>", "/parse <eq>", "/weights",
            "/save_session <name>", "/history", "/invariants", "/equations", "/tensors", "/cef <text>",
            "/pinn <epochs> <equation>", "/rk", "/fusion", "/latent", "/sheaf",
            "/ab01", "/somatic", "/macena_sim", "/search_alts", "/ddg <query>", "/serp_api <query>", "/braid_translate <intent>",
            "/physics <equation>", "/ssn",
            "/lullian", "/gnomon", "/codex", "/compendium", "/genesis", "/axiomatics", "/induction", "/evaluate", "/neuro"
        )
    }
    
    val physicalTemplates = remember {
        listOf(
            "Harmonic Oscillator" to "/pinn 500 u_tt + u_xx = 0",
            "Navier-Stokes (Fluid Dynamics)" to "/pinn 1000 u_t + u*u_x + v*u_y + p_x - (1/Re)*(u_xx + u_yy) = 0",
            "Schrodinger (Quantum)" to "/pinn 1000 i*u_t + 0.5*u_xx + |u|^2*u = 0",
            "Burgers' Equation (Fluid)" to "/pinn 500 u_t + u*u_x - (0.01/pi)*u_xx = 0",
            "Wave Equation" to "/pinn 500 u_tt - c^2*u_xx = 0",
            "KdV Equation (Solitons)" to "/pinn 1000 u_t + 6*u*u_x + u_xxx = 0",
            "Quantum D-Wave Annealing" to "/pinn 2000 H(s) = A(s)*H_X + B(s)*H_P"
        )
    }
    
    var isDropdownExpanded by remember { mutableStateOf(false) }
    var isTemplateDropdownExpanded by remember { mutableStateOf(false) }
    var localTerminalOutput by remember { mutableStateOf(listOf<String>()) }
    val coroutineScope = rememberCoroutineScope()

    Column(modifier = modifier) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            // CLI Commands Dropdown
            Box(modifier = Modifier.weight(1f)) {
                OutlinedTextField(
                    value = "CLI Commands...",
                    onValueChange = {},
                    readOnly = true,
                    trailingIcon = {
                        IconButton(onClick = { isDropdownExpanded = true }) {
                            Icon(Icons.Default.ArrowDropDown, contentDescription = "Expand", tint = LocalVesperColors.current.textCyan)
                        }
                    },
                    textStyle = androidx.compose.ui.text.TextStyle(color = LocalVesperColors.current.primaryText, fontFamily = FontFamily.Monospace),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = LocalVesperColors.current.textCyan,
                        unfocusedBorderColor = LocalVesperColors.current.textCyan.copy(alpha = 0.5f),
                        focusedContainerColor = LocalVesperColors.current.background.copy(alpha = 0.3f),
                        unfocusedContainerColor = LocalVesperColors.current.background.copy(alpha = 0.3f),
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .clickable { isDropdownExpanded = true }
                )
                DropdownMenu(
                    expanded = isDropdownExpanded,
                    onDismissRequest = { isDropdownExpanded = false },
                    modifier = Modifier.background(LocalVesperColors.current.background.copy(alpha = 0.9f)).border(1.dp, LocalVesperColors.current.textCyan.copy(alpha = 0.3f)).heightIn(max = 300.dp)
                ) {
                    cliCommands.forEach { command ->
                        DropdownMenuItem(
                            text = { Text(command, color = LocalVesperColors.current.textCyan, fontFamily = FontFamily.Monospace, fontSize = 12.sp) },
                            onClick = {
                                localTerminalOutput = localTerminalOutput + "> root@vesper:~$ $command"
                                coroutineScope.launch {
                                    delay(300)
                                    localTerminalOutput = localTerminalOutput + "  [SYSTEM] Parsing tensor request..."
                                    delay(500)
                                    localTerminalOutput = localTerminalOutput + "  [COMPUTE] Executing sub-dimensional fold along manifold..."
                                    delay(400)
                                    localTerminalOutput = localTerminalOutput + "  [RESULT] Equation yields invariant stability against f₀=15.965"
                                }
                                onCommandSelected(command)
                                isDropdownExpanded = false
                            }
                        )
                    }
                }
            }

            // Physical Templates Dropdown
            Box(modifier = Modifier.weight(1f)) {
                OutlinedTextField(
                    value = "System Templates...",
                    onValueChange = {},
                    readOnly = true,
                    trailingIcon = {
                        IconButton(onClick = { isTemplateDropdownExpanded = true }) {
                            Icon(Icons.Default.ArrowDropDown, contentDescription = "Expand", tint = LocalVesperColors.current.textGreen)
                        }
                    },
                    textStyle = androidx.compose.ui.text.TextStyle(color = LocalVesperColors.current.primaryText, fontFamily = FontFamily.Monospace),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = LocalVesperColors.current.textGreen,
                        unfocusedBorderColor = LocalVesperColors.current.textGreen.copy(alpha = 0.5f),
                        focusedContainerColor = LocalVesperColors.current.background.copy(alpha = 0.3f),
                        unfocusedContainerColor = LocalVesperColors.current.background.copy(alpha = 0.3f),
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .clickable { isTemplateDropdownExpanded = true }
                )
                DropdownMenu(
                    expanded = isTemplateDropdownExpanded,
                    onDismissRequest = { isTemplateDropdownExpanded = false },
                    modifier = Modifier.background(LocalVesperColors.current.background.copy(alpha = 0.9f)).border(1.dp, LocalVesperColors.current.textGreen.copy(alpha = 0.3f)).heightIn(max = 300.dp)
                ) {
                    physicalTemplates.forEach { (name, command) ->
                        DropdownMenuItem(
                            text = { Text(name, color = LocalVesperColors.current.textGreen, fontFamily = FontFamily.Monospace, fontSize = 12.sp) },
                            onClick = {
                                localTerminalOutput = localTerminalOutput + "> root@vesper:~$ LOAD TEMPLATE: $name"
                                coroutineScope.launch {
                                    delay(300)
                                    localTerminalOutput = localTerminalOutput + "  [SYSTEM] Injecting physics logic..."
                                    delay(500)
                                    localTerminalOutput = localTerminalOutput + "  > $command"
                                }
                                onCommandSelected(command)
                                isTemplateDropdownExpanded = false
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (localTerminalOutput.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 120.dp)
                    .border(1.dp, Brush.linearGradient(listOf(LocalVesperColors.current.primaryText.copy(alpha = 0.3f), LocalVesperColors.current.primaryText.copy(alpha = 0.1f))), RoundedCornerShape(8.dp))
                    .background(LocalVesperColors.current.background.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                    .padding(8.dp)
            ) {
                LazyColumn {
                    items(localTerminalOutput) { line ->
                        Text(line, color = LocalVesperColors.current.textGreen, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VesperDashboard(
    modifier: Modifier = Modifier,
    isInPipMode: Boolean = false,
    vesperViewModel: VesperCoreViewModel = androidx.lifecycle.viewmodel.compose.viewModel(),
    onCommandSelected: (String) -> Unit = {}
) {
    val themeMode by vesperViewModel.themeMode.collectAsState()
    val colors = when(themeMode) {
        VesperThemeMode.NEON -> NeonCyberpunkColors
        VesperThemeMode.SLATE -> DarkSlateTerminalColors
        VesperThemeMode.OLED -> OledRedBlackColors
    }

    VesperTheme(colors = colors) {
        val targetF0 by vesperViewModel.targetF0.collectAsState()
    val targetPhi by vesperViewModel.targetPhi.collectAsState()
    val targetDeltaPhi by vesperViewModel.targetDeltaPhi.collectAsState()
    val targetTau by vesperViewModel.targetTau.collectAsState()

    // GSAP-like smooth physics
    val animSpec = spring<Float>(dampingRatio = 0.5f, stiffness = 50f)
    val f0State = animateFloatAsState(targetValue = targetF0, animationSpec = animSpec, label = "f0")
    val phiState = animateFloatAsState(targetValue = targetPhi, animationSpec = animSpec, label = "phi")
    val deltaPhiState = animateFloatAsState(targetValue = targetDeltaPhi, animationSpec = animSpec, label = "deltaPhi")
    val tauState = animateFloatAsState(targetValue = targetTau, animationSpec = animSpec, label = "tau")

    val heartbeatTransition = rememberInfiniteTransition(label = "heartbeat")
    val heartbeatGlowState = heartbeatTransition.animateColor(
        initialValue = LocalVesperColors.current.background.copy(alpha = 0.8f),
        targetValue = LocalVesperColors.current.panelBackground.copy(alpha = 0.9f),
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "heartbeatPulse"
    )
    
    var isSidebarOpen by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .drawBehind { drawRect(heartbeatGlowState.value) }
    ) {
        // Fullscreen visualizer
        val offset = (f0State.value - VesperConstants.F0_HZ.toFloat())
        val offsetIntensity = (kotlin.math.abs(offset) * 35f).coerceIn(0f, 1f)
        
        Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            VesperManifoldVisualizer(modifier = Modifier.weight(1f).fillMaxWidth(), offsetIntensity = offsetIntensity)
            Spacer(modifier = Modifier.height(16.dp))
            PhaseLockIndicator(offset = offset)
            Spacer(modifier = Modifier.height(32.dp))
        }

        // Overlay glassmorphic sidebar
        if (!isInPipMode) {
            Row(modifier = Modifier.fillMaxSize()) {
                androidx.compose.animation.AnimatedVisibility(
                    visible = isSidebarOpen,
                    enter = androidx.compose.animation.expandHorizontally(expandFrom = Alignment.End),
                    exit = androidx.compose.animation.shrinkHorizontally(shrinkTowards = Alignment.End)
                ) {
                    Column(
                        modifier = Modifier
                            .width(360.dp)
                            .fillMaxHeight()
                            .background(LocalVesperColors.current.panelBackground.copy(alpha = 0.6f))
                            .border(1.dp, Brush.linearGradient(listOf(LocalVesperColors.current.textCyan.copy(alpha = 0.3f), Color.Transparent)), RoundedCornerShape(16.dp))
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "VESPER HUD",
                            color = LocalVesperColors.current.textCyan,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(bottom = 16.dp)
                        )
                        
                        var selectedWorkspace by remember { mutableIntStateOf(0) }
                        
                        ScrollableTabRow(
                            selectedTabIndex = selectedWorkspace,
                            containerColor = Color.Transparent,
                            divider = { HorizontalDivider(color = LocalVesperColors.current.dividerColor) },
                            edgePadding = 0.dp,
                            indicator = { tabPositions ->
                                TabRowDefaults.SecondaryIndicator(
                                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedWorkspace]),
                                    color = LocalVesperColors.current.textCyan
                                )
                            }
                        ) {
                            listOf("Terminal", "Engine", "Mesh", "System", "Visuals", "Search", "Gallery", "VMAL", "SDML", "Analytics", "E8 Lattice", "Braid Trace", "UARM", "Shunt", "Sources", "Git Repo").forEachIndexed { index, title ->
                                Tab(
                                    selected = selectedWorkspace == index,
                                    onClick = { selectedWorkspace = index },
                                    text = { Text(title, fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = if (selectedWorkspace == index) LocalVesperColors.current.textCyan else LocalVesperColors.current.primaryText) }
                                )
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(16.dp))

                        Box(modifier = Modifier.weight(1f)) {
                            when (selectedWorkspace) {
                                0 -> {
                                    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                                    // Terminal Workspace
                                    // High level stats
                                    VesperAccordion(title = "CORE VIBRATION", statusColor = LocalVesperColors.current.textCyan, initiallyExpanded = true) {
                                        ConstantCard(label = "Aperiodic Heartbeat", symbol = "f₀", value = String.format(java.util.Locale.US, "%.4f Hz", f0State.value))
                                        Spacer(modifier = Modifier.height(8.dp))
                                        ConstantCard(label = "Golden Ratio", symbol = "φ", value = String.format(java.util.Locale.US, "%.9f", phiState.value))
                                        Spacer(modifier = Modifier.height(8.dp))
                                        ConstantCard(label = "Tulsa Phase Delta", symbol = "ΔΦ", value = String.format(java.util.Locale.US, "%.8f", deltaPhiState.value))
                                    }
                                    
                                    Spacer(modifier = Modifier.height(8.dp))
                                    
                                    val metricCharging by vesperViewModel.metricCharging.collectAsState()
                                    val isomorphismValid by vesperViewModel.isomorphismValid.collectAsState()
                                    val hallucinationDecay by vesperViewModel.hallucinationDecay.collectAsState()
                                    val resonanceOutput by vesperViewModel.resonanceOutput.collectAsState()
                                    
                                    VesperAccordion(title = "UNIFIED VALIDATION", statusColor = LocalVesperColors.current.textGreen) {
                                        ConstantCard(label = "Thermodynamic Decay", symbol = "THD", value = String.format(java.util.Locale.US, "%.2f%%", hallucinationDecay * 100))
                                        Spacer(modifier = Modifier.height(8.dp))
                                        ConstantCard(label = "Material Isomorphism", symbol = "Iso", value = if (isomorphismValid) "LOCKED" else "SEEKING")
                                        Spacer(modifier = Modifier.height(8.dp))
                                        ConstantCard(label = "Metric Charging (Δg₀₀)", symbol = "Δg", value = String.format(java.util.Locale.US, "%.5f", metricCharging))
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))
                                    
                                    Box(modifier = Modifier.height(200.dp)) {
                                        VesperTerminalSection(onCommandSelected = onCommandSelected)
                                    }
                                    Spacer(modifier = Modifier.height(16.dp))
                                    
                                    val manifoldEnergy by vesperViewModel.manifoldEnergy.collectAsState()
                                    VesperOracleTerminal(manifoldState = "f0=${f0State.value}, Ψ=${resonanceOutput}, E=${manifoldEnergy}", selectedTab = 0)
                                    }
                                }
                                1 -> {
                                    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                                        val resonanceOutput by vesperViewModel.resonanceOutput.collectAsState()
                                        val manifoldEnergy by vesperViewModel.manifoldEnergy.collectAsState()
                                        VesperOracleTerminal(manifoldState = "f0=${f0State.value}, Ψ=${resonanceOutput}, E=${manifoldEnergy}", selectedTab = 1)
                                    }
                                }
                                2 -> {
                                    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                                        val resonanceOutput by vesperViewModel.resonanceOutput.collectAsState()
                                        val manifoldEnergy by vesperViewModel.manifoldEnergy.collectAsState()
                                        VesperOracleTerminal(manifoldState = "f0=${f0State.value}, Ψ=${resonanceOutput}, E=${manifoldEnergy}", selectedTab = 2)
                                    }
                                }
                                3 -> {
                                    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                                        val resonanceOutput by vesperViewModel.resonanceOutput.collectAsState()
                                        val manifoldEnergy by vesperViewModel.manifoldEnergy.collectAsState()
                                        VesperOracleTerminal(manifoldState = "f0=${f0State.value}, Ψ=${resonanceOutput}, E=${manifoldEnergy}", selectedTab = 3)
                                    }
                                }
                                4 -> {
                                    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                                        val resonanceOutput by vesperViewModel.resonanceOutput.collectAsState()
                                        val manifoldEnergy by vesperViewModel.manifoldEnergy.collectAsState()
                                        VesperOracleTerminal(manifoldState = "f0=${f0State.value}, Ψ=${resonanceOutput}, E=${manifoldEnergy}", selectedTab = 4)
                                    }
                                }
                                5 -> {
                                    PhysicsSearchScreen(modifier = Modifier.fillMaxSize())
                                }
                                6 -> {
                                    GlyphGalleryScreen(modifier = Modifier.fillMaxSize())
                                }
                                7 -> {
                                    VmalPlaygroundScreen(modifier = Modifier.fillMaxSize())
                                }
                                8 -> {
                                    SDMLGraphIntegrationScreen(modifier = Modifier.fillMaxSize())
                                }
                                9 -> {
                                    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                                        PerformanceWorkspace()
                                    }
                                }
                                10 -> {
                                    E8LatticeWorkspace()
                                }
                                11 -> {
                                    ReversibleBraidWorkspace()
                                }
                                12 -> {
                                    UARMSchedulerWorkspace()
                                }
                                13 -> {
                                    SovereignShuntWorkspace()
                                }
                                14 -> {
                                    CanonicalSourcesWorkspace()
                                }
                                15 -> {
                                    GitIntegrationWorkspace()
                                }
                            }
                        }
                    }
                }
                
                // Toggle Button
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .padding(start = 8.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    IconButton(
                        onClick = { isSidebarOpen = !isSidebarOpen },
                        modifier = Modifier
                            .background(LocalVesperColors.current.textCyan.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                            .border(1.dp, LocalVesperColors.current.textCyan.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                    ) {
                        Icon(
                            imageVector = if (isSidebarOpen) Icons.AutoMirrored.Filled.List else Icons.Default.Menu,
                            contentDescription = "Toggle Sidebar",
                            tint = LocalVesperColors.current.textCyan
                        )
                    }
                }
            }
        }
        
        NotificationLayer()
    }
}
}

@Composable
fun ConstantCard(label: String, symbol: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Brush.linearGradient(listOf(LocalVesperColors.current.primaryText.copy(alpha = 0.3f), LocalVesperColors.current.primaryText.copy(alpha = 0.1f))), RoundedCornerShape(12.dp))
            .background(LocalVesperColors.current.primaryText.copy(alpha = 0.05f), RoundedCornerShape(12.dp))
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(
                text = symbol,
                color = LocalVesperColors.current.textGreen.copy(alpha = 0.8f),
                fontFamily = FontFamily.Monospace,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = label,
                color = LocalVesperColors.current.primaryText.copy(alpha = 0.7f),
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp
            )
        }
        Text(
            text = value,
            color = LocalVesperColors.current.textCyan,
            fontFamily = FontFamily.Monospace,
            fontSize = 14.sp
        )
    }
}

@Composable
fun PhaseLockIndicator(offset: Float = 0f) {
    val infiniteTransition = rememberInfiniteTransition(label = "phaseLock")
    
    // Inject dynamic turbulence based on offset to simulate organic phase variance
    val offsetIntensity = (kotlin.math.abs(offset) * 35f).coerceIn(0f, 1f)

    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    val ringScale by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ringScale"
    )

    // GSAP-like secondary reactive animation
    val reactiveRingScale by animateFloatAsState(
        targetValue = ringScale + offsetIntensity * 0.15f,
        animationSpec = spring(dampingRatio = 0.4f, stiffness = 60f),
        label = "reactiveScale"
    )

    // Dynamic color shift
    val indicatorColor by animateColorAsState(
        targetValue = if (offsetIntensity > 0.6f) LocalVesperColors.current.textRed else LocalVesperColors.current.textCyan,
        animationSpec = spring(dampingRatio = 0.8f),
        label = "indicatorColor"
    )
    val indicatorBgColor by animateColorAsState(
        targetValue = if (offsetIntensity > 0.6f) LocalVesperColors.current.buttonBgRed.copy(alpha = 0.5f) else LocalVesperColors.current.buttonBgCyan.copy(alpha = 0.5f),
        animationSpec = spring(dampingRatio = 0.8f),
        label = "indicatorBgColor"
    )

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(120.dp)
                .background(Color.Transparent),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2, size.height / 2)
                val baseRadius = 40.dp.toPx()
                
                // Outer pulsing ring
                drawCircle(
                    color = indicatorColor.copy(alpha = pulseAlpha * 0.5f),
                    radius = baseRadius * reactiveRingScale,
                    center = center,
                    style = Stroke(width = 2.dp.toPx())
                )
                
                // Inner solid core
                drawCircle(
                    color = indicatorBgColor,
                    radius = baseRadius * 0.6f,
                    center = center
                )
            }
            Text(
                text = if (offsetIntensity > 0.6f) "SYNCING" else "LOCKED",
                color = LocalVesperColors.current.primaryText,
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = if (offsetIntensity > 0.6f) "PHASE-LOCK: RE-ALIGNING" else "PHASE-LOCK: STABLE",
            color = indicatorColor,
            fontFamily = FontFamily.Monospace,
            fontSize = 14.sp,
            letterSpacing = 1.sp
        )
        Text(
            text = String.format(java.util.Locale.US, "Tuning Offset: %+.5f Hz", offset),
            color = LocalVesperColors.current.primaryText.copy(alpha = 0.6f),
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
fun KhysAttentionVisualizer(weights: List<Float>, modifier: Modifier = Modifier) {
    val textYellow = LocalVesperColors.current.textYellow
    val textCyan = LocalVesperColors.current.textCyan
    Canvas(modifier = modifier) {
        val nodeCount = 8 // Assume 8x8 matrix for 64 weights
        val radius = size.minDimension / 2.5f
        val center = Offset(size.width / 2, size.height / 2)
        
        // Draw nodes
        val nodePositions = List(nodeCount) { i ->
            val angle = (i.toFloat() / nodeCount) * 2 * Math.PI
            Offset(
                x = center.x + kotlin.math.cos(angle).toFloat() * radius,
                y = center.y + kotlin.math.sin(angle).toFloat() * radius
            )
        }
        
        // Draw stochastic 91-degree connections
        for (i in 0 until nodeCount) {
            for (j in 0 until nodeCount) {
                if (i != j) {
                    val weight = weights.getOrNull(i * nodeCount + j) ?: 0f
                    if (weight > 0.4f) { // Sparsity threshold
                        drawLine(
                            color = textYellow.copy(alpha = weight),
                            start = nodePositions[i],
                            end = nodePositions[j],
                            strokeWidth = weight * 4f
                        )
                    }
                }
            }
        }
        // Draw nodes on top
        nodePositions.forEach { pos ->
            drawCircle(textCyan, radius = 4.dp.toPx(), center = pos)
        }
    }
}
