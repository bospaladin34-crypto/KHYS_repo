package com.example.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

import androidx.compose.ui.platform.LocalContext
import java.io.InputStreamReader
import java.io.BufferedReader

@Composable
fun VesperManifoldVisualizer(modifier: Modifier = Modifier, offsetIntensity: Float = 0f, fpsDelay: Long = 16L) {
    val context = LocalContext.current
    
    var points by remember { mutableStateOf<List<Triple<Float, Float, Float>>>(emptyList()) }

    LaunchedEffect(Unit) {
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            // Load real points from the datasets
            val erdosPoints = try {
                context.assets.open("nephilim_repo/points_erdos_100.csv").bufferedReader().use { reader ->
                    reader.readLines().drop(1).mapNotNull { line ->
                        val parts = line.split(",")
                        if (parts.size == 3) {
                            Triple(parts[0].toFloat(), parts[1].toFloat(), parts[2].toFloat())
                        } else null
                    }
                }
            } catch (e: Exception) {
                emptyList()
            }
            
            val nephilimPoints = try {
                context.assets.open("nephilim_repo/points_nephilim_100.csv").bufferedReader().use { reader ->
                    reader.readLines().drop(1).mapNotNull { line ->
                        val parts = line.split(",")
                        if (parts.size == 3) {
                            Triple(parts[0].toFloat(), parts[1].toFloat(), parts[2].toFloat())
                        } else null
                    }
                }
            } catch (e: Exception) {
                emptyList()
            }

            val merged = erdosPoints + nephilimPoints
            points = if (merged.isNotEmpty()) {
                merged.map { (x, y, z) ->
                    // Normalize points because raw CSV has coordinate values up to 250
                    Triple(x / 150f, y / 150f, z / 150f)
                }
            } else {
                List(256) {
                    val theta = Random.nextFloat() * 2 * Math.PI
                    val phi = Random.nextFloat() * Math.PI
                    val radius = 0.5 + Random.nextFloat() * 0.5
                    Triple((radius * sin(phi) * cos(theta)).toFloat(), (radius * sin(phi) * sin(theta)).toFloat(), (radius * cos(phi)).toFloat())
                }
            }
        }
    }

    val animationsEnabled = LocalAnimationsEnabled.current
    var time by remember { mutableStateOf(0f) }

    LaunchedEffect(animationsEnabled, fpsDelay) {
        if (!animationsEnabled) return@LaunchedEffect
        while (true) {
            val t = time + 0.02f
            time = t
            kotlinx.coroutines.delay(fpsDelay)
        }
    }

    val reactColor by animateColorAsState(
        targetValue = if (offsetIntensity > 0.6f) Color(0xFFB84A2A) else Color(0xFF2A3620),
        animationSpec = spring(dampingRatio = 0.8f),
        label = "reactColor"
    )

    val reactStroke by animateColorAsState(
        targetValue = if (offsetIntensity > 0.6f) Color(0xFF8C2626) else Color(0xFF556B2F),
        animationSpec = spring(dampingRatio = 0.8f),
        label = "reactStroke"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFFC0B398), RoundedCornerShape(8.dp))
            .background(Color(0xFFEBE1C7), RoundedCornerShape(8.dp))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "7,777-BIT MANIFOLD PROJECTION",
            color = Color(0xFF5C5248),
            fontFamily = FontFamily.Serif,
            fontSize = 12.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2, size.height / 2)
            val scale = size.minDimension / 2.5f
            val t = time

            // Draw points
            points.forEach { (x, y, z) ->
                val rotX = x * cos(t) - z * sin(t)
                val newZ = x * sin(t) + z * cos(t)

                val rotY = y * cos(t * 0.5f) - newZ * sin(t * 0.5f)
                val finalZ = y * sin(t * 0.5f) + newZ * cos(t * 0.5f)

                val perspective = 2.0f / (2.0f - finalZ)
                val projX = rotX * perspective
                val projY = rotY * perspective
                val depthAlpha = ((finalZ + 1.0f) / 2.0f).coerceIn(0.1f, 1.0f)
                val sizeAndAlpha = depthAlpha * perspective

                drawCircle(
                    color = reactColor.copy(alpha = sizeAndAlpha),
                    radius = 2.dp.toPx() * (sizeAndAlpha / ((sizeAndAlpha + 1.0f) / 2.0f)), // approx depth
                    center = Offset(center.x + projX * scale, center.y + projY * scale)
                )
            }
            
            // Draw connecting web for aesthetic 
            val limit = kotlin.math.min(100, points.size - 1)
            for (i in 0 until limit step 2) {
                 val (x1, y1, z1) = points[i]
                 val (x2, y2, z2) = points[i+1]
                 
                 val nx1 = x1 * cos(t) - z1 * sin(t)
                 val nz1 = x1 * sin(t) + z1 * cos(t)
                 val ny1 = y1 * cos(t * 0.5f) - nz1 * sin(t * 0.5f)
                 val fnz1 = y1 * sin(t * 0.5f) + nz1 * cos(t * 0.5f)
                 val p1 = 2.0f / (2.0f - fnz1)
                 val px1 = nx1 * p1
                 val py1 = ny1 * p1
                 
                 val nx2 = x2 * cos(t) - z2 * sin(t)
                 val nz2 = x2 * sin(t) + z2 * cos(t)
                 val ny2 = y2 * cos(t * 0.5f) - nz2 * sin(t * 0.5f)
                 val fnz2 = y2 * sin(t * 0.5f) + nz2 * cos(t * 0.5f)
                 val p2 = 2.0f / (2.0f - fnz2)
                 val px2 = nx2 * p2
                 val py2 = ny2 * p2
                 
                 drawLine(
                     color = reactStroke.copy(alpha = 0.3f),
                     start = Offset(center.x + px1 * scale, center.y + py1 * scale),
                     end = Offset(center.x + px2 * scale, center.y + py2 * scale),
                     strokeWidth = 1f
                 )
            }
        }
    }
}
