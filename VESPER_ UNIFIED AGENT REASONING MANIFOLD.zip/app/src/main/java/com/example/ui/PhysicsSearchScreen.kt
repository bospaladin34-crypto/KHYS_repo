package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.LocalVesperColors
import com.example.viewmodel.PhysicsSearchViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhysicsSearchScreen(
    modifier: Modifier = Modifier,
    viewModel: PhysicsSearchViewModel = viewModel()
) {
    var searchQuery by remember { mutableStateOf("") }
    val searchStatus by viewModel.searchStatus.collectAsState()
    val searchResult by viewModel.searchResult.collectAsState()

    Column(modifier = modifier.fillMaxSize().padding(16.dp)) {
        Text(
            text = "PHYSICS GRAPH ORACLE",
            color = LocalVesperColors.current.textCyan,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Text(
            text = "Enter a physics law, property, or universal constant to fetch ground-truth definitions and mathematical formulas.",
            color = LocalVesperColors.current.primaryText.copy(alpha = 0.8f),
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        Text(
            text = "Status: $searchStatus",
            color = LocalVesperColors.current.textGreen,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (searchResult.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(LocalVesperColors.current.panelBackground.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    .border(1.dp, LocalVesperColors.current.textCyan.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    item {
                        Text(
                            text = searchResult,
                            color = LocalVesperColors.current.primaryText,
                            fontSize = 13.sp,
                            lineHeight = 20.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
