package com.example.ui

import androidx.compose.runtime.compositionLocalOf

val LocalAnimationsEnabled = compositionLocalOf { true }
