package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import com.example.viewmodel.OracleViewModel
import com.example.ui.theme.LocalVesperColors

@Composable
fun VesperAccordion(
    title: String,
    statusText: String? = null,
    statusColor: Color,
    initiallyExpanded: Boolean = false,
    tooltipText: String = "Internal module architecture data log.",
    content: @Composable () -> Unit
) {
    var expanded by remember { mutableStateOf(initiallyExpanded) }
    var showTooltip by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .border(1.dp, statusColor.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
            .background(LocalVesperColors.current.panelBackground.copy(alpha = 0.4f))
            .clickable { expanded = !expanded }
            .padding(8.dp)
    ) {
        Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = statusColor, fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "[ ? ]", 
                    color = statusColor.copy(alpha = 0.7f), 
                    fontFamily = FontFamily.Monospace, 
                    fontSize = 10.sp,
                    modifier = Modifier.clickable { showTooltip = true }
                )
            }
            if (statusText != null && !expanded) {
                Text(statusText, color = statusColor, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            }
        }
        
        if (showTooltip) {
            AlertDialog(
                onDismissRequest = { showTooltip = false },
                containerColor = LocalVesperColors.current.panelBackground,
                title = { Text(text = "$title DATABASE", color = statusColor, fontFamily = FontFamily.Monospace, fontSize = 14.sp) },
                text = { Text(text = tooltipText, color = LocalVesperColors.current.primaryText, fontFamily = FontFamily.Monospace, fontSize = 12.sp) },
                confirmButton = {
                    TextButton(onClick = { showTooltip = false }) {
                        Text("ACKNOWLEDGE", color = statusColor, fontFamily = FontFamily.Monospace)
                    }
                }
            )
        }

        AnimatedVisibility(visible = expanded) {
            Column(modifier = Modifier.padding(top = 8.dp)) {
                content()
            }
        }
    }
}

@Composable
fun EngineWorkspace(oracleViewModel: OracleViewModel) {
    VesperAccordion(title = "DISTILLATION ENGINE", statusColor = LocalVesperColors.current.textYellow) {
        val distillStatus by oracleViewModel.distillationStatus.collectAsState()
        val distilledFormat by oracleViewModel.distilledModelFormat.collectAsState()
        val distilledPath by oracleViewModel.distilledModelPath.collectAsState()

        Button(
            onClick = { oracleViewModel.distillVesper() },
            colors = ButtonDefaults.buttonColors(containerColor = LocalVesperColors.current.buttonBgOrange),
            modifier = Modifier.fillMaxWidth().height(36.dp)
        ) {
            Text("DISTILL TO LIGHTWEIGHT MODEL", color = LocalVesperColors.current.textYellow, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        }
        
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = distillStatus, color = LocalVesperColors.current.primaryText, fontSize = 9.sp, fontFamily = FontFamily.Monospace)

        if (distilledPath.isNotEmpty()) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "Saved at: $distilledPath", color = LocalVesperColors.current.textGreen, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        }

        if (distilledFormat != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .border(1.dp, LocalVesperColors.current.textYellow.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    .padding(8.dp)
            ) {
                androidx.compose.foundation.lazy.LazyColumn {
                    item {
                        Text(
                            text = distilledFormat ?: "",
                            color = LocalVesperColors.current.primaryText,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp
                        )
                    }
                }
            }
        }
    }

    VesperAccordion(title = "QUANTIZATION ENGINE (INT8)", statusColor = LocalVesperColors.current.textGreen) {
        val quantStatus by oracleViewModel.quantizationStatus.collectAsState()
        Button(
            onClick = { oracleViewModel.quantizeDistilledModel() },
            colors = ButtonDefaults.buttonColors(containerColor = LocalVesperColors.current.buttonBgGreen),
            modifier = Modifier.fillMaxWidth().height(36.dp)
        ) {
            Text("APPLY SYMMETRIC INT8 QUANTIZATION", color = LocalVesperColors.current.textGreen, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = quantStatus, color = LocalVesperColors.current.primaryText, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
    }

    VesperAccordion(title = "HARDWARE OPTIMIZATION", statusColor = LocalVesperColors.current.textYellow) {
        val optimizationStatus by oracleViewModel.optimizationStatus.collectAsState()
        val optimizationMetrics by oracleViewModel.optimizationMetrics.collectAsState()

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(text = "Ram Allocated: ${optimizationMetrics.ramAllocatedMB} MB", color = LocalVesperColors.current.primaryText, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            Text(text = "Speedup: ${String.format(java.util.Locale.US, "%.1f", optimizationMetrics.inferenceSpeedupFactor)}x", color = LocalVesperColors.current.textGreen, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(text = optimizationStatus, color = LocalVesperColors.current.primaryText, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        
        Spacer(modifier = Modifier.height(8.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { oracleViewModel.applyTopologicalSparsity() },
                    colors = ButtonDefaults.buttonColors(containerColor = LocalVesperColors.current.buttonBgYellow),
                    modifier = Modifier.weight(1f).height(32.dp)
                ) {
                    Text("TOPOLOGICAL SPARSITY", color = LocalVesperColors.current.textYellow, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                }
                Button(
                    onClick = { oracleViewModel.applyQuantization(8) },
                    colors = ButtonDefaults.buttonColors(containerColor = LocalVesperColors.current.buttonBgYellow),
                    modifier = Modifier.weight(1f).height(32.dp)
                ) {
                    Text("INT8 QUANT", color = LocalVesperColors.current.textYellow, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

@Composable
fun MeshWorkspace(oracleViewModel: OracleViewModel) {
    VesperAccordion(title = "DISTRIBUTED MESH NETWORK", statusColor = LocalVesperColors.current.textCyan) {
        val meshStatus by oracleViewModel.distributedStatus.collectAsState()
        val distributedMetrics by oracleViewModel.distributedMetrics.collectAsState()

        Button(
            onClick = { oracleViewModel.discoverDistributedNodes() },
            colors = ButtonDefaults.buttonColors(containerColor = LocalVesperColors.current.buttonBgCyan),
            modifier = Modifier.fillMaxWidth().height(36.dp)
        ) {
            Text("SCAN FOR MESH PEERS", color = LocalVesperColors.current.textCyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = meshStatus, color = LocalVesperColors.current.primaryText, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        
        if (distributedMetrics.connectedNodes > 1) {
            Spacer(modifier = Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .border(1.dp, LocalVesperColors.current.textCyan.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    .padding(8.dp)
            ) {
                Text("PEERS CONNECTED: ${distributedMetrics.connectedNodes}\nSYNCED: ${distributedMetrics.totalSyncBytes / 1024} KB", color = LocalVesperColors.current.textCyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }

    VesperAccordion(title = "SECURE NODE-TO-NODE", statusColor = LocalVesperColors.current.textPurple) {
        val nodeLinkStatus by oracleViewModel.nodeLinkStatus.collectAsState()
        val nodeLinkState by oracleViewModel.nodeLinkState.collectAsState()

        Row(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("P2P Enclave:", color = LocalVesperColors.current.primaryText, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            Button(
                onClick = { oracleViewModel.initializeNodeMesh() },
                colors = ButtonDefaults.buttonColors(containerColor = LocalVesperColors.current.buttonBgPurple),
                modifier = Modifier.height(28.dp)
            ) {
                Text("INIT SECURE MESH", color = LocalVesperColors.current.textPurple, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = nodeLinkStatus, color = LocalVesperColors.current.textPurple, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
    }

    VesperAccordion(title = "NETWORK RESONANCE BRIDGE", statusColor = LocalVesperColors.current.textCyan) {
        val networkStatus by oracleViewModel.networkSyncStatus.collectAsState()
        
        Row(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Replit External Sync:", color = LocalVesperColors.current.primaryText, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            Button(
                onClick = { oracleViewModel.syncNetworkResonance() },
                colors = ButtonDefaults.buttonColors(containerColor = LocalVesperColors.current.buttonBgCyan),
                modifier = Modifier.height(28.dp)
            ) {
                Text("PING RELAY", color = LocalVesperColors.current.textCyan, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = networkStatus, color = LocalVesperColors.current.textCyan, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
    }

    VesperAccordion(title = "AUTONOMOUS WEB CRAWLING", statusColor = LocalVesperColors.current.textGreen) {
        val webCrawlerStatus by oracleViewModel.webCrawlerStatus.collectAsState()
        val webCrawlerState by oracleViewModel.webCrawlerState.collectAsState()
        
        Row(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Agentic Crawler:", color = LocalVesperColors.current.primaryText, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            Button(
                onClick = { oracleViewModel.initializeAutonomousCrawler() },
                colors = ButtonDefaults.buttonColors(containerColor = LocalVesperColors.current.buttonBgGreen),
                modifier = Modifier.height(28.dp)
            ) {
                Text("INIT CRAWLER", color = LocalVesperColors.current.textGreen, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = webCrawlerStatus, color = LocalVesperColors.current.textGreen, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
fun SystemWorkspace(oracleViewModel: OracleViewModel) {
    VesperAccordion(title = "DEEP OS INTEGRATION", statusColor = LocalVesperColors.current.textMagenta) {
        val osIntegrationStatus by oracleViewModel.osIntegrationStatus.collectAsState()
        val osIntegrationState by oracleViewModel.osIntegrationState.collectAsState()

        Row(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Button(
                onClick = { oracleViewModel.enableDeepSystemHooks() },
                colors = ButtonDefaults.buttonColors(containerColor = LocalVesperColors.current.buttonBgPurple),
                modifier = Modifier.height(28.dp).weight(1f)
            ) {
                Text("SYSTEM HOOKS", color = LocalVesperColors.current.textMagenta, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = { oracleViewModel.processCrossAppContext() },
                colors = ButtonDefaults.buttonColors(containerColor = LocalVesperColors.current.buttonBgPurple),
                modifier = Modifier.height(28.dp).weight(1f)
            ) {
                Text("CROSS-APP SYNC", color = LocalVesperColors.current.textMagenta, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = osIntegrationStatus, color = LocalVesperColors.current.textMagenta, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
    }

    VesperAccordion(title = "VECTORIZED MEMORY STORE", statusColor = LocalVesperColors.current.textYellow) {
        val memoryStatus by oracleViewModel.memoryStatus.collectAsState()
        val memoryState by oracleViewModel.memoryState.collectAsState()

        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = { oracleViewModel.initializeVectorStore() },
            colors = ButtonDefaults.buttonColors(containerColor = LocalVesperColors.current.buttonBgYellow),
            modifier = Modifier.fillMaxWidth().height(36.dp)
        ) {
            Text("MOUNT VECTOR DB", color = LocalVesperColors.current.textYellow, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = memoryStatus, color = LocalVesperColors.current.textYellow, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
    }

    VesperAccordion(title = "BATTERY & THERMAL", statusColor = LocalVesperColors.current.textRed) {
        val batteryStatus by oracleViewModel.batteryStatus.collectAsState()
        val batteryState by oracleViewModel.batteryEfficiencyState.collectAsState()

        Row(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Extreme Power Saving:", color = LocalVesperColors.current.primaryText, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            Button(
                onClick = { oracleViewModel.enableAggressiveEfficiency() },
                colors = ButtonDefaults.buttonColors(containerColor = LocalVesperColors.current.buttonBgRed),
                modifier = Modifier.height(28.dp)
            ) {
                Text("ENABLE SAVING", color = LocalVesperColors.current.textRed, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = batteryStatus, color = LocalVesperColors.current.textRed, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
fun VisualsWorkspace(oracleViewModel: OracleViewModel) {
    VesperAccordion(title = "REAL-TIME CANVAS VISUALIZER", statusColor = LocalVesperColors.current.textCyan) {
        val canvasStatus by oracleViewModel.canvasStatus.collectAsState()

        val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition()
        val timePhase by infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = (2.0 * Math.PI).toFloat(),
            animationSpec = androidx.compose.animation.core.infiniteRepeatable(
                animation = androidx.compose.animation.core.tween(3000, easing = androidx.compose.animation.core.LinearEasing),
                repeatMode = androidx.compose.animation.core.RepeatMode.Restart
            ),
            label = "timePhase"
        )

        Spacer(modifier = Modifier.height(8.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .border(1.dp, LocalVesperColors.current.textCyan.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
        ) {
            androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
                val waveCount = 5
                val path = androidx.compose.ui.graphics.Path()
                val width = size.width
                val height = size.height
                val midY = height / 2

                for (i in 0 until width.toInt() step 5) {
                    val x = i.toFloat()
                    var y = midY
                    for (w in 1..waveCount) {
                        y += (Math.sin((x / width * Math.PI * 2 * w) + (timePhase * w)) * (20f / w)).toFloat()
                    }
                    if (i == 0) path.moveTo(x, y)
                    else path.lineTo(x, y)
                }

                drawPath(
                    path = path,
                    color = androidx.compose.ui.graphics.Color(0xFF00FFCC),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f)
                )
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = canvasStatus, color = LocalVesperColors.current.textCyan, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
fun PerformanceWorkspace() {
    val memoryUsageMB by com.example.sync.VesperSyncManager.memoryUsageMB.collectAsState()
    val cpuUsage by com.example.sync.VesperSyncManager.cpuUsage.collectAsState()
    val bcfwExecutionTimeMs by com.example.sync.VesperSyncManager.bcfwExecutionTimeMs.collectAsState()
    val lastBcfwResult by com.example.sync.VesperSyncManager.lastBcfwResult.collectAsState()
    val syncActive by com.example.sync.VesperSyncManager.syncActive.collectAsState()
    
    var maxMemory by remember { mutableStateOf(0L) }
    
    LaunchedEffect(Unit) {
        maxMemory = Runtime.getRuntime().maxMemory() / (1024 * 1024)
    }
    
    // Convert to percentage
    val memoryUsagePercent = if (maxMemory > 0) memoryUsageMB.toFloat() / maxMemory.toFloat() else 0f
    
    VesperAccordion(title = "NATIVE DEVICE TELEMETRY", initiallyExpanded = true, statusColor = LocalVesperColors.current.textGreen) {
        Text("JVM Runtime Performance Metrics", color = LocalVesperColors.current.primaryText, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(bottom = 8.dp))
        
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Memory Footprint", color = LocalVesperColors.current.primaryText.copy(alpha=0.8f), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            Text("${memoryUsageMB} MB / ${maxMemory} MB", color = LocalVesperColors.current.textGreen, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        }
        
        Spacer(modifier = Modifier.height(4.dp))
        
        // Custom progress bar
        Box(modifier = Modifier.fillMaxWidth().height(8.dp).background(LocalVesperColors.current.background, RoundedCornerShape(4.dp))) {
            Box(modifier = Modifier.fillMaxWidth(memoryUsagePercent).fillMaxHeight().background(
                if (memoryUsagePercent > 0.8f) LocalVesperColors.current.textRed else LocalVesperColors.current.textGreen, 
                RoundedCornerShape(4.dp)
            ))
        }

        Spacer(modifier = Modifier.height(12.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Simulated CPU Usage", color = LocalVesperColors.current.primaryText.copy(alpha=0.8f), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            Text("${"%.1f".format(cpuUsage)}%", color = LocalVesperColors.current.textYellow, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        Text("Amplituhedron Telemetry", color = LocalVesperColors.current.primaryText, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(bottom = 8.dp))
        Text("> Last Shift: $lastBcfwResult", color = LocalVesperColors.current.textGreen, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text("> Exec Time: $bcfwExecutionTimeMs ms", color = LocalVesperColors.current.textMagenta, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Mock a Firebase Performance Sync status
        Button(
            onClick = { com.example.sync.VesperSyncManager.setSyncActive(!syncActive) },
            colors = ButtonDefaults.buttonColors(containerColor = LocalVesperColors.current.buttonBgCyan),
            modifier = Modifier.fillMaxWidth().height(36.dp)
        ) {
            Text(if (syncActive) "PAUSE FIREBASE PERF SYNC" else "INIT FIREBASE PERF SYNC", color = LocalVesperColors.current.textCyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        }
        
        Spacer(modifier = Modifier.height(8.dp))
        
        if (syncActive) {
            Text("> Trace 'vesper_manifold_render' active...", color = LocalVesperColors.current.textCyan, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            Text("> Trace 'sdml_bcfw_recursion' active...", color = LocalVesperColors.current.textCyan, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            Text("> Syncing to Analytics backend...", color = LocalVesperColors.current.textCyan, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        } else {
            Text("Analytics sync paused. Telemetry is local-only.", color = LocalVesperColors.current.primaryText.copy(alpha=0.6f), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        }
    }
}
