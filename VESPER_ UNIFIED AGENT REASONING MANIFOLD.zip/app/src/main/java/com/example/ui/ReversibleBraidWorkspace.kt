package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.LocalVesperColors
import java.util.UUID

data class BraidEvent(
    val id: String = UUID.randomUUID().toString().take(8),
    val timestamp: Long = System.currentTimeMillis(),
    val agentId: String,
    val stateIn: String,
    val action: String,
    val stateOut: String,
    val rationale: String,
    val dependencies: List<String> = emptyList(),
    var isReversed: Boolean = false
)

@Composable
fun ReversibleBraidWorkspace() {
    val colors = LocalVesperColors.current
    
    val initialEvents = listOf(
        BraidEvent(
            agentId = "Agent_Controller",
            stateIn = "S_01",
            action = "DELEGATE_ANALYSIS",
            stateOut = "S_02",
            rationale = "Task requires higher parallel bandwidth. GPU agent available."
        ),
        BraidEvent(
            agentId = "Agent_GPU_Node",
            stateIn = "S_02",
            action = "COMPUTE_TENSOR_GRAPH",
            stateOut = "S_03",
            rationale = "Received delegation. GPU memory sufficient. Executing tensor contraction.",
            dependencies = listOf("S_01")
        ),
        BraidEvent(
            agentId = "Agent_Controller",
            stateIn = "S_03",
            action = "VERIFY_RESULTS",
            stateOut = "S_04",
            rationale = "Results returned from GPU. Checking structural invariants.",
            dependencies = listOf("S_02")
        )
    )

    var trace by remember { mutableStateOf(initialEvents) }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "REVERSIBLE BRAID TRACE",
            color = colors.textMagenta,
            fontSize = 18.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        
        Text(
            text = "Distributed Cognitive Protocol (DCP) enforcing UARM trace alignment. Each atomic step is causally ordered and fully reversible, ensuring fault-tolerant multi-agent intelligence.",
            color = colors.primaryText.copy(alpha = 0.8f),
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(trace) { event ->
                BraidEventCard(
                    event = event,
                    onReverse = { 
                        trace = trace.map { 
                            if (it.id == event.id) it.copy(isReversed = !it.isReversed) else it 
                        } 
                    }
                )
            }
        }
    }
}

@Composable
fun BraidEventCard(event: BraidEvent, onReverse: () -> Unit) {
    val colors = LocalVesperColors.current
    var expanded by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp, 
                if (event.isReversed) colors.textRed.copy(alpha = 0.5f) else colors.borderMagenta, 
                RoundedCornerShape(8.dp)
            )
            .background(if (event.isReversed) colors.background else colors.panelBackground)
            .padding(12.dp)
            .clickable { expanded = !expanded }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = if (event.isReversed) "[REVERSED] ${event.action}" else event.action,
                    color = if (event.isReversed) colors.textRed else colors.textCyan,
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Monospace
                )
                Icon(
                    imageVector = if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    contentDescription = "Expand",
                    tint = colors.primaryText
                )
            }
            
            Text("Agent: ${event.agentId}", color = colors.primaryText, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            
            AnimatedVisibility(visible = expanded) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(top = 8.dp)) {
                    Text("ID: ${event.id}", color = androidx.compose.ui.graphics.Color.DarkGray, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Text("State Transition: ${event.stateIn} -> ${event.stateOut}", color = colors.textGreen, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Text("Rationale: ${event.rationale}", color = colors.primaryText.copy(alpha = 0.8f), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    if (event.dependencies.isNotEmpty()) {
                        Text("Dependencies: ${event.dependencies.joinToString()}", color = colors.textYellow, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = onReverse,
                        colors = ButtonDefaults.buttonColors(containerColor = if (event.isReversed) colors.buttonBgGreen else colors.buttonBgRed),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            if (event.isReversed) "RESTORE EVENT" else "REVERSE EVENT",
                            color = if (event.isReversed) colors.textGreen else colors.textRed,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}
