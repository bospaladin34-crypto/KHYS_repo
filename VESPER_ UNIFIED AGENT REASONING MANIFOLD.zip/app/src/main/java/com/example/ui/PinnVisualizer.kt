package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import com.example.pinn.PinnSolver
import com.example.pinn.PinnTrainingBatch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder
import com.example.service.IterativeSimulationService
import com.example.ui.LocalAnimationsEnabled

@Composable
fun PinnVisualizer(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val animationsEnabled = LocalAnimationsEnabled.current
    var simService by remember { mutableStateOf<IterativeSimulationService?>(null) }
    
    DisposableEffect(context) {
        val intent = Intent(context, IterativeSimulationService::class.java)
        val connection = object : ServiceConnection {
            override fun onServiceConnected(name: android.content.ComponentName?, service: IBinder?) {
                val binder = service as IterativeSimulationService.LocalBinder
                simService = binder.getService()
            }
            override fun onServiceDisconnected(name: android.content.ComponentName?) {
                simService = null
            }
        }
        context.bindService(intent, connection, Context.BIND_AUTO_CREATE)
        onDispose {
            context.unbindService(connection)
        }
    }

    var equation by remember { mutableStateOf("L_couple = alpha * Phi + beta") }
    var epochs by remember { mutableStateOf("100") }
    var variableValues by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var result by remember { mutableStateOf<PinnTrainingBatch?>(null) }
    var isExecuting by remember { mutableStateOf(false) }
    var isSimulating by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()
    
    val simProgress = simService?.progress?.collectAsState()
    val simLogs = simService?.logs?.collectAsState()

    // Parse variables from equation whenever it changes
    LaunchedEffect(equation) {
        val regex = Regex("\\b[a-zA-Z_][a-zA-Z0-9_]*\\b")
        val matches = regex.findAll(equation).map { it.value }.toSet()
        val ignoreList = setOf("sin", "cos", "tan", "log", "exp", "sqrt")
        val parsedVars = matches - ignoreList
        
        val newMap = parsedVars.associateWith { name ->
            variableValues[name] ?: "0.0"
        }
        variableValues = newMap
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF001100))
            .padding(16.dp)
    ) {
        Text(
            text = "PINN SOLVER VISUALIZER",
            color = Color(0xFF00FF00),
            fontFamily = FontFamily.Monospace,
            fontSize = 20.sp,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        OutlinedTextField(
            value = equation,
            onValueChange = { equation = it },
            label = { Text("Target Equation", color = Color(0xFF005500)) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color(0xFF00FF00),
                unfocusedTextColor = Color(0xFF00FF00),
                focusedBorderColor = Color(0xFF00FF00),
                unfocusedBorderColor = Color(0xFF005500),
                cursorColor = Color(0xFF00FF00)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp)
        )

        Text("ITERATIVE SIMULATION RANGES", color = Color.Gray, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(bottom = 4.dp))
        Text("Format: start:end:step (e.g. 0.0:1.0:0.1)", color = Color.Gray, fontSize = 8.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(bottom = 8.dp))
        
        LazyColumn(
            modifier = Modifier.fillMaxWidth().heightIn(max = 200.dp).padding(bottom = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val chunkedVars = variableValues.keys.toList().chunked(2)
            items(chunkedVars) { rowVars ->
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (varName in rowVars) {
                        OutlinedTextField(
                            value = variableValues[varName] ?: "",
                            onValueChange = { newValue ->
                                variableValues = variableValues.toMutableMap().apply { put(varName, newValue) }
                            },
                            label = { Text(varName, color = Color(0xFF005500)) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Next),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color(0xFF00FF00), 
                                unfocusedTextColor = Color(0xFF00FF00), 
                                focusedBorderColor = Color(0xFF00FF00), 
                                unfocusedBorderColor = Color(0xFF005500), 
                                cursorColor = Color(0xFF00FF00)
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (rowVars.size == 1) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        OutlinedTextField(
            value = epochs,
            onValueChange = { epochs = it },
            label = { Text("Epochs", color = Color(0xFF005500)) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color(0xFF00FF00),
                unfocusedTextColor = Color(0xFF00FF00),
                focusedBorderColor = Color(0xFF00FF00),
                unfocusedBorderColor = Color(0xFF005500),
                cursorColor = Color(0xFF00FF00)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        )

        Row(modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    val epochCount = epochs.toIntOrNull() ?: 100
                    isExecuting = true
                    coroutineScope.launch(Dispatchers.Default) {
                        val solver = PinnSolver()
                        // Replaced solver.solve() call to just simulate parameter ingestion
                        result = solver.solve(equation, epochCount)
                        isExecuting = false
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003300)),
                modifier = Modifier.weight(1f)
            ) {
                val paramString = variableValues.entries.joinToString(" ") { "${it.key}=${it.value}" }
                Text(if (isExecuting) "EXECUTING" else "SOLVER", color = Color(0xFF00FF00), fontFamily = FontFamily.Monospace)
            }
            
            Button(
                onClick = {
                    if (simService == null) return@Button
                    isSimulating = true
                    
                    val parsedRanges = mutableMapOf<String, List<Double>>()
                    for ((k, vStr) in variableValues) {
                        val parts = vStr.split(":")
                        if (parts.size == 3) {
                            val start = parts[0].toDoubleOrNull() ?: 0.0
                            val end = parts[1].toDoubleOrNull() ?: 1.0
                            val step = parts[2].toDoubleOrNull() ?: 0.1
                            val points = mutableListOf<Double>()
                            var current = start
                            while (current <= end) {
                                points.add(current)
                                current += step
                            }
                            parsedRanges[k] = points
                        } else {
                            parsedRanges[k] = listOf(vStr.toDoubleOrNull() ?: 0.0)
                        }
                    }
                    
                    simService?.requestIterativeSimulation(parsedRanges)
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF330033)),
                modifier = Modifier.weight(1f)
            ) {
                val prog = (simProgress?.value ?: 0f) * 100
                val progFormatted = "%.1f".format(prog)
                Text(if (isSimulating) "SIM $progFormatted%" else "BATCH SIM", color = Color(0xFFFF00FF), fontFamily = FontFamily.Monospace)
            }
        }

        if (isSimulating) {
            LinearProgressIndicator(
                progress = { simProgress?.value ?: 0f },
                color = Color(0xFFFF00FF),
                trackColor = Color(0xFF330033),
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
            )
            val logVal = simLogs?.value?.lastOrNull()
            if (logVal != null) {
                Text(
                    text = logVal,
                    color = Color.Gray,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
            }
        }

        result?.let { batch ->
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Final Loss: ${batch.finalLoss}\nBoundary Loss: ${batch.boundaryLoss}\nEquation Loss: ${batch.equationLoss}\nEpochs completed: ${batch.epoch}",
                    color = Color(0xFF00CC00),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 14.sp
                )
                val context = LocalContext.current
                Button(
                    onClick = {
                        val csvData = StringBuilder()
                        csvData.append("Epoch,Loss\n")
                        batch.lossHistory.forEachIndexed { i, loss ->
                            csvData.append("${i + 1},$loss\n")
                        }
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("PINN Loss CSV", csvData.toString())
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(context, "Exported PINN history to clipboard", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003300))
                ) {
                    Text("EXPORT CSV", color = Color(0xFF00FF00), fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                }
            }

            // Chart
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color(0xFF002200))
                    .padding(16.dp)
            ) {
                val history = batch.lossHistory
                if (history.isNotEmpty()) {
                    val chartEntryModel = com.patrykandpatrick.vico.core.entry.entryModelOf(*history.toTypedArray())
                    com.patrykandpatrick.vico.compose.style.ProvideChartStyle(
                        com.patrykandpatrick.vico.compose.style.ChartStyle.fromColors(
                            axisLabelColor = Color(0xFF00FF00),
                            axisGuidelineColor = Color(0xFF005500),
                            axisLineColor = Color(0xFF00FF00),
                            entityColors = listOf(Color(0xFF00FF00)),
                            elevationOverlayColor = Color.Transparent
                        )
                    ) {
                        com.patrykandpatrick.vico.compose.chart.Chart(
                            chart = com.patrykandpatrick.vico.compose.chart.line.lineChart(),
                            model = chartEntryModel,
                            startAxis = com.patrykandpatrick.vico.compose.axis.vertical.rememberStartAxis(),
                            bottomAxis = com.patrykandpatrick.vico.compose.axis.horizontal.rememberBottomAxis(),
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }
        }
    }
}
