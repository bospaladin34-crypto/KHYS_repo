package com.example.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.LanguageToGeometryMapper
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun LanguageGeometryVisualizer(modifier: Modifier = Modifier) {
    var text by remember { mutableStateOf("") }
    var displayedText by remember { mutableStateOf("toroidal magnetic containment field") }
    
    val keyboardController = LocalSoftwareKeyboardController.current

    val infiniteTransition = rememberInfiniteTransition(label = "rotation")
    val rotationY by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2 * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(15000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotY"
    )
    
    val rotationX by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2 * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(19000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotX"
    )
    
    val geometry = remember(displayedText) {
        LanguageToGeometryMapper.mapLanguageToGeometry(displayedText)
    }

    // Calculate simulated or rough geometric stats for the dashboard
    val stats = remember(geometry) {
        val volume = (4.0 / 3.0) * Math.PI * Math.pow(geometry.bounds.toDouble(), 3.0)
        val surfaceArea = 4.0 * Math.PI * Math.pow(geometry.bounds.toDouble(), 2.0)
        val density = geometry.points.size / volume
        mapOf(
            "Volume" to String.format("%.4f µ³", volume),
            "Surface Area" to String.format("%.4f µ²", surfaceArea),
            "Vertex Density" to String.format("%.2f pts/µ³", density),
            "Bounding Radius" to String.format("%.2f µ", geometry.bounds)
        )
    }

    Box(modifier = modifier.fillMaxSize().background(Color(0xFF000511))) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val scale = (size.minDimension / 2f) / geometry.bounds * 0.8f
            
            for (p in geometry.points) {
                // simple 3D to 2D projection
                val x1 = p.first * cos(rotationY) - p.third * sin(rotationY)
                val z1 = p.first * sin(rotationY) + p.third * cos(rotationY)
                
                val y2 = p.second * cos(rotationX) - z1 * sin(rotationX)
                val z2 = p.second * sin(rotationX) + z1 * cos(rotationX)
                
                val screenX = cx + x1 * scale
                val screenY = cy + y2 * scale
                
                // Depth for fading
                val depth = (z2 + geometry.bounds) / (2 * geometry.bounds)
                val alpha = (0.2f + 0.8f * depth).coerceIn(0.1f, 1.0f)
                
                drawCircle(
                    color = Color(0xFF00FFCC).copy(alpha = alpha),
                    radius = 3.5f,
                    center = Offset(screenX.toFloat(), screenY.toFloat())
                )
            }
        }
        
        // Dashboard Overlay
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(16.dp)
                .background(Color(0xFF0A110A).copy(alpha = 0.85f))
                .padding(12.dp)
        ) {
            Text(
                "GEOMETRIC MANIFOLD DATA",
                color = Color(0xFF00FFCC),
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            stats.forEach { (label, value) ->
                Row(
                    modifier = Modifier.fillMaxWidth(0.5f),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = label,
                        color = Color.Gray,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp
                    )
                    Text(
                        text = value,
                        color = Color.White,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
            }
        }
        
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = 0.8f))
                .padding(16.dp)
        ) {
            Text(
                "MAPPED TOPOLOGY: ${geometry.type}",
                color = Color.Yellow,
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            BasicTextField(
                value = text,
                onValueChange = { text = it },
                textStyle = TextStyle(
                    color = Color.White,
                    fontSize = 16.sp,
                    fontFamily = FontFamily.Monospace,
                ),
                keyboardOptions = KeyboardOptions.Default.copy(
                    imeAction = ImeAction.Search
                ),
                keyboardActions = KeyboardActions(
                    onSearch = {
                        if (text.isNotBlank()) displayedText = text
                        keyboardController?.hide()
                    }
                ),
                decorationBox = { innerTextField ->
                    if (text.isEmpty()) {
                        Text(
                            "e.g., 'vesper phason', 'stomachion tessellation', 'compression matrix'",
                            color = Color.Gray,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    innerTextField()
                },
                modifier = Modifier.fillMaxWidth().background(Color(0xFF222222)).padding(12.dp)
            )
            Text(
                "N=${geometry.points.size} COORDS",
                color = Color.Green,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}
