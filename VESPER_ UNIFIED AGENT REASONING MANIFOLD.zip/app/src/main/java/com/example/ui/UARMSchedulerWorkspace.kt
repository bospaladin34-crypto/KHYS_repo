package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.LocalVesperColors
import java.util.UUID

data class UARMAgentCapability(
    val agentId: String,
    val role: String,
    val cpuAvailable: Float,
    val ramAvailable: Int,
    val gpuEnabled: Boolean,
    val latencyMs: Int
)

data class UARMStateSnapshot(
    val id: String = UUID.randomUUID().toString().take(8),
    val timestamp: Long = System.currentTimeMillis(),
    val agentId: String,
    val activeGoals: Int,
    val traceDepth: Int,
    val sourceFiles: List<String> = emptyList()
)

object UARMSnapshotManager {
    val snapshots = mutableStateListOf<UARMStateSnapshot>()
    val executionLog = mutableStateListOf<String>()

    fun addSnapshot(snapshot: UARMStateSnapshot) {
        snapshots.add(0, snapshot)
        if (snapshots.size > 50) snapshots.removeAt(snapshots.lastIndex)
        executionLog.add(0, "[SNAPSHOT] Saved cognitive state ID: ${snapshot.id}")
        if (executionLog.size > 100) executionLog.removeAt(executionLog.lastIndex)
    }

    fun log(message: String) {
        executionLog.add(0, message)
        if (executionLog.size > 100) executionLog.removeAt(executionLog.lastIndex)
    }
}

@Composable
fun UARMSchedulerWorkspace() {
    val colors = LocalVesperColors.current
    
    val agents = listOf(
        UARMAgentCapability("Edge_Mobile_1", "Executor", 0.4f, 2048, false, 15),
        UARMAgentCapability("GPU_Node_Alpha", "Reasoner/Executor", 0.9f, 32768, true, 42),
        UARMAgentCapability("LLM_Controller", "Coordinator", 0.1f, 8192, false, 250)
    )

    val snapshots = UARMSnapshotManager.snapshots
    val executionLog = UARMSnapshotManager.executionLog
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "UARM DISTRIBUTED COGNITION",
            color = colors.textCyan,
            fontSize = 18.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        
        Text(
            text = "Capability-aware scheduling and reversible state snapshots (DCP). Optimizing agent allocation based on real-time resource profiles and capability descriptors.",
            color = colors.primaryText.copy(alpha = 0.8f),
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
                onClick = {
                    val newSnapshot = UARMStateSnapshot(agentId = "Controller", activeGoals = 3, traceDepth = (8..15).random())
                    UARMSnapshotManager.addSnapshot(newSnapshot)
                },
                colors = ButtonDefaults.buttonColors(containerColor = colors.buttonBgMagenta),
                modifier = Modifier.weight(1f)
            ) {
                Text("CREATE SNAPSHOT", color = colors.textMagenta, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            }
            
            Button(
                onClick = {
                    // capability aware scheduling logic
                    val bestAgent = agents.maxByOrNull { (it.cpuAvailable * 100) + (if (it.gpuEnabled) 500 else 0) - it.latencyMs }
                    UARMSnapshotManager.log("[DISPATCH] Delegated tensor job to ${bestAgent?.agentId} based on capability profile.")
                },
                colors = ButtonDefaults.buttonColors(containerColor = colors.buttonBgCyan),
                modifier = Modifier.weight(1f)
            ) {
                Text("DISPATCH JOB", color = colors.textCyan, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            }
        }
        
        Row(modifier = Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            // Agent capabilities
            Column(modifier = Modifier.weight(1f).border(1.dp, colors.borderCyan, RoundedCornerShape(8.dp)).padding(8.dp)) {
                Text("PEER CAPABILITIES", color = colors.textCyan, fontSize = 12.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(bottom=8.dp))
                LazyColumn {
                    items(agents) { agent ->
                        Column(modifier = Modifier.padding(bottom = 8.dp).fillMaxWidth().background(colors.panelBackground).padding(8.dp)) {
                            Text(agent.agentId, color = colors.primaryText, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                            Text("Role: ${agent.role}", color = colors.primaryText.copy(alpha=0.8f), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            Text("CPU: ${agent.cpuAvailable} | RAM: ${agent.ramAvailable} | GPU: ${agent.gpuEnabled}", color = colors.textCyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
            
            // Snapshots
            Column(modifier = Modifier.weight(1f).border(1.dp, colors.borderMagenta, RoundedCornerShape(8.dp)).padding(8.dp)) {
                Text("STATE SNAPSHOTS", color = colors.textMagenta, fontSize = 12.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(bottom=8.dp))
                LazyColumn {
                    items(snapshots) { snap ->
                        Column(modifier = Modifier.padding(bottom = 8.dp).fillMaxWidth().background(colors.panelBackground).padding(8.dp)) {
                            Text("ID: ${snap.id}", color = colors.textMagenta, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                            Text("Agent: ${snap.agentId} | Goals: ${snap.activeGoals}", color = colors.primaryText, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            Text("Trace Depth: ${snap.traceDepth}", color = colors.primaryText.copy(alpha=0.6f), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            if (snap.sourceFiles.isNotEmpty()) {
                                Text("Injected files: ${snap.sourceFiles.size}", color = colors.textGreen, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }
        }
        
        Box(modifier = Modifier.fillMaxWidth().height(120.dp).border(1.dp, colors.borderGreen, RoundedCornerShape(8.dp)).padding(8.dp)) {
            LazyColumn {
                items(executionLog) { log ->
                    Text(log, color = colors.textGreen, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}
