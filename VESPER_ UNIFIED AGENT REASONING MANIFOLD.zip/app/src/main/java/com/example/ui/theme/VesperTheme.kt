package com.example.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

enum class VesperThemeMode {
    NEON,
    SLATE,
    OLED
}

data class VesperColors(
    val primaryText: Color,
    val background: Color,
    val panelBackground: Color,
    val borderCyan: Color,
    val textCyan: Color,
    val buttonBgCyan: Color,
    val borderMagenta: Color,
    val textMagenta: Color,
    val buttonBgMagenta: Color,
    val borderGreen: Color,
    val textGreen: Color,
    val buttonBgGreen: Color,
    val borderYellow: Color,
    val textYellow: Color,
    val buttonBgYellow: Color,
    val borderRed: Color,
    val textRed: Color,
    val buttonBgRed: Color,
    val borderOrange: Color,
    val textOrange: Color,
    val buttonBgOrange: Color,
    val borderPurple: Color,
    val textPurple: Color,
    val buttonBgPurple: Color,
    val borderBlue: Color,
    val textBlue: Color,
    val buttonBgBlue: Color,
    val dividerColor: Color
)

val NeonCyberpunkColors = VesperColors(
    primaryText = Color.White,
    background = Color.Black,
    panelBackground = Color.Transparent,
    borderCyan = Color(0xFF00FFD4),
    textCyan = Color(0xFF00FFD4),
    buttonBgCyan = Color(0xFF00332B),
    borderMagenta = Color(0xFFFF00D4),
    textMagenta = Color(0xFFFF00D4),
    buttonBgMagenta = Color(0xFF33002B),
    borderGreen = Color(0xFF00FF55),
    textGreen = Color(0xFF00FF55),
    buttonBgGreen = Color(0xFF003311),
    borderYellow = Color(0xFFFFD700),
    textYellow = Color(0xFFFFD700),
    buttonBgYellow = Color(0xFF443300),
    borderRed = Color(0xFFFF0055),
    textRed = Color(0xFFFF0055),
    buttonBgRed = Color(0xFF330011),
    borderOrange = Color(0xFFFF5500),
    textOrange = Color(0xFFFF5500),
    buttonBgOrange = Color(0xFF441100),
    borderPurple = Color(0xFF8800FF),
    textPurple = Color(0xFF8800FF),
    buttonBgPurple = Color(0xFF110033),
    borderBlue = Color(0xFF33AAFF),
    textBlue = Color(0xFF33AAFF),
    buttonBgBlue = Color(0xFF001133),
    dividerColor = Color.DarkGray
)

val DarkSlateTerminalColors = VesperColors(
    primaryText = Color(0xFFB0C4DE),
    background = Color(0xFF1A1D24),
    panelBackground = Color(0xFF222630),
    borderCyan = Color(0xFF66CDAA),
    textCyan = Color(0xFF66CDAA),
    buttonBgCyan = Color(0xFF1F3B33),
    borderMagenta = Color(0xFFDA70D6),
    textMagenta = Color(0xFFDA70D6),
    buttonBgMagenta = Color(0xFF3A1E37),
    borderGreen = Color(0xFF98FB98),
    textGreen = Color(0xFF98FB98),
    buttonBgGreen = Color(0xFF1E3A1E),
    borderYellow = Color(0xFFF0E68C),
    textYellow = Color(0xFFF0E68C),
    buttonBgYellow = Color(0xFF3B381E),
    borderRed = Color(0xFFFA8072),
    textRed = Color(0xFFFA8072),
    buttonBgRed = Color(0xFF3B1E1C),
    borderOrange = Color(0xFFFFA07A),
    textOrange = Color(0xFFFFA07A),
    buttonBgOrange = Color(0xFF3B261D),
    borderPurple = Color(0xFF9370DB),
    textPurple = Color(0xFF9370DB),
    buttonBgPurple = Color(0xFF251E3B),
    borderBlue = Color(0xFF87CEFA),
    textBlue = Color(0xFF87CEFA),
    buttonBgBlue = Color(0xFF1F2F3B),
    dividerColor = Color(0xFF3A4252)
)

val OledRedBlackColors = VesperColors(
    primaryText = Color(0xFFFF3333),
    background = Color.Black,
    panelBackground = Color.Black,
    borderCyan = Color(0xFFBB0000),
    textCyan = Color(0xFFFF5555),
    buttonBgCyan = Color(0xFF220000),
    borderMagenta = Color(0xFFCC0000),
    textMagenta = Color(0xFFFF4444),
    buttonBgMagenta = Color(0xFF220000),
    borderGreen = Color(0xFFDD0000),
    textGreen = Color(0xFFFF6666),
    buttonBgGreen = Color(0xFF220000),
    borderYellow = Color(0xFFEE0000),
    textYellow = Color(0xFFFF7777),
    buttonBgYellow = Color(0xFF220000),
    borderRed = Color(0xFFFF0000),
    textRed = Color(0xFFFF0000),
    buttonBgRed = Color(0xFF330000),
    borderOrange = Color(0xFFAA0000),
    textOrange = Color(0xFFFF3333),
    buttonBgOrange = Color(0xFF220000),
    borderPurple = Color(0xFF990000),
    textPurple = Color(0xFFFF2222),
    buttonBgPurple = Color(0xFF220000),
    borderBlue = Color(0xFF880000),
    textBlue = Color(0xFFFF1111),
    buttonBgBlue = Color(0xFF220000),
    dividerColor = Color(0xFF440000)
)

val LocalVesperColors = staticCompositionLocalOf { NeonCyberpunkColors }

@Composable
fun VesperTheme(
    colors: VesperColors = LocalVesperColors.current,
    content: @Composable () -> Unit
) {
    CompositionLocalProvider(LocalVesperColors provides colors) {
        content()
    }
}
