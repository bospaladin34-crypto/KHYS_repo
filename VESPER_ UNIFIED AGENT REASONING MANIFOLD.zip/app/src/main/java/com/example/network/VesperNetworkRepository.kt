package com.example.network

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import com.squareup.moshi.Moshi

class VesperNetworkRepository {

    // Target the Replit URL (will be updated once the Replit instance is active)
    private val BASE_URL = "https://vesper-relay.your-username.repl.co/"

    // The OkHttpClient acts for both Retrofit and WebSocket connections
    private val client = OkHttpClient.Builder()
        .addInterceptor(HttpLoggingInterceptor().apply { 
            level = HttpLoggingInterceptor.Level.BODY 
        })
        .pingInterval(30, TimeUnit.SECONDS) // Important for keeping WS alive
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder().build()
    private val wsMessageAdapter = moshi.adapter(WsMessage::class.java)

    // --- Retrofit Fallback / REST API ---

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(client)
        .addConverterFactory(MoshiConverterFactory.create())
        .build()

    val api: VesperResonanceApi = retrofit.create(VesperResonanceApi::class.java)

    suspend fun syncWithRelay(energy: Double, phase: Double, state: String): ResonanceResponse? {
        return try {
            val payload = ResonancePayload(energy, phase, state)
            api.transmitResonance(payload)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    // --- WebSocket Resonance Bridge ---

    private var webSocket: WebSocket? = null

    private val _connectionStatus = MutableStateFlow("Disconnected")
    val connectionStatus: StateFlow<String> = _connectionStatus

    private val _networkTopology = MutableStateFlow<NetworkTopology?>(null)
    val networkTopology: StateFlow<NetworkTopology?> = _networkTopology

    fun connectWebSocket(wsUrl: String) {
        if (webSocket != null) return // Already connected or connecting

        _connectionStatus.value = "Connecting..."
        val request = Request.Builder().url(wsUrl).build()
        
        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                _connectionStatus.value = "Connected"
                // Example: Immediately register node on connect
                // sendWebSocketMessage(WsMessage(type = "REGISTER_NODE"))
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val message = wsMessageAdapter.fromJson(text)
                    handleIncomingMessage(message)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                _connectionStatus.value = "Disconnected"
                this@VesperNetworkRepository.webSocket = null
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                _connectionStatus.value = "Error: ${t.message}"
                this@VesperNetworkRepository.webSocket = null
            }
        })
    }

    private fun handleIncomingMessage(message: WsMessage?) {
        message ?: return
        when (message.type) {
            "TOPOLOGY_UPDATE" -> {
                // Parse payload as NetworkTopology and update state
                // (Assuming basic reflection or explicit adapters for nested objects)
            }
            "COMPUTE_TASK" -> {
                // Receive computational shard -> dispatch to VesperEngine -> compute -> send result
            }
            "PONG" -> {
                // Replit ack
            }
        }
    }

    fun disconnectWebSocket() {
        webSocket?.close(1000, "User disconnected")
        webSocket = null
        _connectionStatus.value = "Disconnected"
    }

    fun sendWebSocketMessage(message: WsMessage) {
        val json = wsMessageAdapter.toJson(message)
        webSocket?.send(json)
    }
}
