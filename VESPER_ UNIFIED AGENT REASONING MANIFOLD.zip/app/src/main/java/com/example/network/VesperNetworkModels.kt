package com.example.network

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class WsMessage(
    val type: String,
    val payload: Map<String, Any>? = null,
    val timestamp: Long = System.currentTimeMillis()
)

@JsonClass(generateAdapter = true)
data class NodeRegistration(
    val nodeHash: String,
    val deviceCapabilities: Map<String, Any>,
    val computeCapacity: Double, // normalized 0.0 to 1.0
    val batteryLevel: Float
)

@JsonClass(generateAdapter = true)
data class ComputeTask(
    val taskId: String,
    val operation: String,
    val payload: String, // serialized data for the task
    val deadline: Long
)

@JsonClass(generateAdapter = true)
data class TaskResult(
    val taskId: String,
    val nodeHash: String,
    val resultPayload: String,
    val computeTimeMs: Long,
    val success: Boolean
)

@JsonClass(generateAdapter = true)
data class NetworkTopology(
    val activeNodes: Int,
    val connectedPeers: List<String>,
    val globalComputePower: Double
)
