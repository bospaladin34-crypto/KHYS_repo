package com.example.network

import com.squareup.moshi.JsonClass
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

// --- Data Models for the Network Resonance Bridge ---

@JsonClass(generateAdapter = true)
data class ResonancePayload(
    val manifoldEnergy: Double,
    val adinkraPhase: Double,
    val vectorState: String,
    val timestamp: Long = System.currentTimeMillis()
)

@JsonClass(generateAdapter = true)
data class ResonanceResponse(
    val ackStatus: String,
    val targetQi: Double,
    val externalSignal: String? = null
)

// --- Retrofit API Interface ---

interface VesperResonanceApi {
    
    /**
     * Pings the Replit Relay to check connection health.
     */
    @GET("api/v1/health")
    suspend fun checkBridgeHealth(): ResonanceResponse

    /**
     * Transmits the current internal state (manifold energy, memory vectors) out to the Replit Relay.
     * The relay can then route this to the broader internet.
     */
    @POST("api/v1/transmit")
    suspend fun transmitResonance(@Body payload: ResonancePayload): ResonanceResponse
}
