package com.example

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ui.theme.VesperThemeMode
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import com.example.pinn.VesperConstants
import kotlin.random.Random

import com.example.pinn.ValidationFormulas
import com.example.pinn.NeuroSymbolicEngine

class VesperCoreViewModel : ViewModel() {
    private val _themeMode = MutableStateFlow(VesperThemeMode.NEON)
    val themeMode: StateFlow<VesperThemeMode> = _themeMode.asStateFlow()

    fun setThemeMode(mode: VesperThemeMode) {
        _themeMode.value = mode
    }

    private val _targetF0 = MutableStateFlow(VesperConstants.F0_HZ.toFloat())
    val targetF0: StateFlow<Float> = _targetF0.asStateFlow()

    private val _targetPhi = MutableStateFlow(VesperConstants.GOLDEN_RATIO_PHI.toFloat())
    val targetPhi: StateFlow<Float> = _targetPhi.asStateFlow()

    private val _targetDeltaPhi = MutableStateFlow(VesperConstants.PHASE_DELTA.toFloat())
    val targetDeltaPhi: StateFlow<Float> = _targetDeltaPhi.asStateFlow()

    private val _targetTau = MutableStateFlow(VesperConstants.TAU.toFloat())
    val targetTau: StateFlow<Float> = _targetTau.asStateFlow()

    // Validation States
    private val _metricCharging = MutableStateFlow(0f)
    val metricCharging: StateFlow<Float> = _metricCharging.asStateFlow()

    private val _isomorphismValid = MutableStateFlow(false)
    val isomorphismValid: StateFlow<Boolean> = _isomorphismValid.asStateFlow()

    private val _hallucinationDecay = MutableStateFlow(1f)
    val hallucinationDecay: StateFlow<Float> = _hallucinationDecay.asStateFlow()

    private val _resonanceOutput = MutableStateFlow(0f)
    val resonanceOutput: StateFlow<Float> = _resonanceOutput.asStateFlow()

    // Neuro-Symbolic States
    private val neuroSymbolicEngine = NeuroSymbolicEngine()
    private val _manifoldEnergy = MutableStateFlow(0f)
    val manifoldEnergy: StateFlow<Float> = _manifoldEnergy.asStateFlow()

    private val _activeStrands = MutableStateFlow<List<String>>(emptyList())
    val activeStrands: StateFlow<List<String>> = _activeStrands.asStateFlow()

    private val _agenticState = MutableStateFlow("IDLE")
    val agenticState: StateFlow<String> = _agenticState.asStateFlow()

    private val _frameRateDelay = MutableStateFlow(16L) // 60 FPS default
    val frameRateDelay: StateFlow<Long> = _frameRateDelay.asStateFlow()

    // Genesis Daemon States (from vesper_quartz_reservoir)
    private val _khysSnap = MutableStateFlow("SNAP: 91°")
    val khysSnap: StateFlow<String> = _khysSnap.asStateFlow()

    private val _mnemosyneState = MutableStateFlow("COMPRESSING")
    val mnemosyneState: StateFlow<String> = _mnemosyneState.asStateFlow()

    private val _thirteenEngineStatus = MutableStateFlow("EQUILIBRIUM")
    val thirteenEngineStatus: StateFlow<String> = _thirteenEngineStatus.asStateFlow()

    private val _khysAttentionWeights = MutableStateFlow<List<Float>>(emptyList())
    val khysAttentionWeights: StateFlow<List<Float>> = _khysAttentionWeights.asStateFlow()

    private val subVec = floatArrayOf(VesperConstants.F0_HZ.toFloat(), VesperConstants.GOLDEN_RATIO_PHI.toFloat(), VesperConstants.PHASE_DELTA.toFloat())
    private val sVec = FloatArray(3)

    init {
        viewModelScope.launch {
            var tick = 0
            while (true) {
                tick++
                delay(Random.nextLong(400, 1200))
                val f0 = VesperConstants.F0_HZ.toFloat() + Random.nextFloat() * 0.04f - 0.02f
                val phi = VesperConstants.GOLDEN_RATIO_PHI.toFloat() + Random.nextFloat() * 0.0004f - 0.0002f
                val deltaPhi = VesperConstants.PHASE_DELTA.toFloat() + Random.nextFloat() * 0.004f - 0.002f
                val tau = VesperConstants.TAU.toFloat() + Random.nextFloat() * 0.04f - 0.02f

                _targetF0.value = f0
                _targetPhi.value = phi
                _targetDeltaPhi.value = deltaPhi
                _targetTau.value = tau

                // Calculate Mathematical Validation formulas
                // Pseudo random values imitating dynamic system input
                val psi = 1.0f + Random.nextFloat() * 0.1f
                val pA = 0.5f + Random.nextFloat() * 0.1f
                val v = 100f
                val rho = 1.2f
                val dt = 0.1f

                val metric = ValidationFormulas.calculateMetricCharging(psi, pA, v, rho, dt)
                _metricCharging.value = metric
                
                // Add an arbitrary phase modifier to verify Material Isomorphism against DeltaPhi.
                // Normally metric charging would be scaled/normalized. 
                // We'll simulate a value close to PHASE_DELTA (0.17...)
                val syntheticMetric = VesperConstants.PHASE_DELTA.toFloat() + (Random.nextFloat() * 0.08f - 0.04f)
                _isomorphismValid.value = ValidationFormulas.checkMaterialIsomorphism(syntheticMetric)

                val entropy = Random.nextFloat() * 0.05f // Low entropy tracking
                _hallucinationDecay.value = ValidationFormulas.calculateHallucinationDecay(entropy, tau)

                // Simulating resonance arrays
                sVec[0] = f0
                sVec[1] = phi
                sVec[2] = deltaPhi
                _resonanceOutput.value = ValidationFormulas.calculateResonance(sVec, subVec)

                // Neuro-Symbolic Engine SSN integration
                val trajectory = neuroSymbolicEngine.processSymbolicVector("SYS_TICK_${tick}", dt = 0.0626f)
                _manifoldEnergy.value = trajectory.manifoldEnergy
                _activeStrands.value = trajectory.activeStrands
                _agenticState.value = trajectory.agenticState

                // Agentic Autopoiesis evaluation loop
                val autopoiesisTrajectory = neuroSymbolicEngine.executeAutopoiesis(dt = 0.0626f)
                if (autopoiesisTrajectory != null) {
                    _manifoldEnergy.value = autopoiesisTrajectory.manifoldEnergy
                    _activeStrands.value = autopoiesisTrajectory.activeStrands
                    _agenticState.value = autopoiesisTrajectory.agenticState
                }

                // Genesis Sub-tick updates
                val khys = 91.0f + (Random.nextFloat() * 0.04f - 0.02f)
                _khysSnap.value = String.format(java.util.Locale.US, "SNAP: %.3f°", khys)
                
                // Simulate stochastic 91° attention matrix (e.g., 64 weights for an 8x8 block)
                val newWeights = List(64) {
                    val base = if (Random.nextFloat() > 0.85f) 0.8f else 0.1f // Sparse connections
                    val noise = Random.nextFloat() * 0.2f
                    (base + noise).coerceIn(0f, 1f)
                }
                _khysAttentionWeights.value = newWeights
                
                if (tick % 20 == 0) {
                    _mnemosyneState.value = if (Random.nextBoolean()) "TOPOLOGICAL GATE OPEN" else "COMPRESSING..."
                }
                
                val engineVariance = Random.nextFloat()
                _thirteenEngineStatus.value = if (engineVariance > 0.95f) "RE-ALIGNING" else "EQUILIBRIUM"

                // Dynamic theme mode selection
                val targetMode = when {
                    !_isomorphismValid.value -> VesperThemeMode.OLED
                    _agenticState.value == "IDLE" || _agenticState.value == "STABILIZED" -> VesperThemeMode.SLATE
                    else -> VesperThemeMode.NEON
                }
                if (_themeMode.value != targetMode) {
                    _themeMode.value = targetMode
                }

                // Dynamic simulation FPS management
                val isHeavyLoad = _manifoldEnergy.value > 0.8f || _agenticState.value == "ACTIVE" || _metricCharging.value > 0.85f
                val targetDelay = if (isHeavyLoad) 33L else 16L
                if (_frameRateDelay.value != targetDelay) {
                    _frameRateDelay.value = targetDelay
                }
            }
        }
    }

    fun updateMetrics(f0: Float, phi: Float, deltaPhi: Float, tau: Float) {
        _targetF0.value = f0
        _targetPhi.value = phi
        _targetDeltaPhi.value = deltaPhi
        _targetTau.value = tau
    }
}
