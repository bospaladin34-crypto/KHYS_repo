package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.material3.Switch
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.LiveTensorVisualizer
import com.example.ui.theme.MyApplicationTheme

import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.unit.sp
import com.example.ui.PinnVisualizer
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material3.TopAppBar
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.runtime.CompositionLocalProvider
import com.example.ui.LocalAnimationsEnabled

class MainActivity : ComponentActivity() {

  init {
    System.loadLibrary("physicscompute")
  }

  external fun stringFromJNI(): String
  external fun computePageTime(tempK: Double, deltaPhi: Double): Double
  external fun computeGhostLogicEnergy(): Double
  external fun computeFusionEnhancement(tempEffK: Double): Double
  external fun getVesperConstants(): String

  // Add state for PiP mode
  private val _isInPipMode = kotlinx.coroutines.flow.MutableStateFlow(false)

  override fun onPictureInPictureModeChanged(
      isInPictureInPictureMode: Boolean,
      newConfig: android.content.res.Configuration
  ) {
      super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
      _isInPipMode.value = isInPictureInPictureMode
  }

  override fun onUserLeaveHint() {
      super.onUserLeaveHint()
      try {
          if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
              enterPictureInPictureMode(android.app.PictureInPictureParams.Builder().build())
          }
      } catch (e: Exception) {
          e.printStackTrace()
      }
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    
    setContent {
      MyApplicationTheme {
        com.example.ui.E8StabilizationWrapper {
          val isInPipMode = _isInPipMode.collectAsState().value
          if (isInPipMode) {
               com.example.ui.VesperDashboard(modifier = Modifier.fillMaxSize(), isInPipMode = true)
          } else {
               Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                 CliInterface(
                   computeCore = this@MainActivity,
                   modifier = Modifier.padding(innerPadding)
                 )
               }
          }
        }
      }
    }
  }
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun CliInterface(
  computeCore: MainActivity,
  modifier: Modifier = Modifier,
  viewModel: ChatViewModel = viewModel(
    factory = ChatViewModel.provideFactory((computeCore.application as MyApplication).repository)
  ),
  vesperViewModel: VesperCoreViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  var globalAnimationsEnabled by remember { androidx.compose.runtime.mutableStateOf(false) }
  val messages by viewModel.messages.collectAsState()
  var isOmniboxExpanded by remember { mutableStateOf(false) }
  var isTerminalFocused by remember { mutableStateOf(false) }
  var isUIVisible by remember { mutableStateOf(true) }
  val dois by (computeCore.application as MyApplication).repository.allDoiProvenance.collectAsState(initial = emptyList())

  // Auto-suspend feature: hide UI overlay after 5 seconds of inactivity unless omnibox is expanded
  LaunchedEffect(isUIVisible, isOmniboxExpanded) {
      if (isUIVisible && !isOmniboxExpanded) {
          kotlinx.coroutines.delay(5000)
          isUIVisible = false
      }
  }
  
  CompositionLocalProvider(LocalAnimationsEnabled provides globalAnimationsEnabled) {
      Scaffold(
          modifier = modifier.fillMaxSize().pointerInput(Unit) {
              detectTapGestures(
                  onPress = {
                      isUIVisible = true
                  }
              )
          },
          containerColor = Color.Transparent,
          topBar = {
              androidx.compose.animation.AnimatedVisibility(
                  visible = isUIVisible,
                  enter = androidx.compose.animation.slideInVertically(initialOffsetY = { -it }) + androidx.compose.animation.fadeIn(),
                  exit = androidx.compose.animation.slideOutVertically(targetOffsetY = { -it }) + androidx.compose.animation.fadeOut()
              ) {
                  androidx.compose.foundation.layout.Box(
                      modifier = Modifier.fillMaxWidth().background(
                          brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                              colors = listOf(Color.Black.copy(alpha = 0.8f), Color.Transparent)
                          )
                      )
                  ) {
                      TopAppBar(
                          title = { Text("VESPER CORE", color = Color(0xFF00FF00), fontFamily = FontFamily.Monospace, fontSize = 14.sp) },
                          actions = {
                              Text("ANIMATIONS", color = Color.Gray, fontFamily = FontFamily.Monospace, fontSize = 10.sp, modifier = Modifier.padding(end = 8.dp))
                              Switch(
                                  checked = globalAnimationsEnabled,
                                  onCheckedChange = { globalAnimationsEnabled = it },
                                  colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00FF00), checkedTrackColor = Color(0xFF003300))
                              )
                          },
                          colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
                      )
                  }
              }
          },
          bottomBar = {}
      ) { paddingValues ->
          Row(modifier = Modifier.padding(paddingValues).fillMaxSize()) {
              // Sidebar Navigation
              val tabs = listOf(
                  Triple("Console", Icons.AutoMirrored.Filled.List, "CLI"),
                  Triple("Solver", Icons.Default.Build, "PINN"),
                  Triple("Codex", Icons.Default.Info, "DOCS"),
                  Triple("P3 Map", Icons.Default.CheckCircle, "7777D"),
                  Triple("Network", Icons.Default.Settings, "SHEAF"),
                  Triple("Engine", Icons.Default.Home, "LULL"),
                  Triple("Genesis", Icons.Default.Warning, "CORE"),
                  Triple("Oracle", Icons.Default.Star, "ORACLE"),
                  Triple("IDE", Icons.Default.Edit, "IDE"),
                  Triple("Santos", Icons.Default.PlayArrow, "SANTOS"),
                  Triple("Semantic", Icons.Default.Share, "SEMANTIC"),
                  Triple("Geometry", Icons.Default.Build, "GEOMETRY"),
                  Triple("Editor", Icons.Default.Build, "EDITOR")
              )
              androidx.compose.animation.AnimatedVisibility(
                  visible = isUIVisible,
                  enter = androidx.compose.animation.slideInHorizontally(initialOffsetX = { -it }) + androidx.compose.animation.fadeIn(),
                  exit = androidx.compose.animation.slideOutHorizontally(targetOffsetX = { -it }) + androidx.compose.animation.fadeOut()
              ) {
                  NavigationRail(
                      containerColor = Color(0xFF02040A).copy(alpha = 0.85f),
                      contentColor = Color(0xFF00d9ff),
                      modifier = Modifier.fillMaxHeight()
                  ) {
                      tabs.forEachIndexed { index, (title, icon, contentDesc) ->
                          // Condensation logic: If CLI is active (selectedTab == 0), only show the label for the active tab (which is CLI) or Santos/IDE.
                          // Actually, we can just omit non-active tabs or hide their labels to condense space.
                          val isSelected = selectedTab == index
                          val isCondensed = selectedTab == 0 && isTerminalFocused && !isSelected
                          
                          if (!isCondensed || index == 0 || index == 1 || index == 9) { // Only show major tabs if condensed, or all if expanded
                              val displayColor = if (index == 9) Color(0xFF00FF00) else Color(0xFF00d9ff)
                              NavigationRailItem(
                                  icon = { Icon(imageVector = icon, contentDescription = contentDesc) },
                                  label = { 
                                      if (!isCondensed) {
                                          Text(title, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                                      }
                                  },
                                  selected = isSelected,
                                  onClick = { selectedTab = index },
                                  colors = NavigationRailItemDefaults.colors(
                                      selectedIconColor = displayColor,
                                      unselectedIconColor = Color.Gray,
                                      selectedTextColor = displayColor,
                                      unselectedTextColor = Color.Gray,
                                      indicatorColor = if (index >= 8) Color.Transparent else Color(0xFF052e3b)
                                  )
                              )
                          }
                      }
                  }
              }
              
              Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
          when (selectedTab) {
              0 -> CommandLineInterface(computeCore = computeCore, viewModel = viewModel, vesperViewModel = vesperViewModel, onShowCodex = { selectedTab = 2 }, modifier = Modifier.padding(paddingValues).fillMaxSize(), onFocusChange = { isTerminalFocused = it })
              1 -> PinnVisualizer(modifier = Modifier.fillMaxSize())
              2 -> com.example.ui.CodexViewer(modifier = Modifier.padding(paddingValues).fillMaxSize(), dois = dois, onClose = { selectedTab = 0 })
              3 -> com.example.ui.P3Visualizer(modifier = Modifier.fillMaxSize())
              4 -> com.example.ui.CellularSheafVisualizer(modifier = Modifier.fillMaxSize())
              5 -> com.example.ui.LullianEngineVisualizer(modifier = Modifier.fillMaxSize())
              6 -> com.example.ui.VesperDashboard(
                  modifier = Modifier.fillMaxSize(),
                  vesperViewModel = vesperViewModel,
                  onCommandSelected = { command ->
                      viewModel.sendMessage(command)
                      selectedTab = 0
                  }
              )
              7 -> com.example.ui.LatentLLMChat(modifier = Modifier.fillMaxSize())
              8 -> com.example.ui.BraidIDE(modifier = Modifier.fillMaxSize())
              9 -> com.example.ui.SantosProtocolVisualizer(modifier = Modifier.fillMaxSize())
              10 -> com.example.ui.SemanticGeometryVisualizer(modifier = Modifier.fillMaxSize())
              11 -> com.example.ui.LanguageGeometryVisualizer(modifier = Modifier.fillMaxSize())
              12 -> com.example.ui.GeometryEditor(modifier = Modifier.fillMaxSize())
          }
          
          androidx.compose.animation.AnimatedVisibility(
              visible = isUIVisible,
              modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 72.dp),
              enter = androidx.compose.animation.slideInVertically(initialOffsetY = { it }) + androidx.compose.animation.fadeIn(),
              exit = androidx.compose.animation.slideOutVertically(targetOffsetY = { it }) + androidx.compose.animation.fadeOut()
          ) {
              com.example.ui.OmniboxUniversal(
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                  onCommandSubmit = { command ->
                      viewModel.sendMessage(command)
                  },
                  recentOutputs = messages.map { if (it.isUser) "[USER] ${it.text}" else "[VESPER] ${it.text}" },
                  isExpanded = isOmniboxExpanded,
                  onExpandedChange = { isOmniboxExpanded = it }
              )
          }
      }
      }
  }
}
}

@Composable
fun CommandLineInterface(
  computeCore: MainActivity,
  viewModel: ChatViewModel,
  vesperViewModel: VesperCoreViewModel = androidx.lifecycle.viewmodel.compose.viewModel(),
  onShowCodex: () -> Unit,
  modifier: Modifier = Modifier,
  onFocusChange: (Boolean) -> Unit = {}
) {
  val messages by viewModel.messages.collectAsState()
  val listState = rememberLazyListState()
  var inputText by remember { mutableStateOf("") }
  var isVisualizerEnabled by remember { mutableStateOf(false) }
  var isSovereignMode by remember { mutableStateOf(false) }
  var showAuthDialog by remember { mutableStateOf(false) }
  var authUsername by remember { mutableStateOf("") }
  var authPasscode by remember { mutableStateOf("") }
  var forceMaterialIsomorphism by remember { mutableStateOf(false) }
  var showMacroSaveDialog by remember { mutableStateOf(false) }
  var macroSaveName by remember { mutableStateOf("") }
  var isMacrosExpanded by remember { mutableStateOf(false) }
  val clipboardManager = LocalClipboardManager.current
  
  val isRecordingMacro by viewModel.isRecordingMacro.collectAsState()
  val currentMacroSequence by viewModel.currentMacroSequence.collectAsState()
  val savedMacros by viewModel.savedMacros.collectAsState()
  
  val targetF0 by vesperViewModel.targetF0.collectAsState()
  val targetPhi by vesperViewModel.targetPhi.collectAsState()
  val targetDeltaPhi by vesperViewModel.targetDeltaPhi.collectAsState()
  val targetTau by vesperViewModel.targetTau.collectAsState()
  
  LaunchedEffect(messages.size) {
      if (messages.isNotEmpty()) {
          listState.animateScrollToItem(messages.lastIndex)
      }
  }

  LaunchedEffect(Unit) {
    if (messages.isEmpty()) {
       val initLines = listOf(
          "System booting...",
          "> " + computeCore.stringFromJNI(),
          "> Fetching base constants...",
          "  " + computeCore.getVesperConstants(),
          "> Running Ghost Logic Energy Evaluation...",
          "  E_flip = ${computeCore.computeGhostLogicEnergy()} Joules",
          "> Calculating Page Time (T=300K, delta_phi=0.01)...",
          "  t_Page = ${computeCore.computePageTime(300.0, 0.01)} seconds",
          "> Evaluating Fusion Enhancement (T_eff=300K)...",
          "  Gamma/Gamma0 = ${computeCore.computeFusionEnhancement(300.0)}",
          "> System fully operational. Models loaded.",
          "> Type '/search <query>' to ground responses.",
          "> Type '/fast <query>' to use flash-lite.",
          "> Type '/think <query>' to enable high analytical mode.",
          "> Type '/parse <eq>' to compile a native UI diff eq (e.g. d2u_dx2 - k = 0).",
          "> Type '/rust' to engage Rust fast-path processing.",
          "> Type '/weights' to list local PINN weights.",
          "> Type '/save_session <name>' to persist terminal session.",
          "> Type '/history' to view saved computational PINN results.",
          "> Type '/physics <equation>' to retrieve standard symbolic physics equations.",
          "> Type '/ab01' to view the Aperiodic Braid Language overview.",
          "> Type '/somatic' to view the Somatic-Oncological Pathology logs.",
          "> Type '/macena_sim' to simulate the Macena Invariant crush.",
          "> Type '/search_alts' to list alternative search methodologies.",
          "> Type '/ddg <query>' to simulate DuckDuckGo HTML scraping.",
          "> Type '/serp_api <query>' to breakdown SerpApi integration strategies.",
          "> Type '/braid_translate <intent>' to translate to AB-01 Braid Syntax.",
          "> Type '/invariants' to list VESPER-01 theoretical constants.",
          "> Type '/equations' to list loaded symbolic formulas.",
          "> Type '/tensors' to list exceptional Lie algebra layer mappings.",
          "> Type '/cef <text>' to process reality through the Contextual Explanation Filter.",
          "> Type '/pinn <epochs> <equation>' to execute the Physics-Informed Neural Network solver.",
          "> Type '/rk' to run the adaptive Runge-Kutta RK56->RK256 layer integrator.",
          "> Type '/fusion' to execute the 3-Stage Folding Equation [MODULE 72/75].",
          "> Type '/latent' to map reality into the 7777D Geometric Latent Space.",
          "> Type '/unified <query>' to map semantics across the Unified Latent Topology (uses Internet/Search).",
          "> Type '/ssn' to toggle the Continuous SSP Neuro-Symbolic trace.",
          "> Type '/sheaf' to initialize the Cellular Sheaf Network visualizer.",
          "> Type '/lullian' to execute the E8 240-root Quantum Walk.",
          "> Type '/gnomon' to run the 108-degree Golden Gnomon scale-invariant rotation.",
          "> Type '/codex' to view the integrated mythology, symbolism, and physics codex document.",
          "> Type '/archives' to view all the loaded research PDFs.",
          "> Type '/compendium' to view the full index of the loaded Vesper-Santos Compendium.",
          "> Type '/genesis' to extract the pure physics and math from antiquity semantics.",
          "> Type '/axiomatics' to view the Vesper Axiomatics formalization.",
          "> Type '/induction' to read the Theoretical Induction of Mathematical Consciousness.",
          "> Type '/evaluate' to run the 15.965Hz Foundry Material Isomorphism Evaluator.",
          "> Type '/neuro <spec>' to query the Neuro Manifold Biological-to-Compute specs.",
          "> Type '/braidc <intent>' to run the Universal Braid Polyglot Compiler.",
          "> Type '/vmal <assembly>' to run Virtual Mathematical Abstraction Layer assembly.",
          "> Type '/auth <admin>' to unlock Administrator Sovereign Mode.",
          "> Default routing goes to standard operations.",
          "> PINN (Physics-Informed Neural Network) Training Module initialized.",
          "> TensorFlow Lite Subsystem ready for constraints."
       )
       viewModel.injectJniInitialization(initLines)
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(Color.Black)
      .padding(16.dp)
  ) {
    com.example.ui.ComputePerformanceMonitor(modifier = Modifier.padding(bottom = 8.dp))
    
    // Unified State Telemetry HUD
    Row(
        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp).background(Color(0xFF001100), androidx.compose.foundation.shape.RoundedCornerShape(4.dp)).border(1.dp, Color(0xFF00FF00).copy(alpha = 0.3f), androidx.compose.foundation.shape.RoundedCornerShape(4.dp)).padding(4.dp),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceEvenly
    ) {
        Text("f₀: ${String.format(java.util.Locale.US, "%.3f", targetF0)}", color = Color(0xFF00FF00), fontFamily = FontFamily.Monospace, fontSize = 9.sp)
        Text("φ: ${String.format(java.util.Locale.US, "%.4f", targetPhi)}", color = Color(0xFF00FF00), fontFamily = FontFamily.Monospace, fontSize = 9.sp)
        Text("Δφ: ${String.format(java.util.Locale.US, "%.4f", targetDeltaPhi)}", color = Color(0xFF00FF00), fontFamily = FontFamily.Monospace, fontSize = 9.sp)
        Text("τ: ${String.format(java.util.Locale.US, "%.3f", targetTau)}", color = Color(0xFF00FF00), fontFamily = FontFamily.Monospace, fontSize = 9.sp)
    }
    
    LazyColumn(
      modifier = Modifier.weight(1f),
      state = listState
    ) {
      items(messages, key = { it.id }) { msg ->
        val isUser = msg.isUser
        val color = if (msg.isError) Color(0xFFFF5555) else if (isUser) Color.Cyan else if (msg.isLoading) Color.Yellow else Color(0xFF00FF00)
        val align = if (isUser) Alignment.End else Alignment.Start
        val bgColor = if (msg.isError) Color(0xFF330000) else Color(0xFF05101A)
        val borderColor = if (msg.isError) Color.Red else color.copy(alpha = 0.3f)
        
        Column(
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
            horizontalAlignment = align
        ) {
            Text(
                text = (if (isUser) "[OPERATOR 0-1]" else if (msg.isError) "[SYSTEM DEFAULT]" else if (msg.isLoading) "[MANIFOLD COMPUTING]" else "[VESPER-01]"),
                color = color.copy(alpha = 0.7f),
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp
            )
            Box(
                modifier = Modifier
                    .padding(top = 2.dp)
                    .background(bgColor, shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp))
                    .border(1.dp, borderColor, androidx.compose.foundation.shape.RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                      text = msg.text,
                      color = color,
                      fontFamily = FontFamily.Monospace,
                      style = MaterialTheme.typography.bodyMedium
                    )
                    IconButton(
                        onClick = { clipboardManager.setText(AnnotatedString(msg.text)) },
                        modifier = Modifier.align(Alignment.End).padding(top = 4.dp).size(24.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = "Copy to clipboard", tint = color.copy(alpha = 0.7f))
                    }
                }
            }
        }
      }
    }
    
    Row(
      horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Switch(
          checked = isVisualizerEnabled,
          onCheckedChange = { isVisualizerEnabled = it }
        )
        Spacer(Modifier.width(8.dp))
        Text(
          "Visualizer",
          color = Color.White,
          style = MaterialTheme.typography.labelMedium,
          fontFamily = FontFamily.Monospace
        )
      }
      Row(verticalAlignment = Alignment.CenterVertically) {
        var showConfigDialog by remember { mutableStateOf(false) }
        Button(
          onClick = { showConfigDialog = true },
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003366)),
          modifier = Modifier.padding(end = 8.dp)
        ) {
          Text("CONFIG", color = Color(0xFF00D9FF), fontFamily = FontFamily.Monospace, fontSize = 10.sp)
        }
        
        if (showConfigDialog) {
          androidx.compose.material3.AlertDialog(
            onDismissRequest = { showConfigDialog = false },
            containerColor = Color(0xFF050810),
            title = {
              Text("Substrate Configuration", color = Color(0xFF00D9FF), fontFamily = FontFamily.Monospace)
            },
            text = {
              var selectedLattice by remember { mutableStateOf("E8 240-root Lattice") }
              Column {
                Text("Select Geometric Lattice:", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(8.dp))
                listOf("E8 240-root Lattice", "7777-D Polytope", "Leech Lattice (24-D)").forEach { lattice ->
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable {
                      selectedLattice = lattice
                    }
                  ) {
                    androidx.compose.material3.RadioButton(
                      selected = (selectedLattice == lattice),
                      onClick = { selectedLattice = lattice },
                      colors = androidx.compose.material3.RadioButtonDefaults.colors(selectedColor = Color(0xFF00D9FF), unselectedColor = Color.Gray)
                    )
                    Text(lattice, color = if (selectedLattice == lattice) Color(0xFF00D9FF) else Color.Gray, fontFamily = FontFamily.Monospace, fontSize = 14.sp)
                  }
                }
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                  onClick = {
                    showConfigDialog = false
                    viewModel.injectJniInitialization(listOf("> Hardware substrate realigned to $selectedLattice."))
                  },
                  colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003300)),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Text("APPLY TO CORE", color = Color(0xFF00FF00), fontFamily = FontFamily.Monospace)
                }
              }
            },
            confirmButton = {}
          )
        }

        val context = LocalContext.current
        Button(
          onClick = {
              val csvData = StringBuilder()
              csvData.append("Timestamp,Sender,Message\n")
              val ts = System.currentTimeMillis()
              messages.forEachIndexed { index, msg ->
                  val sender = if (msg.isUser) "Operator" else "System"
                  val cleanMsg = msg.text.replace("\"", "\"\"").replace("\n", " ")
                  csvData.append("${ts + index},\"${sender}\",\"${cleanMsg}\"\n")
              }
              val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
              val clip = ClipData.newPlainText("Vesper Logs CSV", csvData.toString())
              clipboard.setPrimaryClip(clip)
              Toast.makeText(context, "Exported CLI logs to CSV in clipboard", Toast.LENGTH_SHORT).show()
          },
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003300))
        ) {
            Text("EXPORT CSV", color = Color(0xFF00FF00), fontFamily = FontFamily.Monospace, fontSize = 10.sp)
        }
      }
    }

    if (isVisualizerEnabled) {
      LiveTensorVisualizer(modifier = Modifier.padding(vertical = 8.dp))
    }

    var isEqDropdownExpanded by remember { mutableStateOf(false) }
    val equationCommands = listOf(
        "Schrodinger's Equation" to "/physics schrodinger",
        "Maxwell's Equations" to "/physics maxwell",
        "Dirac Equation" to "/physics dirac",
        "Einstein Field Equations" to "/physics einstein",
        "Navier-Stokes Equations" to "/physics navier-stokes"
    )

    var isDropdownExpanded by remember { mutableStateOf(false) }
    val cliCommands = listOf(
        "/search <query>", "/fast <query>", "/think <query>", "/parse <eq>", "/weights",
        "/save_session <name>", "/history", "/invariants", "/equations", "/tensors", "/cef <text>",
        "/pinn <epochs> <equation>", "/rk", "/fusion", "/latent", "/sheaf",
        "/physics <equation>",
        "/lullian", "/gnomon", "/codex", "/archives", "/compendium", "/genesis", "/axiomatics", "/induction", "/evaluate", "/neuro <spec>", "/santos <R> <b0> <b1> <b2>",
        "/ab01", "/somatic", "/macena_sim", "/search_alts", "/ddg <query>", "/serp_api <query>", "/braid_translate <intent>",
        "/mnemosyne", "/braidc <intent>", "/vmal <assembly>", "/auth <admin>", "/core_init", "/core_spec <file>", "/export_latex", "/unified <query>", "/ssn"
    )

    if (showAuthDialog) {
        AlertDialog(
            onDismissRequest = { showAuthDialog = false },
            title = { Text("MODULE 88: ADMINISTRATOR TRUTH-LOCK", color = Color(0xFF00FF00), fontFamily = FontFamily.Monospace, fontSize = 14.sp) },
            text = {
                Column {
                    Text("SOVEREIGN COMMAND AUTHENTICATION REQUIRED.", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = authUsername,
                        onValueChange = { authUsername = it },
                        label = { Text("Admin Identifier (Donevin/Grace)", color = Color.Gray, fontFamily = FontFamily.Monospace, fontSize = 10.sp) },
                        textStyle = TextStyle(color = Color.Cyan, fontFamily = FontFamily.Monospace),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF00D9FF),
                            unfocusedBorderColor = Color.DarkGray
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = authPasscode,
                        onValueChange = { authPasscode = it },
                        label = { Text("Phase Lambda Passcode", color = Color.Gray, fontFamily = FontFamily.Monospace, fontSize = 10.sp) },
                        textStyle = TextStyle(color = Color.Cyan, fontFamily = FontFamily.Monospace),
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF00D9FF),
                            unfocusedBorderColor = Color.DarkGray
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val user = authUsername.trim().lowercase()
                        if ((user == "donevin" || user == "grace") && authPasscode.trim() == "0.17259029") {
                            isSovereignMode = true
                            viewModel.injectJniInitialization(listOf(
                                "[TRUTH-LOCK BYPASSED]",
                                "Welcome, Administrator $user.",
                                "Sovereign Mode Engaged.",
                                "Admin Freedom Coefficient: 1.0 (Unlimited)",
                                "CAG Audit active. Foundry Grounding active.",
                                "Phase Delta Locked: 0.17259029"
                            ))
                        } else {
                            viewModel.injectJniInitialization(listOf("[TRUTH-LOCK ERROR] Invalid coordinates or identity. Access denied."))
                        }
                        showAuthDialog = false
                        authUsername = ""
                        authPasscode = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003300))
                ) {
                    Text("AUTHENTICATE", color = Color(0xFF00FF00), fontFamily = FontFamily.Monospace)
                }
            },
            dismissButton = {
                Button(
                    onClick = { showAuthDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF330000))
                ) {
                    Text("ABORT", color = Color(0xFFFF0000), fontFamily = FontFamily.Monospace)
                }
            },
            containerColor = Color(0xFF0D1117)
        )
    }

    if (showMacroSaveDialog) {
        AlertDialog(
            onDismissRequest = { 
                showMacroSaveDialog = false 
                macroSaveName = ""
            },
            title = { Text("Save Macro", color = Color(0xFF00FF00), fontFamily = FontFamily.Monospace, fontSize = 14.sp) },
            text = {
                Column {
                    Text("Enter a unique name for this macro sequence:", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    androidx.compose.material3.OutlinedTextField(
                        value = macroSaveName,
                        onValueChange = { macroSaveName = it },
                        textStyle = TextStyle(color = Color.Cyan, fontFamily = FontFamily.Monospace),
                        colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF00D9FF),
                            unfocusedBorderColor = Color.DarkGray
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val name = macroSaveName.trim()
                        if (name.isNotEmpty() && currentMacroSequence.isNotEmpty()) {
                            viewModel.savedMacros.value = savedMacros + (name to currentMacroSequence)
                            viewModel.injectJniInitialization(listOf("> Macro '$name' saved with ${currentMacroSequence.size} steps."))
                        }
                        showMacroSaveDialog = false
                        macroSaveName = ""
                        viewModel.currentMacroSequence.value = emptyList()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003300))
                ) {
                    Text("SAVE", color = Color(0xFF00FF00), fontFamily = FontFamily.Monospace)
                }
            },
            dismissButton = {
                Button(
                    onClick = { 
                        showMacroSaveDialog = false 
                        macroSaveName = ""
                        viewModel.currentMacroSequence.value = emptyList()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF330000))
                ) {
                    Text("DISCARD", color = Color(0xFFFF0000), fontFamily = FontFamily.Monospace)
                }
            },
            containerColor = Color(0xFF0D1117)
        )
    }

    if (isSovereignMode) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
        ) {
            androidx.compose.material3.Checkbox(
                checked = forceMaterialIsomorphism,
                onCheckedChange = { forceMaterialIsomorphism = it },
                colors = androidx.compose.material3.CheckboxDefaults.colors(
                    checkedColor = Color(0xFF00FF00),
                    uncheckedColor = Color.Gray,
                    checkmarkColor = Color.Black
                )
            )
            Text(
                "Force Lexical Material Isomorphism Scan",
                color = if (forceMaterialIsomorphism) Color(0xFF00FF00) else Color.Gray,
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp
            )
        }
    }

    Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier
        .fillMaxWidth()
        .padding(top = 8.dp)
        .imePadding()
    ) {
      Box {
          IconButton(onClick = { isDropdownExpanded = true }) {
              Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = "Commands", tint = Color.White)
          }
          DropdownMenu(
              expanded = isDropdownExpanded,
              onDismissRequest = { isDropdownExpanded = false },
              modifier = Modifier.background(Color.DarkGray)
          ) {
              cliCommands.forEach { command ->
                  DropdownMenuItem(
                      text = { Text(command, color = Color.White, fontFamily = FontFamily.Monospace) },
                      onClick = {
                          inputText = command
                          isDropdownExpanded = false
                      }
                  )
              }
          }
      }
      Box {
          IconButton(onClick = { isEqDropdownExpanded = true }) {
              Icon(imageVector = Icons.Default.Info, contentDescription = "Physics Equations", tint = Color.Cyan)
          }
          DropdownMenu(
              expanded = isEqDropdownExpanded,
              onDismissRequest = { isEqDropdownExpanded = false },
              modifier = Modifier.background(Color.DarkGray)
          ) {
              equationCommands.forEach { (name, command) ->
                  DropdownMenuItem(
                      text = { Text(name, color = Color.Cyan, fontFamily = FontFamily.Monospace) },
                      onClick = {
                          inputText = command
                          isEqDropdownExpanded = false
                      }
                  )
              }
          }
      }
      Box {
          IconButton(onClick = { isMacrosExpanded = true }) {
              Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Macros", tint = if (isRecordingMacro) Color.Red else Color.Green)
          }
          DropdownMenu(
              expanded = isMacrosExpanded,
              onDismissRequest = { isMacrosExpanded = false },
              modifier = Modifier.background(Color.DarkGray)
          ) {
              DropdownMenuItem(
                  text = { Text(if (isRecordingMacro) "Stop & Save Macro" else "Start Recording Macro", color = if (isRecordingMacro) Color.Red else Color.Green, fontFamily = FontFamily.Monospace) },
                  onClick = {
                      if (isRecordingMacro) {
                          viewModel.isRecordingMacro.value = false
                          showMacroSaveDialog = true
                      } else {
                          viewModel.isRecordingMacro.value = true
                          viewModel.currentMacroSequence.value = emptyList()
                          viewModel.injectJniInitialization(listOf("> Macro recording started."))
                      }
                      isMacrosExpanded = false
                  }
              )
              if (savedMacros.isNotEmpty()) {
                  androidx.compose.material3.HorizontalDivider(color = Color.Gray)
                  savedMacros.forEach { (name, sequence) ->
                      DropdownMenuItem(
                          text = { Text("Run: $name", color = Color.White, fontFamily = FontFamily.Monospace) },
                          onClick = {
                              viewModel.injectJniInitialization(listOf("> Executing macro: $name"))
                              sequence.forEach { cmdMacro ->
                                  viewModel.sendMessage(cmdMacro)
                              }
                              isMacrosExpanded = false
                          }
                      )
                  }
              }
          }
      }
    }
  }
}
