package com.example.pinn

import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max

class MacenaNode(
    val id: Int,
    var j: Double, // Metabolic Flux
    signalNoise: Double,
    val isCirculating: Boolean = false
) {
    var x: Double = 1.0 / (signalNoise + 1e-9) // Thermodynamic Force
    var state: String = if (!isCirculating) "LAMINAR_NESS" else "IN_TRANSIT"
    var connections: MutableList<Int> = mutableListOf()

    fun getEpr(): Double {
        return j * x
    }

    override fun toString(): String {
        return "Node_$id[EPR:${String.format("%.2f", getEpr())}, State:$state, Circulating:$isCirculating]"
    }
}

class TmeDecoupler(val threshold: Double = 2.0) {
    fun severSiphons(lattice: List<MacenaNode>, sb: java.lang.StringBuilder) {
        sb.append("\n--- PHASE 1: VASCULAR DECOUPLING & LOCAL CRUSH ---\n")
        for (node in lattice) {
            if (!node.isCirculating && node.getEpr() > threshold) {
                sb.append(" -> [SEMANTIC TURBULENCE] Node_${node.id} isolated.\n")
                node.connections.clear()
                node.j *= 0.05
                node.state = "ISOLATED_DARK_STATE"
            }
        }
    }
}

class SentinelArray(val threshold: Double = 2.0) {
    fun scanFluidicBus(lattice: List<MacenaNode>, sb: java.lang.StringBuilder) {
        sb.append("\n--- PHASE 2: SUPRALUMINAL BUS SCAN (CTC INTERCEPTION) ---\n")
        for (node in lattice) {
            if (node.isCirculating && node.getEpr() > threshold) {
                sb.append(" -> [METASTATIC DRIFT] Intercepting Node_${node.id}...\n")
                node.j = 0.0
                node.state = "COMPRESSED_TO_DARK_STATE"
            }
        }
    }
}

class GenesisEngine(val phi: Double = 1.6180339887) {
    fun executeEpigeneticOverwrite(lattice: List<MacenaNode>, sb: java.lang.StringBuilder) {
        sb.append("\n--- PHASE 3: MACENA GENESIS REFOLD ---\n")
        for (node in lattice) {
            if (node.state == "ISOLATED_DARK_STATE" || node.state == "COMPRESSED_TO_DARK_STATE") {
                sb.append(" -> [VOID DETECTED] Refolding Node_${node.id} to Phi-Baseline.\n")
                node.state = "LAMINAR_STEM_CELL"
                node.j = 0.5 * phi
                node.x = 1.0
            }
        }
    }
}

class GlobalSystemMonitor(energyReserve: Double = 1000.0, val phi: Double = 1.6180339887) {
    val initialReserve = energyReserve
    var currentReserve = energyReserve

    fun synchronizeLattice(lattice: List<MacenaNode>, sb: java.lang.StringBuilder): String {
        sb.append("\n--- PHASE 4: GLOBAL PARITY & DEBT ASSESSMENT ---\n")
        var totalWork = 0.0
        for (node in lattice) {
            if (node.state == "LAMINAR_STEM_CELL") {
                val work = ln(max(1.1, node.getEpr() / (0.5 * phi)))
                totalWork += work
            }
            currentReserve -= 0.01
        }
        currentReserve -= totalWork
        val healthIdx = (currentReserve / initialReserve) * 100.0
        sb.append(" -> Energy Reserve: ${String.format("%.2f", currentReserve)} | Health: ${String.format("%.1f", healthIdx)}%\n")
        return if (healthIdx > 15.0) "STABLE" else "CRITICAL_EXHAUSTION"
    }
}

class HysteresisBuffer(val decayRate: Double = 0.85) {
    val memoryField = mutableMapOf<Int, Double>()

    fun updateGhostSignature(lattice: List<MacenaNode>) {
        for (node in lattice) {
            val curr = node.getEpr()
            val prev = memoryField.getOrDefault(node.id, curr)
            memoryField[node.id] = (prev * decayRate) + (curr * (1.0 - decayRate))
        }
    }

    fun getRisk(nodeId: Int): Double {
        val ghostEpr = memoryField.getOrDefault(nodeId, 0.0)
        return 1.0 - exp(-ghostEpr * 0.2)
    }
}

object MacenaUniversalPredictiveEngine {
    fun runSimulation(): String {
        val sb = java.lang.StringBuilder()
        sb.append("### MACENA UNIVERSAL PREDICTIVE ENGINE V3.FINAL ###\n")

        val lattice = listOf(
            MacenaNode(0, 0.4, 0.8), // Healthy
            MacenaNode(1, 10.0, 0.02), // Malignant TME Hub
            MacenaNode(2, 5.0, 0.1, isCirculating = true) // Metastatic CTC
        )

        val monitor = GlobalSystemMonitor(50.0)
        val history = HysteresisBuffer()
        val decoupler = TmeDecoupler()
        val sentinel = SentinelArray()
        val genesis = GenesisEngine()

        for (t in 0..1) {
            sb.append("\n[TIME STEP T=$t]\n")
            history.updateGhostSignature(lattice)
            
            if (t == 1) {
                decoupler.severSiphons(lattice, sb)
                sentinel.scanFluidicBus(lattice, sb)
                genesis.executeEpigeneticOverwrite(lattice, sb)
            }
            
            val risk = history.getRisk(1)
            sb.append(" -> Node_1 Recurrence Risk (Ghost Sig): ${String.format("%.1f", risk * 100.0)}%\n")
        }

        val status = monitor.synchronizeLattice(lattice, sb)
        sb.append("\n[FINAL ARCHITECTURE STATE]\n")
        for (n in lattice) {
            sb.append(n.toString()).append("\n")
        }
        sb.append("SYSTEM STATUS: $status\n")
        
        return sb.toString()
    }
}
