package com.example.pinn.parser

object KnotTopology {

    data class KnotEnergy(
        val mobiusEnergy: Float,
        val ropelength: Float,
        val dirichletEnergy: Float
    )

    fun calculateKnotEnergy(crossings: Int, writhe: Int): KnotEnergy {
        val c = if (crossings < 1) 1 else crossings
        // Heuristic mapping for standard knot energy models
        val mobiusEnergy = 4.0f * c + (Math.abs(writhe) * 1.5f)
        val ropelength = 2.0f * Math.pow(c.toDouble(), 1.33).toFloat()
        val dirichletEnergy = 1.2f * c + Math.abs(writhe)

        return KnotEnergy(mobiusEnergy, ropelength, dirichletEnergy)
    }

    data class SemanticInterference(
        val sourceAmplitude: Float,
        val targetAmplitude: Float,
        val phaseShiftRad: Float,
        val resultantAmplitude: Float,
        val interactionType: String
    )

    fun computeSemanticInterference(intentA: String, intentB: String): SemanticInterference {
        val aLength = intentA.length.toFloat()
        val bLength = intentB.length.toFloat()
        
        val aAmp = if (aLength > 0) aLength * 0.17259029f else 1.0f
        val bAmp = if (bLength > 0) bLength * 0.17259029f else 1.0f

        // Pseudo-phase difference based on Jaccard lexical distance
        val intersection = intentA.lowercase().toSet().intersect(intentB.lowercase().toSet()).size
        val union = intentA.lowercase().toSet().union(intentB.lowercase().toSet()).size
        val jaccard = if (union > 0) intersection.toFloat() / union.toFloat() else 0f
        
        // 0 jaccard -> pi phase shift (destructive)
        // 1 jaccard -> 0 phase shift (constructive)
        val phaseShift = ((1.0f - jaccard) * Math.PI).toFloat()

        val resultant = Math.sqrt((aAmp * aAmp + bAmp * bAmp + 2 * aAmp * bAmp * Math.cos(phaseShift.toDouble()))).toFloat()

        val type = if (Math.cos(phaseShift.toDouble()) > 0) "CONSTRUCTIVE (Resonance)" else "DESTRUCTIVE (Cancellation)"

        return SemanticInterference(aAmp, bAmp, phaseShift, resultant, type)
    }
}
