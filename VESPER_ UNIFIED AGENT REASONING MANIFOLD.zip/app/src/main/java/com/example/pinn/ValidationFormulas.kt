package com.example.pinn

import kotlin.math.abs
import kotlin.math.exp

/**
 * MODULE: UNIFIED MATHEMATICAL VALIDATION
 * Validates the latent space states against core thermodynamic and material equations.
 */
object ValidationFormulas {

    /**
     * Metric Charging Law
     * Δg_00 = ∫(Ψ · P_a) / (V · ρ) dt
     * 
     * Calculates the thermodynamic viability of a mapped topological manifold
     * returning a material scaling factor.
     */
    fun calculateMetricCharging(psi: Float, pA: Float, v: Float, rho: Float, dt: Float): Float {
        if (v == 0f || rho == 0f) return 0f
        return (psi * pA) / (v * rho) * dt
    }

    /**
     * Material Isomorphism Check
     * Validates if the metric charging law outputs are within the stable 0.17259029 Phase Delta.
     */
    fun checkMaterialIsomorphism(metricCharge: Float): Boolean {
        val delta = abs(metricCharge - VesperConstants.PHASE_DELTA.toFloat())
        return delta < 0.05f 
    }

    /**
     * Thermodynamic Hallucination Decay (THD)
     * Tracks the entropy of generated tokens and returns a deterministic confidence metric.
     * Decay = e^(-S / tau) where S is entropy summation.
     */
    fun calculateHallucinationDecay(entropy: Float, tau: Float): Float {
        if (tau == 0f) return 0f
        return exp(-entropy / tau)
    }

    /**
     * Resonance Coupled Output
     * Calculates semantic resonance score over multidimensional mappings.
     */
    fun calculateResonance(semanticVector: FloatArray, substrateVector: FloatArray): Float {
        if (semanticVector.size != substrateVector.size || semanticVector.isEmpty()) return 0f
        var dotProduct = 0f
        var magS = 0f
        var magSub = 0f
        for (i in semanticVector.indices) {
            dotProduct += semanticVector[i] * substrateVector[i]
            magS += semanticVector[i] * semanticVector[i]
            magSub += substrateVector[i] * substrateVector[i]
        }
        val denom = Math.sqrt((magS * magSub).toDouble()).toFloat()
        return if (denom == 0f) 0f else dotProduct / denom
    }
}
