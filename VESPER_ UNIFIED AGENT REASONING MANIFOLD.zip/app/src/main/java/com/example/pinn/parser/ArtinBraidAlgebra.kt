package com.example.pinn.parser

/**
 * Artin Braid Group (B_n) Generative Algebra.
 * Implements the topological strand crossings for the Universal Braid Syntax.
 */
object ArtinBraidAlgebra {

    /**
     * Represents an Artin Braid generator σ_i or its inverse σ_i^-1.
     * Index i indicates the strand crossing over strand i+1.
     */
    data class Generator(val index: Int, val isInverse: Boolean) {
        override fun toString(): String {
            return if (isInverse) "σ${index}⁻¹" else "σ${index}"
        }
    }

    /**
     * A Braid Word is a sequence of generators forming a topological braid.
     */
    data class BraidWord(val generators: List<Generator>) {
        override fun toString(): String {
            return generators.joinToString(" • ")
        }
        
        fun toCodeString(): String {
            if (generators.isEmpty()) return "Id"
            return generators.joinToString(" ") { 
                if (it.isInverse) "s${it.index}^-1" else "s${it.index}"
            }
        }
    }

    /**
     * Parses an Artin Braid string into a sequence of generators.
     * Supports formats: "s1 s2 s1^-1", "σ1 σ2⁻¹", "1 2 -1"
     */
    fun parseBraidSyntax(syntax: String): BraidWord {
        val tokens = syntax.split(Regex("[,\\s]+")).filter { it.isNotBlank() }
        val generators = tokens.mapNotNull { token ->
            val isInverse = token.endsWith("^-1") || token.endsWith("⁻¹") || token.endsWith("'") || token.startsWith("-")
            val cleanToken = token.replace("^-1", "")
                .replace("⁻¹", "")
                .replace("'", "")
                .replace("-", "")
                .replace("s", "")
                .replace("σ", "")
            
            val index = cleanToken.toIntOrNull()
            if (index != null && index > 0) Generator(index, isInverse) else null
        }
        return BraidWord(generators)
    }

    /**
     * Reduces the braid word through free group cancellation (σ_i • σ_i⁻¹ = Id).
     * Future expansions will include full Artin relations.
     */
    fun reduce(braid: BraidWord): BraidWord {
        val result = mutableListOf<Generator>()
        for (g in braid.generators) {
            if (result.isNotEmpty() && result.last().index == g.index && result.last().isInverse != g.isInverse) {
                result.removeAt(result.size - 1) // Free cancellation
            } else {
                result.add(g)
            }
        }
        return BraidWord(result)
    }
    
    /**
     * Evaluates the Yang-Baxter energy state of the current braid configuration
     */
    fun evaluateEnergy(braid: BraidWord): Float {
        val crossingCount = braid.generators.size
        val inverseCount = braid.generators.count { it.isInverse }
        val forwardCount = crossingCount - inverseCount
        
        // Custom topological energy mapped around Phase Delta (0.17259029)
        val phaseDelta = 0.17259029f
        return (forwardCount - inverseCount) * phaseDelta
    }

    /**
     * Calculates the deterministic structural bounds for polynomial invariants of the braid closure.
     */
    data class PolynomialBounds(
        val writhe: Int,
        val maxCrossings: Int,
        val jonesDegreeSpan: Int,
        val alexanderDegreeBound: Int
    )

    fun calculateInvariants(braid: BraidWord): PolynomialBounds {
        val cPlus = braid.generators.count { !it.isInverse }
        val cMinus = braid.generators.count { it.isInverse }
        val writhe = cPlus - cMinus
        val crossings = cPlus + cMinus
        
        // Skein relation bounds estimation
        // The span of the Jones polynomial is at most the crossing number
        val jonesSpan = crossings 
        // The degree of the Alexander polynomial is at most c / 2
        val alexanderBound = crossings / 2
        
        return PolynomialBounds(writhe, crossings, jonesSpan, alexanderBound)
    }
}
