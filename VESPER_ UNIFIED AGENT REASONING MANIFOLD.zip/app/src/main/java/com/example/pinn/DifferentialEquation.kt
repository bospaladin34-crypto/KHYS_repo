package com.example.pinn

/**
 * Interface representing a mathematical differential equation
 * to be enforced by the Physics-Informed Neural Network (PINN).
 */
interface DifferentialEquation {
    val id: String
    val description: String
    
    /**
     * Evaluates the physical residual.
     * In a full implementation, this might build a symbolic computation graph
     * or utilize C++ JNI representations with TF Lite.
     * @param inputs Example independent variables (e.g. x, t)
     * @param outputs Current network predictions (e.g. u(x,t))
     * @param gradients Gradients (e.g. du/dx, d^2u/dx^2, du/dt)
     * @return The residual loss, which should approach 0
     */
    fun evaluateResidual(inputs: FloatArray, outputs: FloatArray, gradients: FloatArray): Float
}
