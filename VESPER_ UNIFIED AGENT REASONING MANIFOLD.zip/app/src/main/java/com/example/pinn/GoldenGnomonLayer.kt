package com.example.pinn

import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

const val PHI_INV = 0.6180339887498948f

class DarkStateException(message: String) : Exception(message)

class Rectifier(val wShear: FloatArray?, val strength: Float) {
    fun call(h: FloatArray): FloatArray {
        if (wShear == null) return h.copyOf()
        val size = h.size
        val result = FloatArray(size)
        for (i in 0 until size) {
            var dot = 0f
            for (j in 0 until size) {
                dot += wShear[i * size + j] * h[j]
            }
            result[i] = h[i] + strength * dot
        }
        return result
    }
}

class Verifier(val maxNorm: Float?) {
    fun check(h: FloatArray): Boolean {
        if (maxNorm != null) {
            var normSq = 0f
            for (v in h) normSq += v * v
            if (sqrt(normSq) > maxNorm) return false
        }
        return true
    }
}

class GoldenGnomonLayer(val dim: Int, seed: Long = 0L, maxNorm: Float? = null) {
    private val random = Random(seed)
    private val u = FloatArray(dim) { random.nextFloat() * 2 - 1f }
    private val v = FloatArray(dim) { random.nextFloat() * 2 - 1f }
    private val rectifier = Rectifier(null, 0f)
    private val verifier = Verifier(maxNorm)
    private val rotatePlane: (FloatArray) -> FloatArray

    init {
        val theta = (3.0 * Math.PI / 5.0).toFloat() // 108 degrees
        rotatePlane = makeRotationPlane(u, v, theta)
    }

    private fun orthonormalize(vec: FloatArray): FloatArray {
        var normSq = 0f
        for (x in vec) normSq += x * x
        val norm = sqrt(normSq) + 1e-12f
        return FloatArray(vec.size) { vec[it] / norm }
    }

    private fun dot(a: FloatArray, b: FloatArray): Float {
        var sum = 0f
        for (i in a.indices) sum += a[i] * b[i]
        return sum
    }

    private fun makeRotationPlane(uIn: FloatArray, vIn: FloatArray, thetaRad: Float): (FloatArray) -> FloatArray {
        val uNorm = orthonormalize(uIn)
        val proj = dot(vIn, uNorm)
        val vOrth = FloatArray(dim) { vIn[it] - proj * uNorm[it] }
        val vNorm = orthonormalize(vOrth)

        val cosT = cos(thetaRad)
        val sinT = sin(thetaRad)

        return { h: FloatArray ->
            val a = dot(h, uNorm)
            val b = dot(h, vNorm)
            val aP = cosT * a - sinT * b
            val bP = sinT * a + cosT * b

            val hRot = FloatArray(dim)
            for (i in 0 until dim) {
                hRot[i] = h[i] - a * uNorm[i] - b * vNorm[i] + aP * uNorm[i] + bP * vNorm[i]
            }
            hRot
        }
    }

    fun stop(h: FloatArray): FloatArray {
        return h.copyOf()
    }

    fun rectify(h: FloatArray): FloatArray {
        return rectifier.call(h)
    }

    fun verify(h: FloatArray): FloatArray {
        if (!verifier.check(h)) {
            throw DarkStateException("Invariant violation: norm out of bounds.")
        }
        return h
    }

    fun act(h: FloatArray): FloatArray {
        val hRot = rotatePlane(h)
        return FloatArray(dim) { hRot[it] * PHI_INV }
    }

    fun call(h: FloatArray): FloatArray {
        // SANTOS: Stop -> Rectify -> Verify -> Act -> Output
        val h0 = stop(h)
        val h1 = rectify(h0)
        val h2 = verify(h1)
        val h3 = act(h2)
        return h3
    }
}
