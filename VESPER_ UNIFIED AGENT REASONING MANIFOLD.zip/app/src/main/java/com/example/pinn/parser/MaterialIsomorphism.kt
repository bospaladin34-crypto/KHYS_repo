package com.example.pinn.parser

object MaterialIsomorphism {

    data class Material(
        val name: String,
        val energyDensityMjKg: Float,
        val thermalDegradationK: Float,
        val volumeDensityKgM3: Float,
        val description: String
    )

    val materialCodex = listOf(
        Material("Titanium-Aluminide Matrix (TiAl)", 4.8f, 1200f, 3900f, "High temperature structural applications."),
        Material("Graphene Aerogel Substrate", 0.05f, 3500f, 1.6f, "Ultra-lightweight thermal lattice."),
        Material("Bismuth Telluride (Bi2Te3)", 1.2f, 500f, 7700f, "Thermoelectric charging layer."),
        Material("Yttrium Barium Copper Oxide (YBCO)", 0.8f, 92f, 6300f, "High-temperature superconductor trace."),
        Material("Silicon Carbide (SiC)", 5.5f, 1600f, 3210f, "High-voltage power substrate."),
        Material("Niobium-Titanium (NbTi)", 1.0f, 10f, 5700f, "Low-temperature superconductor coil.")
    )

    fun mapConceptToMaterial(concept: String): Material {
        val lower = concept.lowercase()
        return when {
            lower.contains("aero") || lower.contains("light") || lower.contains("lattice") -> materialCodex[1]
            lower.contains("thermo") || lower.contains("heat") -> materialCodex[2]
            lower.contains("super") || lower.contains("conduct") || lower.contains("flux") || lower.contains("coil") -> materialCodex[5]
            lower.contains("power") || lower.contains("voltage") || lower.contains("compute") || lower.contains("engine") -> materialCodex[4]
            else -> materialCodex[0] // Default TiAl
        }
    }

    fun metricChargingLawViability(material: Material, psi: Float = 1.0f, pa: Float = 1.0f): Float {
        // Δg_00 = ∫(Ψ · P_a) / (V · ρ) dt
        // Assuming unit Integration metrics for conceptual bounds (V=1.0, dt=1.0)
        val deltaG00 = (psi * pa) / material.volumeDensityKgM3
        val baselineDelta = 0.17259029f
        // Return ratio normalized to Phase Delta
        return (deltaG00 / baselineDelta)
    }
}
