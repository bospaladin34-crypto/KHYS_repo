package com.example.pinn

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Latent Coordinate System Engine
 * Defines geometrically exact layouts for:
 * 1. Penrose P3 Tilings (via De Bruijn Pentagrid Intersections)
 * 2. E6, E7, E8 Lie Group Root System Projections mapped onto the Coxeter Plane
 */
object LatentCoordinateSystem {

    fun generateE8(scale: Float, phaseShift: Float = 0f): List<Pair<Float, Float>> {
         val exponents = listOf(1, 7, 11, 13, 17, 19, 23, 29)
         val h = 30 // Coxeter Number
         return generateCoxeter(scale, phaseShift, h, exponents)
    }

    fun generateE7(scale: Float, phaseShift: Float = 0f): List<Pair<Float, Float>> {
         val exponents = listOf(1, 5, 7, 9, 11, 13, 17)
         val h = 18 // Coxeter Number
         return generateCoxeter(scale, phaseShift, h, exponents)
    }

    fun generateE6(scale: Float, phaseShift: Float = 0f): List<Pair<Float, Float>> {
         val exponents = listOf(1, 4, 5, 7, 8, 11)
         val h = 12 // Coxeter Number
         return generateCoxeter(scale, phaseShift, h, exponents)
    }

    private fun generateCoxeter(scale: Float, phaseShift: Float, h: Int, exponents: List<Int>): List<Pair<Float, Float>> {
         val roots = mutableListOf<Pair<Float, Float>>()
         for (m in exponents) {
             val r = scale * sin(m * PI.toFloat() / h)
             for (k in 0 until h) {
                 val angle = phaseShift + k * (2f * PI.toFloat() / h)
                 roots.add(Pair(r * cos(angle), r * sin(angle)))
             }
         }
         return roots
    }

    /**
     * Maps De Bruijn pentagrids intersections to aperiodic Penrose P3 tile vertices
     */
    fun generatePenroseP3Grid(scale: Float, gridDensity: Int, phase: Float): List<Pair<Float, Float>> {
         val points = mutableSetOf<Pair<Int, Int>>() // Spatial HashSet to prevent float drift dupes
         val finalPoints = mutableListOf<Pair<Float, Float>>()
         val pentagridAngles = FloatArray(5) { i -> i * PI.toFloat() / 5f }
         
         // Perturbation vector to maintain aperiodicity shifting
         val gamma = FloatArray(5) { i -> phase + (i * 0.13f) } 

         for (i in 0 until 4) {
             for (j in i + 1 until 5) {
                 val sinDiff = sin(pentagridAngles[j] - pentagridAngles[i])
                 if (sinDiff == 0f) continue

                 for (k in -gridDensity..gridDensity) {
                     for (l in -gridDensity..gridDensity) {
                         // Line-line intersection across standard pentagrids
                         val x = ((k + gamma[i]) * sin(pentagridAngles[j]) - (l + gamma[j]) * sin(pentagridAngles[i])) / sinDiff
                         val y = ((l + gamma[j]) * cos(pentagridAngles[i]) - (k + gamma[i]) * cos(pentagridAngles[j])) / sinDiff
                         
                         var vx = 0f
                         var vy = 0f
                         for (m in 0 until 5) {
                             // Project mathematically to the sum of integer vectors
                             val km = Math.ceil((x * cos(pentagridAngles[m]) + y * sin(pentagridAngles[m]) - gamma[m]).toDouble()).toFloat()
                             vx += km * cos(pentagridAngles[m])
                             vy += km * sin(pentagridAngles[m])
                         }
                         val px = vx * scale
                         val py = vy * scale
                         
                         val hx = (px * 100).toInt()
                         val hy = (py * 100).toInt()
                         if (points.add(Pair(hx, hy))) {
                             finalPoints.add(Pair(px, py))
                         }
                     }
                 }
             }
         }
         return finalPoints
    }
}
