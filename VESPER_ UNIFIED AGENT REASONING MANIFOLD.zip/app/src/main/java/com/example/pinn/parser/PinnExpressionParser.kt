package com.example.pinn.parser

enum class TokenType {
    NUMBER, IDENTIFIER, PLUS, MINUS, MULT, DIV, EQUALS, EOF, LPAREN, RPAREN
}

data class Token(val type: TokenType, val text: String)

sealed class AstNode {
    abstract fun toLatex(): String
    
    data class Num(val value: Double) : AstNode() {
        override fun toLatex() = value.toString()
    }
    data class Var(val name: String) : AstNode() {
        override fun toLatex() = name.replace("_", "\\_")
    }
    data class Derivative(val dependent: String, val independent: String, val order: Int) : AstNode() {
        override fun toLatex(): String {
            return if (order > 1) {
                "\\frac{\\partial^{$order} ${dependent}}{\\partial ${independent}^{$order}}"
            } else {
                "\\frac{\\partial ${dependent}}{\\partial ${independent}}"
            }
        }
    }
    data class BinOp(val left: AstNode, val op: Char, val right: AstNode) : AstNode() {
        override fun toLatex(): String {
            return if (op == '/') {
                "\\frac{${left.toLatex()}}{${right.toLatex()}}"
            } else {
                "(${left.toLatex()} $op ${right.toLatex()})"
            }
        }
    }
    data class Equation(val lhs: AstNode, val rhs: AstNode) : AstNode() {
        override fun toLatex() = "${lhs.toLatex()} = ${rhs.toLatex()}"
    }
}

class PinnLexer(private val input: String) {
    private var pos = 0

    fun tokenize(): List<Token> {
        val tokens = mutableListOf<Token>()
        while (pos < input.length) {
            val c = input[pos]
            when {
                c.isWhitespace() -> pos++
                c == '+' -> { tokens.add(Token(TokenType.PLUS, "+")); pos++ }
                c == '-' -> { tokens.add(Token(TokenType.MINUS, "-")); pos++ }
                c == '*' -> { tokens.add(Token(TokenType.MULT, "*")); pos++ }
                c == '/' -> { tokens.add(Token(TokenType.DIV, "/")); pos++ }
                c == '=' -> { tokens.add(Token(TokenType.EQUALS, "=")); pos++ }
                c == '(' -> { tokens.add(Token(TokenType.LPAREN, "(")); pos++ }
                c == ')' -> { tokens.add(Token(TokenType.RPAREN, ")")); pos++ }
                c.isLetter() -> {
                    val start = pos
                    while (pos < input.length && (input[pos].isLetterOrDigit() || input[pos] == '_')) {
                        pos++
                    }
                    tokens.add(Token(TokenType.IDENTIFIER, input.substring(start, pos)))
                }
                c.isDigit() || c == '.' -> {
                    val start = pos
                    while (pos < input.length && (input[pos].isDigit() || input[pos] == '.')) {
                        pos++
                    }
                    tokens.add(Token(TokenType.NUMBER, input.substring(start, pos)))
                }
                else -> throw IllegalArgumentException("Unknown character: $c")
            }
        }
        tokens.add(Token(TokenType.EOF, ""))
        return tokens
    }
}

class PinnParser(private val tokens: List<Token>) {
    private var current = 0

    fun parse(): AstNode {
        val result = expression()
        if (match(TokenType.EQUALS)) {
            val rhs = expression()
            return AstNode.Equation(result, rhs)
        }
        return result
    }

    private fun match(vararg types: TokenType): Boolean {
        for (type in types) {
            if (check(type)) {
                current++
                return true
            }
        }
        return false
    }

    private fun check(type: TokenType): Boolean {
        if (isAtEnd()) return false
        return tokens[current].type == type
    }

    private fun isAtEnd(): Boolean = tokens[current].type == TokenType.EOF

    private fun advance(): Token {
        if (!isAtEnd()) current++
        return tokens[current - 1]
    }

    private fun expression(): AstNode {
        return term()
    }

    private fun term(): AstNode {
        var expr = factor()
        while (match(TokenType.PLUS, TokenType.MINUS)) {
            val op = tokens[current - 1].text[0]
            val right = factor()
            expr = AstNode.BinOp(expr, op, right)
        }
        return expr
    }

    private fun factor(): AstNode {
        var expr = primary()
        while (match(TokenType.MULT, TokenType.DIV)) {
            val op = tokens[current - 1].text[0]
            val right = primary()
            expr = AstNode.BinOp(expr, op, right)
        }
        return expr
    }

    private fun primary(): AstNode {
        if (match(TokenType.NUMBER)) {
            return AstNode.Num(tokens[current - 1].text.toDouble())
        }
        if (match(TokenType.IDENTIFIER)) {
            val name = tokens[current - 1].text
            // Identifier check for derivative: e.g., d2u_dx2
            if (name.startsWith("d") && name.contains("_d")) {
                return parseDerivativeIdentifier(name)
            }
            return AstNode.Var(name)
        }
        if (match(TokenType.LPAREN)) {
            val expr = expression()
            match(TokenType.RPAREN)
            return expr
        }
        throw IllegalArgumentException("Unexpected token: ${tokens[current]}")
    }

    private fun parseDerivativeIdentifier(name: String): AstNode {
        try {
            val parts = name.split("_d")
            if (parts.size == 2) {
                val first = parts[0].substring(1) // remove leading 'd'
                val orderStr = first.takeWhile { it.isDigit() }
                val order = if (orderStr.isEmpty()) 1 else orderStr.toInt()
                val dep = first.substring(orderStr.length)
                
                val indComponent = parts[1] // e.g., x2 or t
                val ind = indComponent.takeWhile { !it.isDigit() }
                return AstNode.Derivative(dep, ind, order)
            }
        } catch (e: Exception) {
            // Fallback
        }
        return AstNode.Var(name)
    }
}
