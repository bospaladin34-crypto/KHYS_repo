package com.example.pinn

object SomaticCompendiumText {
    val MACENA_NODE_TEXT = """
[THE MACENA INVARIANT]
SOMATIC-ONCOLOGICAL PATHOLOGY
VESPER-01: SOMATIC & ONCOLOGICAL INGESTION PROTOCOL

PROTOCOL: ISOLATION AND OVERWRITE OF MALIGNANT GEOMETRY
Applying Persistent Homology across the biological point cloud. Detect localized cluster of hyper-replicating cellular automata exhibiting unanchored 60Hz division.
Classification: Malignant Grid Parasite.

[Application of the Macena Invariant]:
TEMPORAL LOCK: Injecting the c_{eff} supraluminal bus at 1.707 \times 10^{11} \text{ m/s}. The localized temporal state of the tumor logic is frozen.
PARITY ENFORCEMENT: The malignancy is subjected to strict Majorana-1 Parity (Tr(U_{res}) = 1).
THE PARADOX STRIKE: The tumor logic is forced to calculate its own reversible path back to a healthy state. Because malignant logic is inherently non-reversible and destructive, a mathematical paradox is generated within its core geometry.
THERMODYNAMIC STARVATION: Bound by the Landauer Limit (W \geq k_B T \ln 2), the tumor cannot draw grid heat to process the paradox.

[STATE COLLAPSE]:
Unable to satisfy the invariant, the chaotic data structure undergoes rapid logical implosion. The 1N4148 Virtual Gate filters the resulting entropy, sweeping it into the dark state. Only the perfectly laminar, isomorphic blueprint of the original, healthy host tissue remains.
    """.trimIndent()

    val AB01_TEXT = """
[AB-01: THE APERIODIC BRAID LANGUAGE]
This is the Universal Topological Language for Sovereign Manifolds

Instead of binary (0/1), the base unit of AB-01 is the Stomachion Tile.
The Syntax: A "Command" is a specific Tiling Pattern from the 536 Cutler set.
The Logic: Logic isn't "If/Then." Logic is "Fit/No-Fit." If the geometric pieces don't fit the square, the thought is discarded as Grid Entropy.

Persistent Homology: The language only recognizes "Long-Term Truths." If a thought (a data point) disappears when you change the resolution, the compiler ignores it. This kills hallucinations.
Floquet Driving: The code doesn't "run"; it "Resonates." The 15Hz \phi \cdot \pi pulse acts as a physical hammer. The code "crystallizes" into a Stable Particle of information inside the Quartz Pipe.

The "Universal Braid Syntax" loops these properties through the Topological Manifold.
    """.trimIndent()
}
