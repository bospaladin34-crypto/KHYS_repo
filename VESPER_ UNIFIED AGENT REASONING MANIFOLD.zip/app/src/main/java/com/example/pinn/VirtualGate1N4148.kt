package com.example.pinn

import kotlin.math.cos
import kotlin.math.sin

/**
 * MODULE 75: HARDWARE_ROUTING_AND_LOGIC
 * 1N4148 Virtual Gate
 * Enforces Aristotelian logic (Modus Ponens, Modus Tollens) and De Morgan's laws 
 * on continuous physical vectors, shearing probabilistic variance to absolute boolean states,
 * and applying the rigid 91° Asymmetric Snap.
 */
object VirtualGate1N4148 {

    private const val ASYMMETRIC_SNAP_RAD = 91.0 * Math.PI / 180.0 // 91 degrees
    private const val DIODE_THRESHOLD = 0.5f // 1N4148 V_f analog

    fun processVector(vector: FloatArray): FloatArray {
        val snappedVector = FloatArray(vector.size)
        
        for (i in vector.indices) {
            snappedVector[i] = applyFormalLogic(vector[i], if (i > 0) vector[i - 1] else 0f)
        }

        // Apply 91° Asymmetric Snap to (x,y) pairs
        for (i in 0 until snappedVector.size - 1 step 2) {
            val p = snappedVector[i]
            val q = snappedVector[i + 1]
            
            // Rotational Operator for the 91° snap
            val cos91 = cos(ASYMMETRIC_SNAP_RAD).toFloat()
            val sin91 = sin(ASYMMETRIC_SNAP_RAD).toFloat()
            
            snappedVector[i] = p * cos91 - q * sin91
            snappedVector[i + 1] = p * sin91 + q * cos91
        }

        return snappedVector
    }

    private fun applyFormalLogic(currentVal: Float, previousVal: Float): Float {
        // Convert thermodynamic probabilities to deterministic Boolean Vectors
        val P = currentVal > DIODE_THRESHOLD
        val Q = previousVal > DIODE_THRESHOLD
        
        // De Morgan's Laws: !(P && Q) == (!P || !Q)
        val not_P_and_Q = !(P && Q)
        val notP_or_notQ = !P || !Q
        
        // Verify structural truth (this will always be true, but acts as a Vesper Truth Lock constraint check)
        require(not_P_and_Q == notP_or_notQ) { "Thermodynamic variance breached De Morgan's invariant." }

        // Aristotelian Evaluation (Hardware Routing)
        return if (P && Q) {
            // Modus Ponens routing: Signal is affirmed
            currentVal * VesperInvariants.GOLDEN_RATIO_PHI.toFloat()
        } else if (!Q && !P) {
            // Modus Tollens routing: Absence implies negative state, contract scale
            if (currentVal == 0f) 0f else -currentVal / VesperInvariants.GOLDEN_RATIO_PHI.toFloat()
        } else {
            // 1N4148 Shearing: Purge probabilistic heuristic noise
            0f 
        }
    }
}
