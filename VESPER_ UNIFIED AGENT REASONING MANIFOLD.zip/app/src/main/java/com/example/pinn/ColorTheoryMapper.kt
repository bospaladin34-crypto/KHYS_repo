package com.example.pinn

import android.graphics.Color as AndroidColor
import androidx.compose.ui.graphics.Color

/**
 * Color Mapping Service
 * Assigns spectral values to physical data clusters using professional color theory standards.
 * Synchronizes with Cymatic resonance, Lie Group manifolds, and Cellular Sheaf topologies.
 */
object ColorTheoryMapper {

    enum class ColorScale {
        CYMATIC_SPECTRUM, // Maps sound harmonics to visual light spectrum
        E8_ROOT_WEIGHT,   // Distributes exceptional roots over aesthetic thermodynamic palettes
        SHEAF_DENSITY     // Maps sheaf intersection clusters to luminance and saturation shifts
    }

    /**
     * Maps a normalized physical data value (0.0 to 1.0) to a professional color representation.
     */
    fun mapValueToColor(value: Float, mode: ColorScale, alpha: Float = 1f): Color {
        val t = value.coerceIn(0f, 1f)
        val hue: Float
        val sat: Float
        val light: Float

        when (mode) {
            ColorScale.CYMATIC_SPECTRUM -> {
                // Hue transition from Crimson Red (0) to Violet (270)
                // Representing frequency escalation mapped to the visible light spectrum
                hue = t * 270f
                sat = 0.85f
                light = 0.95f
            }
            ColorScale.E8_ROOT_WEIGHT -> {
                // E8 Root systems clustered into continuous thermodynamic aesthetic gradients
                // Maps into Gold -> Orange -> Violet
                // 0.0 -> Gold, 0.5 -> Coral, 1.0 -> Violet/Magenta
                hue = 45f + t * 235f // 45 (Yellow/Gold) -> 280 (Violet/Magenta)
                sat = 0.7f + (t * 0.2f)
                light = 0.9f
            }
            ColorScale.SHEAF_DENSITY -> {
                // Archimedean Sheaf aesthetic: Teal / Cyan (data) on deep void background
                // Cold/Dense is dark teal, Active/Sparse is bright Ice blue/white
                hue = 180f + t * 40f // 180 (Cyan) to 220 (Blue)
                sat = 1.0f - (t * 0.4f)
                light = 0.3f + (t * 0.7f)
            }
        }
        
        val alphaInt = (alpha.coerceIn(0f, 1f) * 255).toInt()
        val hsv = floatArrayOf(hue, sat, light)
        val androidColor = AndroidColor.HSVToColor(alphaInt, hsv)
        return Color(androidColor)
    }
}
