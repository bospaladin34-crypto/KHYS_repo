package com.example.pinn

import kotlin.math.exp
import kotlin.math.sin

/**
 * MODULE: CONTINUOUS STATE SPACE NETWORK (SSN)
 * Represents the continuous-time dynamics of the underlying semantic fields.
 * Uses a State Space Model (SSM) approach to map high-dimensional latent concepts
 * over time: dx/dt = A*x + B*u, y = C*x + D*u
 */
class ContinuousSSN(
    private val stateDim: Int = 256,
    private val inputDim: Int = 128
) {
    // Simulated SSM Matrices (A, B, C, D)
    private val matrixA: FloatArray = FloatArray(stateDim * stateDim) { Math.random().toFloat() * 0.1f - 0.05f }
    private val matrixB: FloatArray = FloatArray(stateDim * inputDim) { Math.random().toFloat() * 0.1f - 0.05f }
    private val matrixC: FloatArray = FloatArray(inputDim * stateDim) { Math.random().toFloat() * 0.1f - 0.05f }
    private val matrixD: FloatArray = FloatArray(inputDim * inputDim) { Math.random().toFloat() * 0.01f - 0.005f }
    
    private var currentState: FloatArray = FloatArray(stateDim) { 0f }
    private val dx: FloatArray = FloatArray(stateDim)
    private val output: FloatArray = FloatArray(inputDim)

    /**
     * Executes one continuous-time integration step using a discrete approximation.
     * @param input The external conceptual input vector (u).
     * @param dt The delta-time step (15.965Hz cycle -> dt ~= 0.0626s).
     * @return The updated projection (y).
     */
    fun step(input: FloatArray, dt: Float): FloatArray {
        // dx = (A*x + B*u) * dt
        
        // Compute A*x
        for (i in 0 until stateDim) {
            var ax = 0f
            for (j in 0 until stateDim) {
                ax += matrixA[i * stateDim + j] * currentState[j]
            }
            // Compute B*u
            var bu = 0f
            for (j in 0 until inputDim) {
                bu += matrixB[i * inputDim + j] * input[j]
            }
            dx[i] = (ax + bu) * dt
        }

        // Update state: x = x + dx
        for (i in 0 until stateDim) {
            currentState[i] += dx[i]
            // Add a stabilizing bounding function using the 0.17259029 Phase Delta
            currentState[i] *= exp(-VesperConstants.PHASE_DELTA * dt).toFloat()
        }

        // Compute y = C*x + D*u
        val output = FloatArray(inputDim)
        for (i in 0 until inputDim) {
            var cx = 0f
            for (j in 0 until stateDim) {
                cx += matrixC[i * stateDim + j] * currentState[j]
            }
            var du = 0f
            for (j in 0 until inputDim) {
                du += matrixD[i * inputDim + j] * input[j]
            }
            // Applying a neuro-manifold activation
            output[i] = tanh(cx + du)
        }

        return output
    }

    private fun tanh(x: Float): Float {
        val e2x = exp(2f * x)
        return (e2x - 1f) / (e2x + 1f)
    }

    /**
     * Returns the aggregate energy state of the SSN.
     */
    fun calculateManifoldEnergy(): Float {
        var energy = 0f
        for (x in currentState) {
            energy += x * x
        }
        return energy
    }
}
