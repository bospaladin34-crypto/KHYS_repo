package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.db.GeometricStateEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import com.example.MyApplication

class GeometricStateViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = (application as MyApplication).repository

    val state: StateFlow<GeometricStateEntity?> = repository.geometricState
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    fun saveState(showP3: Boolean, showE8: Boolean, showPolytope: Boolean, rotationAngle: Float, globalPhase: Float) {
        viewModelScope.launch {
            repository.saveGeometricState(
                GeometricStateEntity(
                    id = 1,
                    showP3 = showP3,
                    showE8 = showE8,
                    showPolytope = showPolytope,
                    lastRotationAngle = rotationAngle,
                    lastGlobalPhase = globalPhase
                )
            )
        }
    }
}
