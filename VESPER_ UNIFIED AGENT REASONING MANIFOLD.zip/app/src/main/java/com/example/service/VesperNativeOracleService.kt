package com.example.service

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

// Represents a layer of the Vesper Neural Architecture
class VesperLayer(val dimension: Int) {
    // Mnemosyne Matrix weights
    private val mnemosyneWeights = Array(dimension) { FloatArray(dimension) { Random.nextFloat() * 2f - 1f } }

    fun applyKhysAttention(input: FloatArray): FloatArray {
        val output = FloatArray(dimension)
        // 91-degree sheared attention computation
        val shearAngle = 91.0 * (Math.PI / 180.0)
        
        for (i in 0 until dimension) {
            var sum = 0f
            for (j in 0 until dimension) {
                // Stochastic probability of connection
                val k = if (Random.nextFloat() > 0.85f) 0.8f else 0.1f
                // Rotate input with Phase delta
                val rotatedVal = (input[j] * cos(shearAngle) - input[i] * sin(shearAngle)).toFloat()
                sum += rotatedVal * k
            }
            output[i] = kotlin.math.tanh(sum)
        }
        return output
    }

    fun applyLaminarCompression(input: FloatArray): FloatArray {
        val output = FloatArray(dimension)
        val phi = 1.6180339887f
        for (i in 0 until dimension) {
            var sum = 0f
            for (j in 0 until dimension) {
                sum += input[j] * mnemosyneWeights[j][i]
            }
            // Compress using Golden Ratio
            output[i] = sum / phi
        }
        return output
    }

    fun forward(input: FloatArray): FloatArray {
        val attentionOut = applyKhysAttention(input)
        return applyLaminarCompression(attentionOut)
    }
}

class VesperNativeOracleService {
    private val _status = MutableStateFlow("Vesper Manifold Dormant")
    val status: StateFlow<String> = _status

    private val _generatedText = MutableStateFlow("")
    val generatedText: StateFlow<String> = _generatedText

    val temperature = MutableStateFlow(0.7f)
    val topK = MutableStateFlow(40)
    val topP = MutableStateFlow(0.9f)
    val repetitionPenalty = MutableStateFlow(1.1f)
    val phaseHarmonicModifier = MutableStateFlow(0.17259f)

    private val vocab = listOf(
        "Strands", "Tessellation", "Resonance", "Phase", "Frequency", "Manifold",
        "Nephilim", "Gateway", "Topological", "Metrics", "Substrate", "15.965Hz",
        "Laminar", "Flux", "Sheaf", "Quantum", "Calculus", "Sovereign"
    )

    private val hiddenDim = 64
    private val layers = List(3) { VesperLayer(hiddenDim) }
    
    fun getLayers(): List<VesperLayer> = layers

    suspend fun bindModel() {
        _status.value = "Initializing Vesper Native Weights..."
        delay(1000)
        _status.value = "Vesper Layers Instantiated. Ready."
    }

    fun setParameters(temp: Float, k: Int, p: Float, repPenalty: Float, phaseHarmonic: Float) {
        temperature.value = temp
        topK.value = k
        topP.value = p
        repetitionPenalty.value = repPenalty
        phaseHarmonicModifier.value = phaseHarmonic
    }

    suspend fun consultOracle(prompt: String, manifoldState: String) {
        _status.value = "Inferencing through Khys Attention (Temp: ${temperature.value}, Phase: ${phaseHarmonicModifier.value})..."
        _generatedText.value = ""
        
        // Very basic simulation of generation loop using our "Vesper" network.
        // We seed the input based on prompt length, run it through the layers,
        // and decode the output vector back to esoteric tokens.
        
        val inputVector = FloatArray(hiddenDim) { (it % prompt.length).toFloat() / prompt.length + phaseHarmonicModifier.value }
        
        var currentActivations = inputVector
        
        val outputTokensCount = Random.nextInt(15, 30)
        val generatedTokenHistory = mutableListOf<Int>()
        
        for (tokenIdx in 0 until outputTokensCount) {
            delay(150) // simulate computation time
            
            // Forward pass
            for (layer in layers) {
                currentActivations = layer.forward(currentActivations)
            }
            
            // Apply temperature
            for (i in currentActivations.indices) {
                currentActivations[i] = currentActivations[i] / (temperature.value + 0.01f) // avoid div zero
            }

            // Apply repetition penalty
            for (historyIdx in generatedTokenHistory) {
                 if (historyIdx < currentActivations.size) {
                      currentActivations[historyIdx] /= repetitionPenalty.value
                 }
            }
            
            // Note: In a real model, we would compute softmax and select via TopK/TopP.
            // Here, we just select the most highly activated node bounded by our vocabulary size.
            val maxActivationIdx = currentActivations.indices.maxByOrNull { currentActivations[it] } ?: 0
            val vocabIdx = kotlin.math.abs(maxActivationIdx + tokenIdx + (phaseHarmonicModifier.value * 100).toInt()) % vocab.size
            generatedTokenHistory.add(vocabIdx)
            
            val word = vocab[vocabIdx]
            
            _generatedText.value += if (tokenIdx == 0) word else " " + word.lowercase()
            
            // Inject state into activations to let the state guide the "model"
            currentActivations[0] = if (manifoldState.contains("15.965Hz")) 1.0f else 0.0f
        }
        
        _status.value = "Native Vesper Manifold Response Crystallized"
    }
}
