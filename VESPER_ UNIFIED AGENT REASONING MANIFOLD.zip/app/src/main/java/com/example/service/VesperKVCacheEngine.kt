package com.example.service

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.delay
import kotlin.random.Random

data class KVCacheMetrics(
    val keysStored: Int = 0,
    val memoryUsageMb: Float = 0f,
    val cacheHitRate: Float = 0f,
    val tokensSaved: Int = 0
)

class VesperKVCacheEngine(private val maxSequenceLength: Int = 2048) {

    private val _cacheStatus = MutableStateFlow("KV Cache Uninitialized")
    val cacheStatus: StateFlow<String> = _cacheStatus

    private val _cacheMetrics = MutableStateFlow(KVCacheMetrics())
    val cacheMetrics: StateFlow<KVCacheMetrics> = _cacheMetrics

    // Pseudo KV Store: Map of Token Hash to "Attention Tensor" representation
    private val keyCache = mutableMapOf<Int, FloatArray>()
    private val valueCache = mutableMapOf<Int, FloatArray>()

    private var totalLookups = 0
    private var cacheHits = 0
    private var tokensSavedAccumulator = 0

    suspend fun processAttentionTokens(tokens: IntArray) {
        _cacheStatus.value = "Updating KV Cache Tensors..."
        delay(600) // Simulate processing

        var newKeys = 0
        var hitsInBatch = 0

        for (token in tokens) {
            totalLookups++
            val tokenHash = token.hashCode()
            
            if (keyCache.containsKey(tokenHash)) {
                cacheHits++
                hitsInBatch++
                tokensSavedAccumulator++
            } else {
                // Simulate computing new Key-Value pairs (128 dim hidden state)
                keyCache[tokenHash] = FloatArray(128) { Random.nextFloat() }
                valueCache[tokenHash] = FloatArray(128) { Random.nextFloat() }
                newKeys++
            }
        }
        
        // Eviction logic if we exceed max seq
        if (keyCache.size > maxSequenceLength) {
            _cacheStatus.value = "Evicting LRU tokens from Memory..."
            val keysToRemove = keyCache.keys.take(keyCache.size - maxSequenceLength)
            keysToRemove.forEach { 
                keyCache.remove(it)
                valueCache.remove(it)
            }
        }

        // Update metrics
        val hitRate = if (totalLookups > 0) (cacheHits.toFloat() / totalLookups.toFloat()) * 100f else 0f
        val memUsage = (keyCache.size * 128 * 4 + valueCache.size * 128 * 4) / (1024f * 1024f * 2) // pseudo MB

        _cacheMetrics.value = KVCacheMetrics(
            keysStored = keyCache.size,
            memoryUsageMb = memUsage,
            cacheHitRate = hitRate,
            tokensSaved = tokensSavedAccumulator
        )

        _cacheStatus.value = "KV Cache Updated. Size: ${keyCache.size} | Hits: $hitsInBatch"
    }

    fun clearCache() {
        keyCache.clear()
        valueCache.clear()
        totalLookups = 0
        cacheHits = 0
        tokensSavedAccumulator = 0
        _cacheMetrics.value = KVCacheMetrics()
        _cacheStatus.value = "KV Cache Flushed."
    }
}
