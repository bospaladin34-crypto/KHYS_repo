package com.example.service

import kotlin.math.log
import kotlin.math.max

object VesperLossFunctions {

    /**
     * Calculates the categorical cross-entropy loss.
     * @param predictions Array of predicted probabilities for each class.
     * @param targets Array of ground truth labels (one-hot encoded).
     * @param epsilon Small value to prevent log(0).
     */
    fun crossEntropyLoss(predictions: FloatArray, targets: FloatArray, epsilon: Float = 1e-7f): Float {
        var loss = 0.0f
        for (i in predictions.indices) {
            val pred = max(predictions[i], epsilon)
            loss -= targets[i] * log(pred, 2.718281828f)
        }
        return loss
    }
    
    /**
     * Vesper specific topological constraint loss to enforce manifold bindings.
     * Penalizes energy states that exceed the theoretical ground state boundaries.
     */
    fun topologicalConstraintLoss(energyState: Float, groundState: Float): Float {
        // Enforce physical energy limit constraints
        return max(0f, energyState - groundState) * 0.1f
    }
    
    /**
     * Computes the mean squared error (MSE) for regression tasks or embedding alignment.
     */
    fun meanSquaredError(predictions: FloatArray, targets: FloatArray): Float {
        var sum = 0.0f
        for (i in predictions.indices) {
            val diff = predictions[i] - targets[i]
            sum += diff * diff
        }
        return sum / predictions.size
    }

    /**
     * Calculates the Kullback-Leibler divergence loss.
     * Measures the difference between the true probability distribution (targets) 
     * and the model's predicted distribution (predictions).
     * @param predictions Array of predicted probabilities.
     * @param targets Array of ground truth probabilities.
     * @param epsilon Small value to prevent division by zero or log of zero.
     */
    fun kullbackLeiblerDivergence(predictions: FloatArray, targets: FloatArray, epsilon: Float = 1e-7f): Float {
        var divergence = 0.0f
        for (i in predictions.indices) {
            val target = max(targets[i], epsilon)
            val pred = max(predictions[i], epsilon)
            divergence += target * log(target / pred, 2.718281828f)
        }
        return divergence
    }
}
