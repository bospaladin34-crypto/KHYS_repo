package com.example.service

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class DistributedMetrics(
    val connectedNodes: Int = 1,
    val totalSyncBytes: Long = 0L,
    val latencyMs: Int = 0
)

class VesperDistributedEngine {

    private val _networkStatus = MutableStateFlow("Standalone Mode (Not Connected)")
    val networkStatus: StateFlow<String> = _networkStatus

    private val _distributedMetrics = MutableStateFlow(DistributedMetrics())
    val distributedMetrics: StateFlow<DistributedMetrics> = _distributedMetrics

    private var nodesConnected = 1
    private var syncBytesAccumulator = 0L
    
    suspend fun discoverLocalNodes() = withContext(Dispatchers.IO) {
        _networkStatus.value = "Scanning local subnet for compute nodes..."
        delay(1200) // Simulate discovery overhead
        
        nodesConnected = (2..5).random() // Pseudo discovery
        _networkStatus.value = "Cluster Formed: $nodesConnected Active Nodes."
        
        _distributedMetrics.value = DistributedMetrics(
            connectedNodes = nodesConnected,
            totalSyncBytes = syncBytesAccumulator,
            latencyMs = (15..45).random()
        )
    }

    suspend fun synchronizeGradients(layerGradientsBytes: Int) = withContext(Dispatchers.IO) {
        if (nodesConnected <= 1) {
            _networkStatus.value = "No peers to sync. Skipping Gradient All-Reduce."
            return@withContext
        }
        
        _networkStatus.value = "Executing Ring-AllReduce gradient synchronization..."
        delay((30..80).random().toLong()) // Simulated network latency
        
        syncBytesAccumulator += layerGradientsBytes * nodesConnected
        _distributedMetrics.value = DistributedMetrics(
            connectedNodes = nodesConnected,
            totalSyncBytes = syncBytesAccumulator,
            latencyMs = (15..45).random()
        )
        
        _networkStatus.value = "All-Reduce completed. Vector fields synchronized."
    }
    
    fun disconnect() {
        nodesConnected = 1
        _distributedMetrics.value = DistributedMetrics()
        _networkStatus.value = "Standalone Mode (Not Connected)"
    }
}
