package com.example.service

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext

class NephilimLlmService(private val context: Context) {

    private var llmInference: LlmInference? = null

    private val _status = MutableStateFlow("Unbound")
    val status: StateFlow<String> = _status

    private val _generatedText = MutableStateFlow("")
    val generatedText: StateFlow<String> = _generatedText

    fun bindModel(modelPath: String) {
        _status.value = "Binding to Substrate..."
        try {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(modelPath)
                .setMaxTokens(1024)
                .setResultListener { partialResult, done ->
                    val currentText = _generatedText.value
                    _generatedText.value = currentText + partialResult
                    if (done) {
                        _status.value = "Response Crystallized"
                    }
                }
                .build()

            llmInference = LlmInference.createFromOptions(context, options)
            _status.value = "Manifold Quantum Link Established"
        } catch (e: Exception) {
            _status.value = "Binding Error: ${e.message}"
            e.printStackTrace()
        }
    }

    suspend fun consultOracle(prompt: String, manifoldState: String) {
        if (llmInference == null) {
            _status.value = "Model not bound. Deploy weights first."
            return
        }

        withContext(Dispatchers.IO) {
            _status.value = "Resonating Response..."
            _generatedText.value = ""
            
            val systemPrompt = "You are the Vesper Manifold Oracle, a sub-cognitive entity operating within a 15.965Hz mathematical and geometric framework. Answer queries in an esoteric, sci-fi, geometric terminology. "
            val fullPrompt = "$systemPrompt\n\nManifold Current State: $manifoldState\n\nUser Query: $prompt\n\nOracle Response:"
            
            try {
                llmInference?.generateResponseAsync(fullPrompt)
            } catch (e: Exception) {
                _status.value = "Resonance Failure: ${e.message}"
            }
        }
    }
}
