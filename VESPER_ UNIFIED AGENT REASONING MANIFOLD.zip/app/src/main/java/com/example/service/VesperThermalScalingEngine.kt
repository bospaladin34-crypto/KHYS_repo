package com.example.service

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.random.Random

// Precision tiers for the topological engine
enum class VesperPrecisionTier {
    FP32, FP16, INT8
}

class VesperThermalScalingEngine(private val context: Context) {

    private val _currentTemperature = MutableStateFlow(35.0f) // Celsius
    val currentTemperature: StateFlow<Float> = _currentTemperature

    private val _activePrecisionTier = MutableStateFlow(VesperPrecisionTier.FP16)
    val activePrecisionTier: StateFlow<VesperPrecisionTier> = _activePrecisionTier

    private val _scalingStatus = MutableStateFlow("Initializing Thermal Monitor...")
    val scalingStatus: StateFlow<String> = _scalingStatus

    // Physical Thresholds
    private val THROTTLE_TEMP_C = 40.0f // Switch to INT8
    private val RECOVERY_TEMP_C = 37.0f // Switch to FP16
    
    private var isSimulating = false
    private var simTemp = 35.0f

    suspend fun monitorThermals() {
        while (true) {
            val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val tempInt = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
            
            var tempCelsius = tempInt / 10.0f
            
            // If running on emulator without battery simulation, or we force simulation
            if (tempCelsius <= 0f || isSimulating) {
                isSimulating = true
                // Random walk for simulated temperature
                simTemp += (Random.nextFloat() * 2f - 0.9f)
                if (simTemp > 46f) simTemp -= 2.0f
                if (simTemp < 32f) simTemp += 2.0f
                tempCelsius = simTemp
            }
            
            // Format to 1 decimal place
            tempCelsius = Math.round(tempCelsius * 10.0f) / 10.0f
            
            _currentTemperature.value = tempCelsius

            // Heuristic Scaling Logic
            if (tempCelsius >= THROTTLE_TEMP_C && _activePrecisionTier.value != VesperPrecisionTier.INT8) {
                _scalingStatus.value = "Thermal Headroom Diminished (${tempCelsius}°C). Shifting to INT8 Quantization Tier."
                _activePrecisionTier.value = VesperPrecisionTier.INT8
            } else if (tempCelsius <= RECOVERY_TEMP_C && _activePrecisionTier.value != VesperPrecisionTier.FP16 && _activePrecisionTier.value != VesperPrecisionTier.FP32) {
                _scalingStatus.value = "Thermal Headroom Recovered (${tempCelsius}°C). Up-casting to FP16 Geometric Tier."
                _activePrecisionTier.value = VesperPrecisionTier.FP16
            } else {
                _scalingStatus.value = "Thermal State: ${tempCelsius}°C. Sustaining Matrix Tier: ${_activePrecisionTier.value}."
            }

            delay(3000) // Poll every 3 seconds
        }
    }
    
    fun triggerSimulatedHeatWave() {
        isSimulating = true
        simTemp = 42.0f // High enough to trigger INT8 shifting
    }
    
    fun triggerSimulatedCooling() {
        isSimulating = true
        simTemp = 34.0f // Low enough to trigger FP16 recovery
    }
}
