package com.example.service

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.delay

data class CheckpointMetadata(
    val checkpointId: Int,
    val type: String,
    val path: String,
    val sizeBytes: Long,
    val timestamp: Long
)

class VesperCheckpointManager {

    private val _checkpointStatus = MutableStateFlow("Idle")
    val checkpointStatus: StateFlow<String> = _checkpointStatus
    
    private val _lastCheckpoint = MutableStateFlow<CheckpointMetadata?>(null)
    val lastCheckpoint: StateFlow<CheckpointMetadata?> = _lastCheckpoint

    private var checkpointCounter = 0

    suspend fun saveFullCheckpoint(weightsSize: Long, destinationDir: String = "/data/local/tmp/vesper/checkpoints") {
        _checkpointStatus.value = "Saving Full Checkpoint..."
        delay(800) // Simulate I/O overhead
        
        checkpointCounter++
        val ckptMetadata = CheckpointMetadata(
            checkpointId = checkpointCounter,
            type = "FULL",
            path = "$destinationDir/vesper_full_ckpt_$checkpointCounter.vesp",
            sizeBytes = weightsSize,
            timestamp = System.currentTimeMillis()
        )
        _lastCheckpoint.value = ckptMetadata
        _checkpointStatus.value = "Full Checkpoint $checkpointCounter Saved."
    }

    suspend fun savePartialCheckpoint(layerIndices: List<Int>, partialSize: Long, destinationDir: String = "/data/local/tmp/vesper/checkpoints") {
        _checkpointStatus.value = "Saving Partial Checkpoint (Layers: ${layerIndices.joinToString()})..."
        delay(400) // Simulate I/O overhead
        
        checkpointCounter++
        val ckptMetadata = CheckpointMetadata(
            checkpointId = checkpointCounter,
            type = "PARTIAL",
            path = "$destinationDir/vesper_partial_ckpt_$checkpointCounter.vesp",
            sizeBytes = partialSize,
            timestamp = System.currentTimeMillis()
        )
        _lastCheckpoint.value = ckptMetadata
        _checkpointStatus.value = "Partial Checkpoint $checkpointCounter Saved."
    }
}
