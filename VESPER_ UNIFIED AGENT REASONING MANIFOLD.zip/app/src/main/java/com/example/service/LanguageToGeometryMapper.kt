package com.example.service

import kotlin.math.*

object LanguageToGeometryMapper {
    
    data class GeometryOutput(
        val type: String,
        val points: List<Triple<Float, Float, Float>>,
        val bounds: Float
    )

    fun mapLanguageToGeometry(description: String): GeometryOutput {
        val lowerDesc = description.lowercase()
        
        val numPoints = 800 // Optimized point count for visual fidelity vs mobile performance
        val points = mutableListOf<Triple<Float, Float, Float>>()
        
        if (lowerDesc.contains("torus") || lowerDesc.contains("toroidal")) {
            for (i in 0 until numPoints) {
                val u = Math.random() * 2 * PI
                val v = Math.random() * 2 * PI
                val R = 1.0
                val r = 0.3
                val x = (R + r * cos(v)) * cos(u)
                val y = (R + r * cos(v)) * sin(u)
                val z = r * sin(v)
                points.add(Triple(x.toFloat(), y.toFloat(), z.toFloat()))
            }
            return GeometryOutput("Toroidal Coordinates", points, 1.3f)
        } else if (lowerDesc.contains("sphere") || lowerDesc.contains("spherical")) {
            for (i in 0 until numPoints) {
                val u = Math.random() * 2 * PI
                val v = Math.acos(2 * Math.random() - 1)
                val R = 1.0
                val x = R * sin(v) * cos(u)
                val y = R * sin(v) * sin(u)
                val z = R * cos(v)
                points.add(Triple(x.toFloat(), y.toFloat(), z.toFloat()))
            }
            return GeometryOutput("Spherical Coordinates", points, 1.0f)
        } else if (lowerDesc.contains("mobius") || lowerDesc.contains("möbius")) {
            for (i in 0 until numPoints) {
                val u = Math.random() * 2 * PI
                val v = Math.random() * 0.8 - 0.4
                val R = 1.0
                val x = (R + v * cos(u / 2)) * cos(u)
                val y = (R + v * cos(u / 2)) * sin(u)
                val z = v * sin(u / 2)
                points.add(Triple(x.toFloat(), y.toFloat(), z.toFloat()))
            }
            return GeometryOutput("Möbius Topology", points, 1.2f)
        } else if (lowerDesc.contains("klein") || lowerDesc.contains("bottle")) {
            for (i in 0 until numPoints) {
                val u = Math.random() * PI
                val v = Math.random() * 2 * PI
                val x = -2.0/15.0 * cos(u) * (3*cos(v) - 30*sin(u) + 90*cos(u).pow(4)*sin(u) - 60*cos(u).pow(6)*sin(u) + 5*cos(u)*cos(v)*sin(u))
                val y = -1.0/15.0 * sin(u) * (3*cos(v) - 3*cos(u).pow(2)*cos(v) - 48*cos(u).pow(4)*cos(v) + 48*cos(u).pow(6)*cos(v) - 60*sin(u) + 5*cos(u)*cos(v)*sin(u) - 5*cos(u).pow(3)*cos(v)*sin(u) - 80*cos(u).pow(5)*cos(v)*sin(u) + 80*cos(u).pow(7)*cos(v)*sin(u))
                val z = 2.0/15.0 * (3 + 5*cos(u)*sin(u)) * sin(v)
                points.add(Triple(x.toFloat(), y.toFloat(), z.toFloat()))
            }
            return GeometryOutput("Klein Bottle Immersion", points, 2.5f)
        } else if (lowerDesc.contains("chaos") || lowerDesc.contains("attractor") || lowerDesc.contains("lorenz")) {
            var x = 0.1
            var y = 0.0
            var z = 0.0
            val dt = 0.01
            for (i in 0 until numPoints * 2) {
                val dx = 10 * (y - x) * dt
                val dy = (x * (28 - z) - y) * dt
                val dz = (x * y - 8.0/3.0 * z) * dt
                x += dx
                y += dy
                z += dz
                if (i % 2 == 0) {
                    points.add(Triple((x/20.0).toFloat(), (y/20.0).toFloat(), (z/20.0 - 1.0).toFloat()))
                }
            }
            return GeometryOutput("Lorenz System (Chaotic Attractor)", points, 1.5f)
        } else if (lowerDesc.contains("quantum") || lowerDesc.contains("orbital") || lowerDesc.contains("wavefunction")) {
            for (i in 0 until numPoints) {
                val u = Math.random() * 2 * PI
                val v = Math.acos(2 * Math.random() - 1)
                val R = Math.abs(cos(v)) * 1.5 // probability density ~ |cos(\theta)|
                val x = R * sin(v) * cos(u)
                val y = R * sin(v) * sin(u)
                val z = R * cos(v)
                points.add(Triple(x.toFloat(), y.toFloat(), z.toFloat()))
            }
            return GeometryOutput("Quantum Probability Orbital (p-state)", points, 1.5f)
        } else if (lowerDesc.contains("gravity") || lowerDesc.contains("relativity") || lowerDesc.contains("spacetime") || lowerDesc.contains("black hole")) {
            val gridSize = Math.sqrt(numPoints.toDouble()).toInt()
            for (i in 0 until gridSize) {
                for (j in 0 until gridSize) {
                    val x = (i - gridSize / 2.0) / (gridSize / 4.0)
                    val y = (j - gridSize / 2.0) / (gridSize / 4.0)
                    val r = Math.sqrt(x*x + y*y)
                    val z = if (r > 0.1) -0.5 / r else -5.0
                    points.add(Triple(x.toFloat(), y.toFloat(), z.toFloat()))
                }
            }
            return GeometryOutput("Spacetime Curvature (Gravity Well)", points, 2.0f)
        } else if (lowerDesc.contains("fluid") || lowerDesc.contains("navier") || lowerDesc.contains("vortex") || lowerDesc.contains("flow")) {
            for (i in 0 until numPoints) {
                val r = Math.random() * 1.5
                val theta = Math.random() * 2 * PI
                val spiral = theta + r * 5.0
                val x = r * cos(spiral)
                val y = r * sin(spiral)
                val z = r * 2.0 - 1.5
                points.add(Triple(x.toFloat(), y.toFloat(), z.toFloat()))
            }
            return GeometryOutput("Fluid Dynamics (Vortex Flow Field)", points, 1.5f)
        } else if (lowerDesc.contains("magnetic") || lowerDesc.contains("electromagnetism") || lowerDesc.contains("maxwell")) {
            for (i in 0 until numPoints) {
                val r0 = 0.5 + Math.random() * 2.0
                val t = Math.random() * PI
                val phi = Math.random() * 2 * PI
                val R = r0 * sin(t).pow(2)
                val x = R * sin(t) * cos(phi)
                val y = R * sin(t) * sin(phi)
                val z = R * cos(t)
                points.add(Triple(x.toFloat(), y.toFloat(), z.toFloat()))
            }
            return GeometryOutput("Electromagnetic Dipole Field Lines", points, 2.5f)
        } else if (lowerDesc.contains("hyperbolic") || lowerDesc.contains("pseudosphere") || lowerDesc.contains("non-euclidean")) {
            for (i in 0 until numPoints) {
                val u = Math.random() * 2 * PI
                val v = 0.05 + Math.random() * 3.0
                val x = cos(u) / cosh(v)
                val y = sin(u) / cosh(v)
                val z = v - tanh(v) - 1.0
                points.add(Triple(x.toFloat(), y.toFloat(), z.toFloat()))
            }
            return GeometryOutput("Hyperbolic Geometry (Pseudosphere/Tractricoid)", points, 1.5f)
        } else if (lowerDesc.contains("phason") || lowerDesc.contains("vesper") || lowerDesc.contains("resonance")) {
            val count = Math.min(numPoints, 1000)
            val nu_p = 0.17259029
            val f0 = 15.965
            for (i in 0 until count) {
                val t = i.toDouble() / 100.0
                val angle = 2 * Math.PI * f0 * t
                val x = nu_p * cos(angle) * (1.0 + 0.1 * t)
                val y = nu_p * sin(angle) * (1.0 + 0.1 * t)
                val z = (t * 0.05) - 2.5
                points.add(Triple((x*5.0).toFloat(), (y*5.0).toFloat(), z.toFloat()))
            }
            return GeometryOutput("Vesper Phason Resonance (15.965Hz)", points, 1.5f)
        } else if (lowerDesc.contains("stomachion") || lowerDesc.contains("archimedes") || lowerDesc.contains("tessellation")) {
            val count = Math.min(numPoints / 14, 536)
            val nu_p = 0.17259029
            val phi = 1.6180339887
            for (i in 0 until count) {
                val seed = (i * nu_p) % 1.0
                for (j in 0 until 14) {
                    val angle = seed * Math.PI * (j + 1) * phi
                    val x = cos(angle) * seed * 4.0
                    val y = sin(angle) * seed * 4.0
                    val z = (i.toFloat() / count.toFloat()) * 5.0 - 2.5
                    points.add(Triple(x.toFloat(), y.toFloat(), z.toFloat()))
                }
            }
            return GeometryOutput("Stomachion Tessellation Extrusion", points, 2.0f)
        } else if (lowerDesc.contains("khys") || lowerDesc.contains("attention") || lowerDesc.contains("snap")) {
            val embedDim = Math.min(numPoints, 240)
            val nuP = 0.17259029f
            for (i in 0 until embedDim) {
                // Determine 91-degree sheared geometry (topological stochastic point)
                val baseAngle = (i.toDouble() / embedDim) * 2 * Math.PI
                val rotationAngle = 91.0 * (Math.PI / 180.0)
                
                val shearX = cos(rotationAngle)
                val shearY = sin(rotationAngle)
                
                val r = Math.random() * 2.0
                val px = (r * cos(baseAngle) * shearX - r * sin(baseAngle) * shearY) * nuP * 10
                val py = (r * sin(baseAngle) * shearX + r * cos(baseAngle) * shearY) * nuP * 10
                val pz = (Math.random() - 0.5) * 4.0
                points.add(Triple(px.toFloat(), py.toFloat(), pz.toFloat()))
            }
            return GeometryOutput("Khys-Nano Stochastic 91° Attention", points, 2.5f)
        } else if (lowerDesc.contains("laminar") || lowerDesc.contains("compression") || lowerDesc.contains("matrix")) {
            val phi = 1.6180339887
            var cur = 0.17259029
            for (i in 0 until numPoints) {
                cur = (cur * phi) % 1.0
                val x = cos(cur * 2 * Math.PI) * 2.0
                val y = sin(cur * 2 * Math.PI) * 2.0
                val z = (cur * 5.0) - 2.5
                points.add(Triple(x.toFloat(), y.toFloat(), z.toFloat()))
            }
            return GeometryOutput("Mnemosyne Compression Matrix", points, 1.0f)
        } else {
            // Abstract Manifold / Random Point Cloud
            for (i in 0 until numPoints) {
                val r = Math.random().pow(1.0/3.0)
                val theta = Math.random() * 2 * PI
                val phi = Math.acos(2 * Math.random() - 1)
                val x = r * sin(phi) * cos(theta)
                val y = r * sin(phi) * sin(theta)
                val z = r * cos(phi)
                points.add(Triple(x.toFloat(), y.toFloat(), z.toFloat()))
            }
            return GeometryOutput("Unconstrained Abstract Manifold", points, 1.0f)
        }
    }
}
