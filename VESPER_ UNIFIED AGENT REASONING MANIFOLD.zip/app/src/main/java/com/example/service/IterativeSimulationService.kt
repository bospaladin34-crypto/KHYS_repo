package com.example.service

import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class IterativeSimulationService : Service() {
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private val binder = LocalBinder()

    private val _progress = MutableStateFlow(0f)
    val progress: StateFlow<Float> = _progress.asStateFlow()
    
    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs: StateFlow<List<String>> = _logs.asStateFlow()

    inner class LocalBinder : Binder() {
        fun getService(): IterativeSimulationService = this@IterativeSimulationService
    }

    override fun onBind(intent: Intent): IBinder = binder
    
    fun requestIterativeSimulation(
        ranges: Map<String, List<Double>>,
        fastMode: Boolean = true
    ) {
        scope.launch {
            _progress.value = 0f
            _logs.value = listOf("Initializing Iterative Simulation across ${ranges.size} variables...")
            
            val keys = ranges.keys.toList()
            val gridBounds = keys.map { ranges[it] ?: listOf(0.0) }
            
            // Calculate total combinations
            val totalSteps = gridBounds.fold(1) { acc, list -> acc * list.size }
            _logs.value += "Total permutation states: $totalSteps"
            
            val nativeInterface = com.nephilim.core.NephilimJni()
            val initialized = nativeInterface.initEngine()
            _logs.value += "JNI Engine initialized: $initialized"
            
            var completed = 0
            
            // We do a flattened iteration using a recursive index approach or just simple nested for loops
            // For arbitrary size, we use a recursive function to generate tuples
            fun generateTuples(depth: Int, currentTuple: List<Double>, resultCollector: (List<Double>) -> Unit) {
                if (depth == keys.size) {
                    resultCollector(currentTuple)
                    return
                }
                for (value in gridBounds[depth]) {
                    generateTuples(depth + 1, currentTuple + value, resultCollector)
                }
            }
            
            val batchSize = if (fastMode) 512 else 64
            val buffer = mutableListOf<FloatArray>()
            
            generateTuples(0, emptyList()) { stateVector ->
                val floatArr = FloatArray(stateVector.size) { stateVector[it].toFloat() }
                buffer.add(floatArr)
                
                if (buffer.size >= batchSize) {
                    // Send to JNI
                    // We simulate processing via standard JNI layer for multiple vars
                    // Braid function expects FloatArray
                    for (b in buffer) {
                        nativeInterface.braid(b)
                    }
                    completed += buffer.size
                    _progress.value = completed.toFloat() / totalSteps.coerceAtLeast(1)
                    buffer.clear()
                }
            }
            
            if (buffer.isNotEmpty()) {
                for (b in buffer) {
                    nativeInterface.braid(b)
                }
                completed += buffer.size
                _progress.value = completed.toFloat() / totalSteps.coerceAtLeast(1)
            }
            
            _logs.value += "Simulation complete across ${completed} states."
        }
    }
}
