package com.example.service

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.security.MessageDigest
import java.util.UUID

data class NodeLinkStatus(
    val linkActive: Boolean = false,
    val connectedNodes: Int = 0,
    val meshNetworkHash: String = "None",
    val statusText: String = "Node Link Idle",
    val activeFirewall: Boolean = true
)

class VesperNodeLinkEngine {

    private val _status = MutableStateFlow("Idle")
    val status: StateFlow<String> = _status

    private val _linkState = MutableStateFlow(NodeLinkStatus())
    val linkState: StateFlow<NodeLinkStatus> = _linkState

    suspend fun generateDeviceHash(): String {
        _status.value = "Generating cryptographic device hash..."
        delay(400)
        val rawId = UUID.randomUUID().toString()
        val bytes = MessageDigest.getInstance("SHA-256").digest(rawId.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }.take(16)
    }

    suspend fun initializeNodeMesh() {
        _status.value = "Booting Firebase mesh infrastructure..."
        delay(600)
        val hash = generateDeviceHash()
        
        _linkState.value = _linkState.value.copy(
            linkActive = true,
            meshNetworkHash = hash,
            statusText = "Mesh Node Active: Listening for peer pulses."
        )
        _status.value = "Mesh network listening. Hash: $hash"
    }

    suspend fun connectToPeerNode(peerHash: String) {
        if (!_linkState.value.linkActive) {
            _status.value = "Error: Mesh network not initialized."
            return
        }
        
        _status.value = "Attempting handshake with peer: $peerHash..."
        delay(800)
        
        _linkState.value = _linkState.value.copy(
            connectedNodes = _linkState.value.connectedNodes + 1,
            statusText = "Peer Connected. Quantum firewall active."
        )
        _status.value = "Successfully linked to peer node."
    }
}
