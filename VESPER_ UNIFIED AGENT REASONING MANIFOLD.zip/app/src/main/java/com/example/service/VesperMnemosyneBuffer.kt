package com.example.service

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.LinkedList

class VesperMnemosyneBuffer(private val maxContextWindow: Int = 240) { // 240 aligns with E8 root vectors

    private val _bufferStatus = MutableStateFlow("Mnemosyne Paging Matrix Empty")
    val bufferStatus: StateFlow<String> = _bufferStatus

    private val _activeContextTokens = MutableStateFlow<List<Int>>(emptyList())
    val activeContextTokens: StateFlow<List<Int>> = _activeContextTokens

    private val contextTokens = LinkedList<Int>()

    fun ingestTokens(tokens: IntArray) {
        _bufferStatus.value = "Ingesting ${tokens.size} tokens into Active VRAM..."
        for (t in tokens) {
            contextTokens.add(t)
        }
        
        // Sliding window compression
        if (contextTokens.size > maxContextWindow) {
            val overflow = contextTokens.size - maxContextWindow
            _bufferStatus.value = "Context window exceeded ($maxContextWindow). Paging $overflow tokens to Majorana Cold Storage."
            for (i in 0 until overflow) {
                contextTokens.removeFirst()
            }
        } else {
            _bufferStatus.value = "Mnemosyne Buffer Active: ${contextTokens.size}/$maxContextWindow Tokens"
        }
        
        _activeContextTokens.value = contextTokens.toList()
    }

    fun getContextVector(): IntArray {
        return contextTokens.toIntArray()
    }
    
    fun flushBuffer() {
        contextTokens.clear()
        _activeContextTokens.value = emptyList()
        _bufferStatus.value = "Mnemosyne Paging Matrix Flushed."
    }
}
