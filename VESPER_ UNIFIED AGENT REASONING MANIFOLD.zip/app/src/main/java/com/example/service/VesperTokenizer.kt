package com.example.service

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

class VesperTokenizer {

    private val _tokenizerStatus = MutableStateFlow("Uninitialized")
    val tokenizerStatus: StateFlow<String> = _tokenizerStatus

    // A sample tiny vocabulary for the Vesper Nano model
    private val vocab = mapOf(
        "<pad>" to 0,
        "<unk>" to 1,
        "<s>" to 2,
        "</s>" to 3,
        "the" to 4,
        "vesper" to 5,
        "topology" to 6,
        "aperiodic" to 7,
        "quantum" to 8,
        "tensor" to 9,
        "network" to 10,
        "is" to 11,
        "active" to 12,
        "majorana" to 13,
        "parity" to 14,
        "state" to 15,
        "system" to 16,
        "ready" to 17
    )
    
    private val inverseVocab = vocab.entries.associate { (k, v) -> v to k }

    init {
        _tokenizerStatus.value = "Tokenizer Initialized. Vocab size: ${vocab.size}"
    }

    fun encode(text: String): IntArray {
        _tokenizerStatus.value = "Encoding text..."
        val words = text.lowercase(Locale.getDefault()).split(Regex("\\s+"))
        val tokens = mutableListOf<Int>()
        tokens.add(vocab["<s>"] ?: 2)
        
        for (word in words) {
            // Clean punctuation
            val cleanWord = word.replace(Regex("[^a-z]"), "")
            if (cleanWord.isEmpty()) continue
            
            val tokenId = vocab[cleanWord] ?: vocab["<unk>"] ?: 1
            tokens.add(tokenId)
        }
        
        tokens.add(vocab["</s>"] ?: 3)
        _tokenizerStatus.value = "Encoding complete. Generated ${tokens.size} tokens."
        return tokens.toIntArray()
    }

    fun decode(tokens: IntArray): String {
        _tokenizerStatus.value = "Decoding tokens..."
        val words = mutableListOf<String>()
        for (token in tokens) {
            if (token == vocab["<s>"] || token == vocab["</s>"] || token == vocab["<pad>"]) continue
            val word = inverseVocab[token] ?: "<unk>"
            words.add(word)
        }
        _tokenizerStatus.value = "Decoding complete."
        return words.joinToString(" ")
    }
}
