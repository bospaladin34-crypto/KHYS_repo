package com.example.service

import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.abs
import kotlin.math.round

object NephilimManifoldEngine {
    const val NU_P = 0.17259029f
    const val PHI = 1.61803398f
    const val F0_HZ = 15.965f

    /**
     * Projects a point in 3D space onto the Nephilim Manifold
     * Returns the delta vector that should be applied to the point
     */
    fun calculateConstraintDelta(
        nx: Float, ny: Float, nz: Float,
        zSnapFactor: Float = 0.1f,
        radialSnapFactor: Float = 0.05f
    ): Triple<Float, Float, Float> {
        var dx = 0f
        var dy = 0f
        var dz = 0f

        // Calculate radial distance
        val r = sqrt(nx * nx + ny * ny)

        // 1. Z-axis Manifold Projection (Aperiodic Heartbeat Modulation)
        val targetZ = (cos(r * PHI * Math.PI).toFloat() * NU_P * 5f).coerceIn(-5f, 5f)
        if (abs(targetZ - nz) > 0.05f) {
            dz = (targetZ - nz) * zSnapFactor
        }

        // 2. Radial Harmonic Alignment (Majorana Parity Lock)
        val targetR = (round(r / NU_P) * NU_P)
        if (abs(targetR - r) > 0.05f && r > 0.001f) {
            val dR = (targetR - r) * radialSnapFactor
            dx = (nx / r) * dR
            dy = (ny / r) * dR
        }

        return Triple(dx, dy, dz)
    }

    /**
     * Calculates the crystallized truth score (0 to 1) for a given point cloud
     * evaluating its adherence to the manifold constraints.
     */
    fun evaluateResonance(points: List<Triple<Float, Float, Float>>): Float {
        if (points.isEmpty()) return 0f
        
        var totalError = 0f
        for (p in points) {
            val (dx, dy, dz) = calculateConstraintDelta(p.first, p.second, p.third)
            totalError += sqrt(dx * dx + dy * dy + dz * dz)
        }
        
        val avgError = totalError / points.size
        // Map error to resonance: error 0 -> resonance 1.0, error 1.0 -> resonance 0.0
        return (1f - avgError).coerceIn(0f, 1f)
    }
}
