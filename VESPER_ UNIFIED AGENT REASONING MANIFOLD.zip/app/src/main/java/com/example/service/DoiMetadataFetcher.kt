package com.example.service

import com.example.db.DoiParser
import com.example.db.DoiProvenanceEntity
import com.example.db.PinnRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.flow.first
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.io.IOException

class DoiMetadataFetcher(private val repository: PinnRepository) {
    private val client = OkHttpClient()

    suspend fun fetchMetadataForUrls(urls: List<String>) {
        withContext(Dispatchers.IO) {
            val entities = urls.map { url ->
                val parsed = DoiParser.parseUrl(url)
                val metadata = fetchMetadata(parsed)
                parsed.copy(citationMetadata = metadata)
            }
            repository.saveAllDoiProvenance(entities)
        }
    }

    suspend fun startPeriodicRefresh(intervalMillis: Long = 24 * 60 * 60 * 1000L) {
        withContext(Dispatchers.IO) {
            while (isActive) {
                delay(intervalMillis)
                refreshAll()
            }
        }
    }

    suspend fun refreshAll() {
        withContext(Dispatchers.IO) {
            val existingDois = repository.allDoiProvenance.first()
            if (existingDois.isNotEmpty()) {
                val urls = existingDois.map { it.url }
                fetchMetadataForUrls(urls)
            }
        }
    }

    suspend fun mapConceptsToExistingDois(conceptMapping: Map<String, String>) {
        withContext(Dispatchers.IO) {
            val existingDois = repository.allDoiProvenance.first()
            val updatedEntities = existingDois.map { entity ->
                // Basic mapping: check if the citation metadata contains the keyword, or just map explicitly
                val urlConcepts = conceptMapping[entity.url]
                if (urlConcepts != null) {
                    entity.copy(associatedConcepts = urlConcepts)
                } else {
                    entity
                }
            }
            if (updatedEntities.isNotEmpty()) {
                repository.saveAllDoiProvenance(updatedEntities)
            }
        }
    }

    private fun fetchMetadata(entity: DoiProvenanceEntity): String? {
        // If we have a DOI, try the doi.org content negotiation for CSL JSON
        if (entity.doi != null) {
            val request = Request.Builder()
                .url(entity.url)
                .addHeader("Accept", "application/vnd.citationstyles.csl+json")
                .build()

            try {
                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        return response.body?.string()
                    }
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }

        // Fallback or non-DOI: use Jsoup to fetch HTML metadata
        try {
            val doc = Jsoup.connect(entity.url)
                .userAgent("Mozilla/5.0")
                .timeout(5000)
                .get()
                
            val title = doc.title()
            val metaDescription = doc.select("meta[name=description]").attr("content")
            
            return if (metaDescription.isNotEmpty()) {
                "Title: $title\nDescription: $metaDescription"
            } else {
                "Title: $title"
            }
            
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return null
    }
}
