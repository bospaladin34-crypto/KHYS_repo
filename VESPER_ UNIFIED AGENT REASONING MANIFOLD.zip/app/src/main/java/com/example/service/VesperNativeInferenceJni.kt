package com.example.service

import java.nio.ByteBuffer

class VesperNativeInferenceJni {
    companion object {
        init {
            System.loadLibrary("physicscompute")
        }
    }

    external fun initInferenceEngine(): Boolean
    external fun forwardPassInt8(inputTokens: IntArray): FloatArray
    external fun quantizeMatrixInt8(weights: FloatArray): ByteArray
    external fun mapWeightsToNative(layerId: Int, weights: ByteBuffer): Boolean
}
