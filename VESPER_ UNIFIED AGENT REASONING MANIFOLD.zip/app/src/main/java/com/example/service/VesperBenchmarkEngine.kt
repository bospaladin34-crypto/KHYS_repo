package com.example.service

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.random.Random

data class BenchmarkResult(
    val fp32InferenceTimeMs: Long = 0,
    val int8InferenceTimeMs: Long = 0,
    val fp32MemoryFootprintMb: Float = 0f,
    val int8MemoryFootprintMb: Float = 0f,
    val speedupFactor: Float = 1f,
    val memoryReductionFactor: Float = 1f
)

class VesperBenchmarkEngine {

    private val _benchmarkStatus = MutableStateFlow("Ready for Benchmarking")
    val benchmarkStatus: StateFlow<String> = _benchmarkStatus

    private val _benchmarkResult = MutableStateFlow<BenchmarkResult?>(null)
    val benchmarkResult: StateFlow<BenchmarkResult?> = _benchmarkResult

    suspend fun runBenchmark(simulatedDataTokens: Int = 128) {
        _benchmarkStatus.value = "Initializing FP32 Baseline Benchmark..."
        delay(800)

        // Mock FP32 parameters (assume 4672 tensors, average dimension 64)
        // Memory footprint FP32
        val fp32Memory = 4672 * 64 * 64 * 4 / (1024f * 1024f) // MB
        
        _benchmarkStatus.value = "Running FP32 Inference pass over $simulatedDataTokens tokens..."
        val fp32StartTime = System.currentTimeMillis()
        delay((simulatedDataTokens * 12.0).toLong() + Random.nextLong(20, 50)) // 12ms per token avg
        val fp32EndTime = System.currentTimeMillis()
        val fp32TimeMs = fp32EndTime - fp32StartTime

        _benchmarkStatus.value = "Initializing INT8 Quantized Benchmark..."
        delay(800)

        // Memory footprint INT8
        val int8Memory = 4672 * 64 * 64 * 1 / (1024f * 1024f) // MB
        
        _benchmarkStatus.value = "Running INT8 Inference pass over $simulatedDataTokens tokens..."
        val int8StartTime = System.currentTimeMillis()
        delay((simulatedDataTokens * 3.5).toLong() + Random.nextLong(10, 30)) // 3.5ms per token avg
        val int8EndTime = System.currentTimeMillis()
        val int8TimeMs = int8EndTime - int8StartTime

        val speedup = fp32TimeMs.toFloat() / int8TimeMs.toFloat()
        val memReduction = fp32Memory / int8Memory

        _benchmarkResult.value = BenchmarkResult(
            fp32InferenceTimeMs = fp32TimeMs,
            int8InferenceTimeMs = int8TimeMs,
            fp32MemoryFootprintMb = fp32Memory,
            int8MemoryFootprintMb = int8Memory,
            speedupFactor = speedup,
            memoryReductionFactor = memReduction
        )

        _benchmarkStatus.value = "Benchmarking Complete."
    }
}
