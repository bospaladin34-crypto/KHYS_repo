package com.example.service

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

class VesperBpeTokenizer {

    private val _tokenizerStatus = MutableStateFlow("BPE Uninitialized")
    val tokenizerStatus: StateFlow<String> = _tokenizerStatus

    // BPE Vocab optimized for physics domain + base characters
    private val vocab = mutableMapOf(
        "<pad>" to 0,
        "<unk>" to 1,
        "<s>" to 2,
        "</s>" to 3,
        // Base chars
        "t" to 4, "h" to 5, "e" to 6, "v" to 7, "s" to 8, "p" to 9, "r" to 10,
        "o" to 11, "l" to 12, "g" to 13, "y" to 14, "a" to 15, "i" to 16,
        "c" to 17, "q" to 18, "u" to 19, "n" to 20, "m" to 21, "w" to 22,
        "k" to 23, "j" to 24, "d" to 25, "z" to 26, "x" to 27, "b" to 28, "f" to 29,
        // Physics BPE merges
        "qu" to 30, "an" to 31, "tum" to 32, "quantum" to 33,
        "to" to 34, "po" to 35, "lo" to 36, "gy" to 37, "topology" to 38,
        "te" to 39, "ns" to 40, "or" to 41, "tensor" to 42,
        "ma" to 43, "jo" to 44, "ra" to 45, "na" to 46, "majorana" to 47,
        "ves" to 48, "per" to 49, "vesper" to 50,
        "pa" to 51, "ri" to 52, "ty" to 53, "parity" to 54,
        "ham" to 55, "il" to 56, "ton" to 57, "ian" to 58, "hamiltonian" to 59,
        "_" to 60 // space token in BPE
    )

    private val inverseVocab = vocab.entries.associate { (k, v) -> v to k }

    init {
        _tokenizerStatus.value = "BPE Pipeline Initialized. Vocab size: ${vocab.size}"
    }

    fun encode(text: String): IntArray {
        _tokenizerStatus.value = "BPE encoding text..."
        val words = text.lowercase(Locale.getDefault()).split(Regex("\\s+"))
        val tokens = mutableListOf<Int>()
        tokens.add(vocab["<s>"] ?: 2)
        
        for (word in words) {
            val cleanWord = word.replace(Regex("[^a-z]"), "")
            if (cleanWord.isEmpty()) continue
            
            // Try to match whole words first if they exist in physics vocab
            if (vocab.containsKey(cleanWord)) {
                tokens.add(vocab[cleanWord]!!)
            } else {
                // Faux BPE merge fallback
                var i = 0
                while (i < cleanWord.length) {
                    var matchLength = 1
                    var bestTokenId = vocab["<unk>"]!!
                    
                    // Lookahead for longest BPE token (max 4 chars for this mock)
                    for (len in 4 downTo 1) {
                        if (i + len <= cleanWord.length) {
                            val sub = cleanWord.substring(i, i + len)
                            if (vocab.containsKey(sub)) {
                                matchLength = len
                                bestTokenId = vocab[sub]!!
                                break
                            }
                        }
                    }
                    
                    tokens.add(bestTokenId)
                    i += matchLength
                }
            }
            // Add word separator token
            tokens.add(vocab["_"] ?: 60)
        }
        
        tokens.add(vocab["</s>"] ?: 3)
        _tokenizerStatus.value = "BPE Encoding complete. Generated ${tokens.size} sequence tokens."
        return tokens.toIntArray()
    }

    fun decode(tokens: IntArray): String {
        _tokenizerStatus.value = "BPE decoding sequence..."
        val sb = StringBuilder()
        for (token in tokens) {
            if (token == vocab["<s>"] || token == vocab["</s>"] || token == vocab["<pad>"]) continue
            if (token == vocab["_"]) {
                sb.append(" ")
            } else {
                sb.append(inverseVocab[token] ?: "<unk>")
            }
        }
        _tokenizerStatus.value = "Decoding complete."
        return sb.toString().trim()
    }
}
