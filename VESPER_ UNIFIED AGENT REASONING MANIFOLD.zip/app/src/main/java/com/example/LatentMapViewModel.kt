package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.db.LatentAnchorEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import com.example.MyApplication

class LatentMapViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = (application as MyApplication).repository

    val anchors: StateFlow<List<LatentAnchorEntity>> = repository.allAnchors
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun addAnchor(x: Float, y: Float, note: String) {
        viewModelScope.launch {
            repository.saveAnchor(LatentAnchorEntity(x = x, y = y, note = note))
        }
    }
    
    fun clearAnchors() {
        viewModelScope.launch {
            repository.clearAnchors()
        }
    }
}
