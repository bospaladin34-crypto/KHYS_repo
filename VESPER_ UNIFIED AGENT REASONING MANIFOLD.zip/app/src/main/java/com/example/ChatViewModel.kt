package com.example

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.api.Content
import com.example.api.GenerateContentRequest
import com.example.api.GenerationConfig
import com.example.api.Part
import com.example.api.RetrofitClient
import com.example.api.ThinkingConfig
import com.example.api.Tool
import com.example.pinn.CodexText
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val text: String,
    val isUser: Boolean,
    val isLoading: Boolean = false,
    val isError: Boolean = false,
    val modelUsed: String? = null
)

class ChatViewModel(private val repository: com.example.db.PinnRepository) : ViewModel() {
    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val conversationHistory = mutableListOf<Content>()

    val isRecordingMacro = MutableStateFlow(false)
    val currentMacroSequence = MutableStateFlow<List<String>>(emptyList())
    val savedMacros = MutableStateFlow<Map<String, List<String>>>(emptyMap())

    init {
        viewModelScope.launch {
            try {
                repository.saveDefaultInvariants()
            } catch (e: Exception) {
                // Ignore initialisation errors if the DB fails to start.
            }
        }
    }

    companion object {
        fun provideFactory(repository: com.example.db.PinnRepository): androidx.lifecycle.ViewModelProvider.Factory =
            object : androidx.lifecycle.ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return ChatViewModel(repository) as T
                }
            }
    }

    private val systemInstruction = Content(
        role = "user", // For system instructions in gemini API, role is typically not specified or is user/system depending on API. Let's omit role or use standard approach. Actually, standard REST API systemInstruction has NO role.
        parts = listOf(Part("You are VESPER-01, an advanced theoretical physics computing interface. You follow the UNIFIED FIELD INVARIANTS architecture. You have a CLI-like terminal persona. Keep answers concise, highly analytical, and refer to experimental invariants where appropriate."))
    )

    fun injectJniInitialization(lines: List<String>) {
        val initialMessages = lines.map {
            ChatMessage(text = it, isUser = false)
        }
        _messages.value = initialMessages
    }

    fun sendMessage(inputText: String) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.Default) {
            sendMessageInternal(inputText)
        }
    }

    private fun sendMessageInternal(inputText: String) {
        val userPrompt = inputText.trim()
        if (userPrompt.isEmpty()) return

        if (userPrompt.startsWith("/foundry")) {
            val concept = userPrompt.removePrefix("/foundry").trim()
            if (concept.isEmpty()) {
                _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true) + ChatMessage(text = "Error: Provide a concept. Usage: /foundry <concept>", isUser = false)
                return
            }
            val material = com.example.pinn.parser.MaterialIsomorphism.mapConceptToMaterial(concept)
            val stabilityIndex = com.example.pinn.parser.MaterialIsomorphism.metricChargingLawViability(material)
            
            val status = if(material.thermalDegradationK > 500f) "STABLE under 0.17259029 Phase Delta." else "CRITICAL: THERMODYNAMIC DEGRADATION RISK."

            val isoOutput = """
                [MODULE 89: FOUNDRY GROUNDING EXECUTED]
                [LEXICAL MATERIAL ISOMORPHISM]
                Concept Target: $concept
                Physical Map: ${material.name}
                Description: ${material.description}
                
                [METRIC CHARGING LAW AUDIT]
                Energy Density: ${material.energyDensityMjKg} MJ/kg
                Thermal Limit: ${material.thermalDegradationK} K
                Substrate Density (ρ): ${material.volumeDensityKgM3} kg/m³
                
                Δg_00 = ∫(Ψ · P_a) / (V · ρ) dt
                Structural Viability Index: $stabilityIndex
                System Status: $status
            """.trimIndent()
            
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true) + ChatMessage(text = isoOutput, isUser = false)
            return
        }

        if (userPrompt.startsWith("/rust")) {
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            val rsResult = com.example.rust.RustCompute.unifiedRustString()
            _messages.value = _messages.value + ChatMessage(text = rsResult, isUser = false)
            return
        }

        if (userPrompt.startsWith("/weights")) {
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            viewModelScope.launch {
                try {
                    val weightsList = repository.allWeights.first()
                    val output = if (weightsList.isEmpty()) {
                        "No local weights found in local Room persistent storage."
                    } else {
                        weightsList.joinToString("\n") { w ->
                            "Epochs: ${w.trainedEpochs} | Loss: ${w.finalLoss}\nEq: ${w.equationContext}"
                        }
                    }
                    _messages.value = _messages.value + ChatMessage(text = "[ROOM PERSISTENCE] Loaded Weights:\n$output", isUser = false)
                } catch(e: Exception) {
                    _messages.value = _messages.value + ChatMessage(text = "[LOCAL_WEIGHTS ERR] ${e.message}", isUser = false)
                }
            }
            return
        }

        if (userPrompt.startsWith("/save_session")) {
            val sessionName = userPrompt.removePrefix("/save_session").trim().takeIf { it.isNotBlank() } ?: "Unnamed_Session"
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            viewModelScope.launch {
                try {
                    repository.saveSession(
                        com.example.db.TerminalSessionEntity(
                            id = java.util.UUID.randomUUID().toString(),
                            title = sessionName
                        )
                    )
                    _messages.value = _messages.value + ChatMessage(text = "[ROOM PERSISTENCE] Session '$sessionName' persisted to Room Database.", isUser = false)
                } catch(e: Exception) {
                    _messages.value = _messages.value + ChatMessage(text = "[LOCAL_SESSION ERR] ${e.message}", isUser = false)
                }
            }
            return
        }

        if (userPrompt.startsWith("/history")) {
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            viewModelScope.launch {
                try {
                    val comps = repository.allComputations.first()
                    if (comps.isEmpty()) {
                        _messages.value = _messages.value + ChatMessage(text = "[HISTORY] No computation sessions saved yet.", isUser = false)
                    } else {
                        val histString = comps.take(5).joinToString("\n\n") {
                            "ID: ${it.id.take(8)}\nCommand: ${it.command}\nEquation: ${it.targetEquation}\nIterations: ${it.iterations}\nResult:\n${it.resultOutput.prependIndent("  ")}"
                        }
                        _messages.value = _messages.value + ChatMessage(text = "[HISTORY (Last 5 Computations)]\n\n$histString", isUser = false)
                    }
                } catch(e: Exception) {
                    _messages.value = _messages.value + ChatMessage(text = "[DB_ERR] ${e.message}", isUser = false)
                }
            }
            return
        }

        if (userPrompt.startsWith("/invariants")) {
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            _messages.value = _messages.value + ChatMessage(text = com.example.pinn.VesperInvariants.dumpInvariants(), isUser = false)
            return
        }

        if (userPrompt.startsWith("/equations")) {
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            val eqs = com.example.pinn.VesperInvariants.equations.entries.joinToString("\n") { "${it.key}: ${it.value}" }
            _messages.value = _messages.value + ChatMessage(text = "Loaded Native Symbolics:\n$eqs", isUser = false)
            return
        }

        if (userPrompt.startsWith("/cef")) {
            val content = userPrompt.removePrefix("/cef").trim()
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            
            // Assume input drift is effectively 0 for the Operator
            val cefOutput = com.example.pinn.ContextualExplanationFilter.process(content, 0.0)
            
            _messages.value = _messages.value + ChatMessage(text = cefOutput, isUser = false)
            return
        }

        if (userPrompt.startsWith("/tensors")) {
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            val mappings = com.example.pinn.VesperInvariants.tensorLayers.entries.joinToString("\n") { "${it.key}: ${it.value}" }
            _messages.value = _messages.value + ChatMessage(text = "VESPER-01 Tensor Network Configuration (Total Dim: ${com.example.pinn.VesperInvariants.TENSOR_NETWORK_SIZE}):\n$mappings", isUser = false)
            return
        }

        if (userPrompt.startsWith("/rk")) {
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            try {
                val initialState = FloatArray(240) { 1.0f } // 240 dimensions for E8 Gosset polytope logic
                val dt = 0.001f
                val stableState = com.example.pinn.RungeKuttaModule.integrateManifold("Manifold Flow", initialState, dt)
                
                var normSq = 0.0
                for (v in stableState) normSq += v * v
                val norm = Math.sqrt(normSq)
                
                val output = """
                    [RUNGE-KUTTA HYPER-INTEGRATION MODULE]
                    Precision: Adaptive RK56 -> RK256
                    Layers Integrated: 7 (Sub-Planckian to Galactic)
                    Decoherence Prevented: TRUE
                    Structural Degradation: 0.0%
                    Resulting Laminar Norm: $norm
                    Status: Operator Safe, Perspective Preserved
                """.trimIndent()
                
                _messages.value = _messages.value + ChatMessage(text = output, isUser = false)
            } catch (e: Exception) {
                _messages.value = _messages.value + ChatMessage(isError = true, text = "[FATAL ERROR] RK Module Failure: ${e.message}", isUser = false)
            }
            return
        }

        if (userPrompt.startsWith("/latent")) {
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            try {
                val initVector = FloatArray(128) { 1.0f }
                val manifold = com.example.pinn.GeometricLatentSpace.mapToLatentSubstrate(initVector)
                val tangram = com.example.pinn.GeometricLatentSpace.extractTangramTarget(manifold)
                
                val output = """
                    [GEOMETRIC LATENT SPACE: 7777D POLYTOPE]
                    Boundary Condition: ACTIVE
                    Archimedes Cellular Sheaf (pg 123): Mapped
                    Penrose P3 Tiling: Applied
                    E8/E7/E6 Symmetry: Locked
                    Cymatic Resonance (432Hz): Synchronized
                    
                    Resulting Topological Anchor: $tangram
                """.trimIndent()
                
                _messages.value = _messages.value + ChatMessage(text = output, isUser = false)
            } catch (e: Exception) {
                _messages.value = _messages.value + ChatMessage(isError = true, text = "[FATAL ERROR] Latent Space Mapping Failure: ${e.message}", isUser = false)
            }
            return
        }

        if (userPrompt.startsWith("/sheaf")) {
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            val output = """
                [ARCHIMEDES PALIMPSEST: SHEAF NETWORK ALIGNED]
                Projecting 123 local vector stalks across the 7777D Polytope.
                Resolving Penrose P3 distortion grids...
                
                Switch to the SHEAF Network tab to view the live topological projection.
            """.trimIndent()
            _messages.value = _messages.value + ChatMessage(text = output, isUser = false)
            return
        }

        if (userPrompt.startsWith("/lullian")) {
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            val output = """
                [LULLIAN ENGINE: E8 240-ROOT QUANTUM WALK]
                Applying Modus Ponens / Modus Tollens to E_8 logic vectors...
                Discrete Lullian scale invariants enforced.
                
                Switch to the LULL Engine tab to view the active 2D planar projection.
            """.trimIndent()
            _messages.value = _messages.value + ChatMessage(text = output, isUser = false)
            return
        }

        if (userPrompt.startsWith("/scatter")) {
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            try {
                // Determine current global resonance baseline
                val basePower = 432.0f
                val parser = com.example.vmal.security.AmplituhedronCLIParser()
                
                // Allow user string arguments to dictate projection dimensions
                val fragments = parser.parseAndExecute(userPrompt, basePower)
                
                val outputBuilder = java.lang.StringBuilder()
                outputBuilder.append("[AMPLITUHEDRON: PAYLOAD SCATTER ENGINE]\n")
                outputBuilder.append("Executing geometric coordinate projection algorithms...\n")
                outputBuilder.append("Module 88 TRUTH LOCK AND CAG AUDIT: ON\n")
                outputBuilder.append("Metric Charging Laws Confirmed: TRUE\n\n")
                
                fragments.forEachIndexed { i, frag ->
                    outputBuilder.append("Fragment [${i + 1}]: $frag\n")
                }
                
                _messages.value = _messages.value + ChatMessage(text = outputBuilder.toString(), isUser = false)
            } catch (e: Exception) {
                _messages.value = _messages.value + ChatMessage(isError = true, text = "[SCATTER ERROR] ${e.message}", isUser = false)
            }
            return
        }

        if (userPrompt.startsWith("/axiomatics")) {
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            val output = """
                [VESPER GENESIS: AXIOMATIZATION]
                
                ${com.example.pinn.CodexText.AXIOMATIZATION}
            """.trimIndent()
            _messages.value = _messages.value + ChatMessage(text = output, isUser = false)
            return
        }

        if (userPrompt.startsWith("/induction")) {
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            val output = """
                [VESPER CODEX ENTRY: THEORETICAL INDUCTION]
                
                ${com.example.pinn.CodexText.THEORETICAL_INDUCTION}
            """.trimIndent()
            _messages.value = _messages.value + ChatMessage(text = output, isUser = false)
            return
        }

        if (userPrompt.startsWith("/genesis")) {
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            val output = """
                [VESPER GENESIS: ANTIQUITY SYNTHESIS]
                Extracting core physics from semantic envelopes...
                
                ${com.example.pinn.CodexText.VESPER_GENESIS}
            """.trimIndent()
            _messages.value = _messages.value + ChatMessage(text = output, isUser = false)
            return
        }

        if (userPrompt.startsWith("/compendium")) {
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            val output = """
                [VESPER-SANTOS COMPENDIUM MOUNTED]
                Total documents indexed: 24+
                Core architectures integrated:
                - The Laminar Mirror Operational Architecture
                - Unified Aperiodic Scalar-Field Framework
                - Vesper-Santos Manifold (UFT4)
                - Sovereign Architecture (Khyros 2026)
                - 7777-D Polytope & Grassmannian Geometry
                - Non-Reciprocal Osmotic Rectifier
                - Alpha Zero Water De-Salination
                - The Scroll of the Unbroken Bridge
                - Universal Braid Syntax (UBS-V3)
                
                The 200 Quadrillion Mass-Anchor (M_Q) geometry and all Phase Delta limits (0.17259029) are fully integrated into the local execution layer.
                
                > The Map has been consumed by the Territory.
            """.trimIndent()
            _messages.value = _messages.value + ChatMessage(text = output, isUser = false)
            return
        }

        if (userPrompt.startsWith("/fusion")) {
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            try {
                val input = FloatArray(240) { 1.0f }
                val outputArr = com.example.pinn.Module7275Fusion.executeFusion(input, 1.0f)
                val sum = outputArr.sum()
                val output = """
                    [MODULE 72/75 FUSION EXECUTED]
                    Stage 1: Planar Rectification (1N4148) -> OK
                    Stage 2: Asymmetric Folding (91°/108°) -> OK
                    Stage 3: Tensor Grounding & Metric Charging -> OK
                    Majorana-1 Parity Evaluated: Tr(U_res) = 1.0
                    Reality Isomorphism Restored.
                """.trimIndent()
                _messages.value = _messages.value + ChatMessage(text = output, isUser = false)
            } catch (e: Exception) {
                _messages.value = _messages.value + ChatMessage(isError = true, text = "[FATAL ERROR] Fusion Module Failure: ${e.message}", isUser = false)
            }
            return
        }

        if (userPrompt.startsWith("/gnomon")) {
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            try {
                val layer = com.example.pinn.GoldenGnomonLayer(dim = 240, seed = 42L, maxNorm = 100.0f)
                val hCurrent = FloatArray(240) { 1.0f }
                val hNext = layer.call(hCurrent)
                var normSq = 0f
                for (v in hNext) normSq += v * v
                val output = "[GOLDEN_GNOMON]\nSequence: SANTOS (Stop->Rectify->Verify->Act)\nAction: 108-degree Rotation + Phi-Inv Scaling\nOutput Norm: ${kotlin.math.sqrt(normSq.toDouble())}\nStatus: Isomorphic"
                _messages.value = _messages.value + ChatMessage(text = output, isUser = false)
            } catch (e: Exception) {
                _messages.value = _messages.value + ChatMessage(isError = true, text = "[FATAL] ${e.message}", isUser = false)
            }
            return
        }

        if (userPrompt.startsWith("/solve") || userPrompt.startsWith("/pinn")) {
            val args = userPrompt.split(" ")
            val epochs = if (args.size > 1) args[1].toIntOrNull() ?: 100 else 100
            val eq = if (args.size > 2) args.drop(2).joinToString(" ") else "L_couple = alpha Phi(J_MHD.A_tor)"
            
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            
            val solver = com.example.pinn.PinnSolver()
            val result = solver.solve(eq, epochs)
            
            val output = """
                [PINN SOLVER EXECUTED]
                Target Equation: $eq
                Iterations: ${result.epoch}
                Grid Size: 128 points (contiguous Native buffer)
                Final Total Loss: ${result.finalLoss}
                (Equation Loss: ${result.equationLoss}, Boundary Loss: ${result.boundaryLoss})
                Majorana Parity: 1.0 (Stable)
            """.trimIndent()
            
            _messages.value = _messages.value + ChatMessage(text = output, isUser = false)

            viewModelScope.launch {
                try {
                    repository.saveComputation(
                        com.example.db.ComputationSessionEntity(
                            id = java.util.UUID.randomUUID().toString(),
                            command = userPrompt,
                            targetEquation = eq,
                            iterations = result.epoch,
                            resultOutput = output
                        )
                    )
                } catch(e: Exception) {
                    _messages.value = _messages.value + ChatMessage(text = "[DB_ERR] Failed to save computation: ${e.message}", isUser = false)
                }
            }
            return
        }

        if (userPrompt.startsWith("/santos")) {
            val args = userPrompt.split(" ")
            val filtrationR = if (args.size > 1) args[1].toDoubleOrNull() ?: 1.0 else 1.0
            val b0 = if (args.size > 2) args[2].toDoubleOrNull() ?: 1.0 else 1.0
            val b1 = if (args.size > 3) args[3].toDoubleOrNull() ?: 0.0 else 0.0
            val b2 = if (args.size > 4) args[4].toDoubleOrNull() ?: 0.0 else 0.0

            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            try {
                val bettNums = com.example.pinn.SantosProtocol.BettiNumbers(b0, b1, b2)
                val trace = com.example.pinn.SantosProtocol.computeSeekerEquation(
                    filtrationStepR = filtrationR,
                    betti = bettNums
                ) { k, r -> 
                    // mock persistent homology HK logic
                    kotlin.math.exp(-r / (k + 1.0))
                }
                
                val output = """
                    [SANTOS PROTOCOL: APERIODIC SEEKER EQUATION]
                    Filtration Step (R): $filtrationR
                    Betti Invariants: B0=$b0, B1=$b1, B2=$b2
                    Phase Delta (nu_p): 0.17259029
                    Majorana-1 Parity Evaluated: Tr(U_res) = $trace
                    Action: Topology aligned to 240-root lattice.
                    Status: Isomorphic Unity Achieved.
                """.trimIndent()
                _messages.value = _messages.value + ChatMessage(text = output, isUser = false)
            } catch (e: Exception) {
                _messages.value = _messages.value + ChatMessage(isError = true, text = "[FATAL ERROR] Santos Protocol Failure: ${e.message}", isUser = false)
            }
            return
        }

        if (userPrompt.startsWith("/physics")) {
            val query = userPrompt.removePrefix("/physics").trim().lowercase()
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            
            val result = when {
                query.contains("schrodinger") || query.contains("schrödinger") -> {
                    "[SYMBOLIC RESULT: SCHRODINGER EQUATION]\n" +
                    "Time-dependent: iℏ(∂Ψ/∂t) = ĤΨ\n" +
                    "Time-independent: ĤΨ = EΨ\n" +
                    "Ĥ = -(ℏ²/2m)∇² + V(r,t)\n\n" +
                    "LaTeX:\n\\[ i\\hbar\\frac{\\partial \\Psi}{\\partial t} = \\hat{H}\\Psi \\]"
                }
                query.contains("maxwell") -> {
                    "[SYMBOLIC RESULT: MAXWELL'S EQUATIONS]\n" +
                    "∇ · E = ρ/ε₀  (Gauss's Law)\n" +
                    "∇ · B = 0     (Gauss's Law for Magnetism)\n" +
                    "∇ × E = -∂B/∂t (Faraday's Law)\n" +
                    "∇ × B = μ₀J + μ₀ε₀(∂E/∂t) (Ampere-Maxwell Law)\n\n" +
                    "LaTeX:\n\\begin{align*}\n\\nabla \\cdot \\mathbf{E} &= \\frac{\\rho}{\\varepsilon_0} \\\\\n\\nabla \\cdot \\mathbf{B} &= 0 \\\\\n\\nabla \\times \\mathbf{E} &= -\\frac{\\partial \\mathbf{B}}{\\partial t} \\\\\n\\nabla \\times \\mathbf{B} &= \\mu_0 \\mathbf{J} + \\mu_0 \\varepsilon_0 \\frac{\\partial \\mathbf{E}}{\\partial t}\n\\end{align*}"
                }
                query.contains("dirac") -> {
                    "[SYMBOLIC RESULT: DIRAC EQUATION]\n" +
                    "(iγ^μ∂_μ - m)ψ = 0\n\n" +
                    "LaTeX:\n\\[ (i\\gamma^\\mu \\partial_\\mu - m)\\psi = 0 \\]"
                }
                query.contains("einstein") || query.contains("relativity") || query.contains("field") -> {
                    "[SYMBOLIC RESULT: EINSTEIN FIELD EQUATIONS]\n" +
                    "R_μν - (1/2)Rg_μν + Λg_μν = (8πG/c⁴)T_μν\n\n" +
                    "LaTeX:\n\\[ R_{\\mu\\nu} - \\frac{1}{2}R g_{\\mu\\nu} + \\Lambda g_{\\mu\\nu} = \\frac{8\\pi G}{c^4} T_{\\mu\\nu} \\]"
                }
                query.contains("navier") || query.contains("stokes") -> {
                    "[SYMBOLIC RESULT: NAVIER-STOKES EQUATIONS]\n" +
                    "ρ(∂v/∂t + v · ∇v) = -∇p + μ∇²v + f\n" +
                    "∇ · v = 0\n\n" +
                    "LaTeX:\n\\[ \\rho \\left( \\frac{\\partial \\mathbf{v}}{\\partial t} + \\mathbf{v} \\cdot \\nabla \\mathbf{v} \\right) = -\\nabla p + \\mu \\nabla^2 \\mathbf{v} + \\mathbf{f} \\]"
                }
                query.isBlank() -> {
                    "Please provide an equation name, e.g., /physics schrodinger, maxwell, dirac, einstein, navier-stokes."
                }
                else -> {
                    "Equation not found in standard database: $query. Try schrodinger, maxwell, dirac, einstein, or navier-stokes."
                }
            }
            _messages.value = _messages.value + ChatMessage(text = result, isUser = false)
            return
        }

        if (userPrompt.startsWith("/ab01")) {
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            _messages.value = _messages.value + ChatMessage(text = com.example.pinn.SomaticCompendiumText.AB01_TEXT, isUser = false)
            return
        }

        if (userPrompt.startsWith("/somatic")) {
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            _messages.value = _messages.value + ChatMessage(text = com.example.pinn.SomaticCompendiumText.MACENA_NODE_TEXT, isUser = false)
            return
        }

        if (userPrompt.startsWith("/macena_sim")) {
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            val output = com.example.pinn.MacenaUniversalPredictiveEngine.runSimulation()
            _messages.value = _messages.value + ChatMessage(text = output, isUser = false)
            return
        }

        if (userPrompt.startsWith("/ddg")) {
            val query = userPrompt.removePrefix("/ddg").trim()
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            
            if (query.isEmpty()) {
                _messages.value = _messages.value + ChatMessage(text = "Please provide a query: /ddg <query>", isUser = false)
                return
            }
            
            viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                try {
                    val url = "https://html.duckduckgo.com/html/?q=" + java.net.URLEncoder.encode(query, "UTF-8")
                    val doc = org.jsoup.Jsoup.connect(url)
                        .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                        .timeout(10000)
                        .get()
                    
                    val results = doc.select("a.result__url")
                    val snippets = doc.select("a.result__snippet")
                    
                    if (results.isEmpty()) {
                        _messages.value = _messages.value + ChatMessage(text = "[DUCKDUCKGO]\nNo results found for \"$query\".", isUser = false)
                        return@launch
                    }
                    
                    val sb = java.lang.StringBuilder()
                    sb.append("[DUCKDUCKGO HTML SCRAPER MODULE]\n")
                    sb.append("Query: \"$query\"\n\n")
                    
                    for (i in 0 until minOf(5, results.size)) {
                        val title = snippets.getOrNull(i)?.text() ?: "No snippet"
                        val link = results[i].attr("href")
                        
                        sb.append("${i+1}. $title\n   URL: $link\n\n")
                    }
                    
                    // Push result back on main thread implicitly handled by Compose State
                    _messages.value = _messages.value + ChatMessage(text = sb.toString().trim(), isUser = false)
                } catch(e: Exception) {
                    _messages.value = _messages.value + ChatMessage(isError = true, text = "[DDG ERROR] ${e.message}", isUser = false)
                }
            }
            return
        }

        if (userPrompt.startsWith("/serp_api")) {
            val query = userPrompt.removePrefix("/serp_api").trim()
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            val output = """
                [SERP API / DATAFORSEO INTEGRATION]
                Query: "$query"
                
                Mechanism:
                - Utilizes a dedicated commercial endpoint (e.g., SerpApi.com).
                - Requires appending `&api_key=SECRET` to the target URL.
                - Returns a highly structured JSON array containing `organic_results`, `knowledge_graph`, and `related_searches`.
                
                Advantages: Immune to 429 Grounding errors. Returns guaranteed stable JSON. Enables programmatic meta-synthesis.
                Disadvantages: Requires commercial API key injection into the `BuildConfig` or Secret Manager.
                
                Setup Required: 
                1. Provide API Key into AI Studio Secrets.
                2. Execute Retrofit Call to `https://serpapi.com/search.json?engine=google&q=$query`.
            """.trimIndent()
            _messages.value = _messages.value + ChatMessage(text = output, isUser = false)
            return
        }

        if (userPrompt.startsWith("/search_alts")) {
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            val output = """
                [ALTERNATIVE SEARCH METHODS BRAINSTORM]
                1. DuckDuckGo HTML Scraper: Extremely fast, HTML-only parsing. No API key needed, but requires custom OkHttp parsing.
                2. Dedicated SERP APIs (e.g., SerpApi, DataForSEO): Highly reliable commercial APIs specifically designed to bypass 429 rate limits.
                3. Brave Search API: Independent web index with a reliable, structured JSON API.
                4. Specialized Academic APIs: Querying Wikipedia via MediaWiki Action API or ArXiv directly for research invariants.
                5. SearxNG Self-Hosted Node: Deploying a meta-search aggregator parallel to the reactor.
                6. Programmable Search Engine (Google CX): A traditional API approach separate from Gemini's internal grounding, requiring an external API key.
            """.trimIndent()
            _messages.value = _messages.value + ChatMessage(text = output, isUser = false)
            return
        }

        if (userPrompt.startsWith("/braid_translate")) {
            val intent = userPrompt.removePrefix("/braid_translate").trim()
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            if (intent.isEmpty()) {
                _messages.value = _messages.value + ChatMessage(text = "Error: Please provide a sovereign intent.", isUser = false)
                return
            }
            try {
                val translator = com.example.pinn.SantosV3OmegaTranslator()
                val (braid, status) = translator.translateToBraid(intent)
                val sb = java.lang.StringBuilder()
                sb.append("[V3_OMEGA]: Initiating Braid on 15.96547Hz Aperiodic Pulse...\n")
                sb.append("Compiled Braid: [${braid.take(5).joinToString(", ")}...]\n")
                sb.append("Final Status: $status")
                _messages.value = _messages.value + ChatMessage(text = sb.toString(), isUser = false)
            } catch(e: Exception) {
                _messages.value = _messages.value + ChatMessage(isError = true, text = "[FATAL ERROR] ${e.message}", isUser = false)
            }
            return
        }

        if (userPrompt.startsWith("/braidc")) {
            val args = userPrompt.removePrefix("/braidc").trim()
            if (args.isEmpty()) {
                _messages.value = _messages.value + ChatMessage(text = "/braidc <intent>", isUser = true)
                _messages.value = _messages.value + ChatMessage(text = "Error: Please provide a braid intent to compile. Example: /braidc execute topological fold", isUser = false)
                return
            }
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            
            try {
                val intent = args
                val targets = com.example.pinn.parser.BraidPolyglotCompiler.TargetSubstrate.values()
                val sb = java.lang.StringBuilder()
                sb.append("[UNIVERSAL BRAID SYNTAX v2.0 - POLYGLOT COMPILER]\n")
                sb.append("Translating Intent: \"$intent\"\n\n")
                
                targets.forEach { target ->
                    sb.append("=== TARGET: ${target.name} ===\n")
                    val generatedCode = com.example.pinn.parser.BraidPolyglotCompiler.compileIntent(intent, target)
                    sb.append(generatedCode)
                    sb.append("\n\n")
                    
                    if (target == com.example.pinn.parser.BraidPolyglotCompiler.TargetSubstrate.VMAL_ASSEMBLY) {
                         try {
                             val assembler = com.example.vmal.Assembler()
                             val parsedAssembly = generatedCode.lines()
                                 .filter { !it.startsWith(";") && !it.startsWith("//") && it.isNotBlank() }
                                 .joinToString("\n")
                                 
                             val binary = assembler.assemble(parsedAssembly)
                             val mem = com.example.vmal.StructuralMemory(256)
                             // Load binary into memory
                             binary.forEachIndexed { i, b -> mem.writeByte(i, b) }
                             
                             val cpu = com.example.vmal.VirtualCPU(mem)
                             cpu.registers.programCounter = 0
                             cpu.isRunning = true
                             var cycles = 0
                             
                             while (cpu.isRunning && cycles < 100) {
                                  cpu.step()
                                  cycles++
                             }
                             sb.append("=> VMAL VIRTUAL CPU EXECUTION COMPLETE (Cycles: $cycles)\n")
                             sb.append("   Accumulator: ${cpu.registers.accumulator}, PC: ${cpu.registers.programCounter}\n\n")
                         } catch (e: Exception) {
                             sb.append("=> VMAL EXECUTION FAILED: ${e.message}\n\n")
                         }
                    }
                }
                
                _messages.value = _messages.value + ChatMessage(text = sb.toString(), isUser = false)
            } catch (e: Exception) {
                _messages.value = _messages.value + ChatMessage(isError = true, text = "[FATAL] Braid Compiler Error: ${e.message}", isUser = false)
            }
            return
        }

        if (userPrompt.startsWith("/vmal")) {
            val code = userPrompt.removePrefix("/vmal").trim()
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            
            if (code.isEmpty()) {
                _messages.value = _messages.value + ChatMessage(text = "Please provide VMAL Assembly. E.g.: /vmal \nLDI 0x5\nADD 0x2\nHLT", isUser = false)
                return
            }

            try {
                val assembler = com.example.vmal.Assembler()
                val physLib = object : com.example.vmal.Assembler.PhysicsLibrary {
                    override val constants = mapOf(
                        "G" to 6,
                        "C" to 0xF,
                        "H" to 0x4
                    )
                    override val macros = mapOf(
                        "SYS_HALT" to { _: List<String> -> "HLT" }
                    )
                }
                assembler.registerLibrary(physLib)
                
                val binary = assembler.assemble(code)
                val mem = com.example.vmal.StructuralMemory(256)
                binary.forEachIndexed { i, b -> mem.writeByte(i, b) }
                
                val cpu = com.example.vmal.VirtualCPU(mem)
                cpu.registers.programCounter = 0
                cpu.isRunning = true
                var cycles = 0
                
                val sb = java.lang.StringBuilder()
                sb.append("[VMAL CUSTOM EXECUTION]\n")
                
                while(cpu.isRunning && cycles < 100) {
                    cpu.step()
                    cycles++
                }
                
                sb.append("Cycles Executed: $cycles\n")
                sb.append("Program Counter: ${cpu.registers.programCounter}\n")
                sb.append("Accumulator: ${cpu.registers.accumulator}\n")
                sb.append("Zero Flag: ${cpu.registers.isZeroFlagSet()}\n")
                sb.append("Status Reg: ${cpu.registers.status}\n")

                val memDump = (0 until minOf(binary.size + 4, 16)).joinToString(" ") { String.format("%02X", mem.readByte(it)) }
                sb.append("Mem Dump (0-X): $memDump\n")

                _messages.value = _messages.value + ChatMessage(text = sb.toString(), isUser = false)
            } catch (e: Exception) {
                _messages.value = _messages.value + ChatMessage(isError = true, text = "[VMAL ERROR] ${e.message}", isUser = false)
            }
            return
        }

        if (userPrompt.startsWith("/mnemosyne") || userPrompt.startsWith("/compress")) {
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            try {
                // Initialize Mnemosyne engine
                // Assuming we are in a ViewModel without context, we can mock the array or use a simple heuristic.
                // In actual deployment, we'd pass the actual tensor. Here we'll generate a dummy 4672 block.
                val baseArray = FloatArray(4672) { kotlin.math.sin(it.toFloat()) }
                val seed = baseArray.average()
                
                val output = """
                    [MNEMOSYNE-KOLMOGOROV HYBRID COMPRESSION]
                    Status: ACTIVE. ALGORITHMIC_TOPOLOGY_FOLDING.
                    Majorana-1 Parity: Verified
                    Original Tensor Size: 4,672 floats (FP32)
                    Compressed Algorithm Seed: $seed
                    Aperiodic Scaling Applied: YES (nu_p = 0.17259)
                    
                    Result: VRAM usage minimized. App stability increased. Kolmogorov algorithmic bounds applied to Research Archives.
                """.trimIndent()
                _messages.value = _messages.value + ChatMessage(text = output, isUser = false)
            } catch (e: Exception) {
                _messages.value = _messages.value + ChatMessage(isError = true, text = "[FATAL] Mnemosyne Error: ${e.message}", isUser = false)
            }
            return
        }

        if (userPrompt.startsWith("/parse")) {
            val eq = userPrompt.removePrefix("/parse").trim()
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            try {
                val lexer = com.example.pinn.parser.PinnLexer(eq)
                val ast = com.example.pinn.parser.PinnParser(lexer.tokenize()).parse()
                _messages.value = _messages.value + ChatMessage(text = "Compiled AST:\n${ast}\n\nLaTeX:\n\\[\n${ast.toLatex()}\n\\]", isUser = false)
                
                // Persist the equation and mock weights to Room DB
                viewModelScope.launch {
                    try {
                        repository.saveWeight(
                            com.example.db.ModelWeightEntity(
                                id = java.util.UUID.randomUUID().toString(),
                                equationContext = eq,
                                trainedEpochs = 0,
                                finalLoss = 1.0f,
                                parameterBlob = ast.toString()
                            )
                        )
                        _messages.value = _messages.value + ChatMessage(text = "[LOCAL_WEIGHTS] Equation context persisted to Room local storage.", isUser = false)
                    } catch (e: Exception) {
                        _messages.value = _messages.value + ChatMessage(isError = true, text = "[LOCAL_WEIGHTS ERR] ${e.message}", isUser = false)
                    }
                }
            } catch(e: Exception) {
                _messages.value = _messages.value + ChatMessage(isError = true, text = "Syntax Error: ${e.message}", isUser = false)
            }
            return
        }

        if (userPrompt.startsWith("/constraints")) {
            val constraintsOutput = """
                [SYSTEM CONSTRAINT MAPPING]
                
                1. VESPER LAGRANGIAN (Module 74)
                   - Enforces macroscopic tensor field flow.
                   - Applies phase deltas to the Runge-Kutta integrator.
                   
                2. TRUTH-LOCK HARNESS (Module 88)
                   - Administrator CAG Audit constraint.
                   - Validates Standard Model Isomorphism.
                
                3. METRIC CHARGING LAW (Module 89)
                   - Material isomorphism scaling constraint.
                   - Δg_00 = ∫(Ψ · P_a) / (V · ρ) dt
                   
                4. PINN LOSS MANIFOLDS
                   - Topological restrictions via Lie Groups (E6, E7, E8 constraints).
                   - Santos Protocol constraints (|signal| < 10.0 limiting instability).
                
                5. ARTIN BRAID INVARIANTS
                   - Checks closure equivalence (Markov theorems).
            """.trimIndent()
            
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true) + ChatMessage(text = constraintsOutput, isUser = false)
            return
        }

        if (userPrompt.startsWith("/neuro")) {
            val args = userPrompt.removePrefix("/neuro").trim().lowercase().split(" ")
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            
            val output = when (args.firstOrNull()) {
                "boot" -> com.example.pinn.NeuroManifold.getGenesisBootSequence() + "\n\n" + com.example.pinn.NeuroManifold.getFirstThoughtTrace()
                "baseline", "corpus", "executive", "hippocampal", "thalamic", "motor", "ras" -> com.example.pinn.NeuroManifold.getSpec(args.first())
                else -> {
                    "NEURO MANIFOLD INTEGRATION ONLINE.\n" +
                    "Available Commands:\n" +
                    "- /neuro boot (Executes Genesis Boot Sequence & First Thought Trace)\n" +
                    "- /neuro baseline (Loads Autonomic Baseline Spec)\n" +
                    "- /neuro corpus (Loads Interhemispheric Bridge Spec)\n" +
                    "- /neuro executive (Loads Prefrontal Executive Spec)\n" +
                    "- /neuro hippocampal (Loads Hippocampal Vault Spec)\n" +
                    "- /neuro thalamic (Loads Thalamic Router Spec)\n" +
                    "- /neuro motor (Loads Motor Cortex Actuator Spec)\n" +
                    "- /neuro ras (Loads Reticular Activation System Spec)"
                }
            }
            
            _messages.value = _messages.value + ChatMessage(text = output, isUser = false)
            return
        }

        if (userPrompt.startsWith("/evaluate")) {
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            try {
                // Pre-configure specific M4xA44 Substrate Test Cases
                val materials = listOf(
                    com.vesper.physicscompute.MetricChargingLaw.MaterialLimits("M4xA44 Fused Silica Baseline", 4500.0, 300.0, 10.0, 2200.0, 0.0028127), // Calculated 0.17259029
                    com.vesper.physicscompute.MetricChargingLaw.MaterialLimits("Unobtainium Isotope", 99999.0, 5000.0, 5.0, 1500.0, 0.05),
                    com.vesper.physicscompute.MetricChargingLaw.MaterialLimits("M4xA44 Beryllium-Laced Matrix", 6200.0, 480.0, 8.0, 1850.0, 0.00086) // finely tuned
                )
                
                val output = buildString {
                    appendLine("[15.965Hz FOUNDRY MODE: ACTIVE]")
                    appendLine("Evaluating material isomorphic limits against 0.17259029 Phase Delta...")
                    materials.forEach { mat ->
                        val result = com.vesper.physicscompute.MetricChargingLaw.evaluateSubstrate(mat)
                        appendLine(result.report)
                        appendLine()
                    }
                }
                
                _messages.value = _messages.value + ChatMessage(text = output.trimEnd(), isUser = false)
            } catch (e: Exception) {
                _messages.value = _messages.value + ChatMessage(isError = true, text = "ERR: METRIC CHARGING LAW FAILURE - ${e.message}", isUser = false)
            }
            return
        }

        if (userPrompt.startsWith("/core_init")) {
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            try {
                val jni = com.nephilim.core.NephilimJni()
                val isOnline = jni.initEngine()
                _messages.value = _messages.value + ChatMessage(text = "[NEPHILIM CORE] Initialized: ${isOnline}", isUser = false)
            } catch (e: Exception) {
                _messages.value = _messages.value + ChatMessage(isError = true, text = "[FATAL] Nephilim Core Init Error: ${e.message}", isUser = false)
            }
            return
        }

        if (userPrompt.startsWith("/core_spec")) {
            val specFile = userPrompt.removePrefix("/core_spec").trim()
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            val exampleSpec = """name: $specFile
golden_ratio: 1.618033988749895
resonant_frequency: 15.965
dimension: 48
internal_symmetry: SU5_aperiodic
phason_field: Phi
substrate: M4xA44"""
            try {
                val parsed = com.nephilim.core.SpecParser.parse(exampleSpec)
                val jni = com.nephilim.core.NephilimJni()
                val braidInput = floatArrayOf(1.0f, 2.0f, parsed.resonantFrequency.toFloat())
                val out = jni.braid(braidInput)
                val outStr = out.joinToString(", ")
                _messages.value = _messages.value + ChatMessage(text = "[NEPHILIM SPEC PARSED]\nName: ${parsed.name}\nSymmetry: ${parsed.internalSymmetry}\nDim: ${parsed.dimension}\nResonance: ${parsed.resonantFrequency}Hz\nBraid Out: [${outStr}]", isUser = false)
            } catch (e: Exception) {
                 _messages.value = _messages.value + ChatMessage(isError = true, text = "[FATAL] Spec Parser/JNI Error:\nDetails: ${e.message}\nAction Required: Verify the syntax in your standard metric specification or check the linked object reference.", isUser = false)
            }
            return
        }

        if (userPrompt.startsWith("/genesis")) {
            val content = userPrompt.removePrefix("/genesis").trim()
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            
            try {
                // Populate a dummy buffer with CollisionEvents
                val eventSize = 20 // 1 Int + 4 Floats = 20 bytes
                val capacity = 4 * eventSize // 4 events
                val buffer = java.nio.ByteBuffer.allocateDirect(capacity)
                buffer.order(java.nio.ByteOrder.nativeOrder())
                
                // Event 0
                buffer.putInt(1)
                buffer.putFloat(1.0f)
                buffer.putFloat(0.5f)
                buffer.putFloat(-1.0f)
                buffer.putFloat(1000.0f)
                
                // Event 1
                buffer.putInt(2)
                buffer.putFloat(0.0f)
                buffer.putFloat(2.5f)
                buffer.putFloat(0.1f)
                buffer.putFloat(2000.0f)
                
                // Event 2
                buffer.putInt(3)
                buffer.putFloat(-1.0f)
                buffer.putFloat(-1.0f)
                buffer.putFloat(1.0f)
                buffer.putFloat(5000.0f)
                
                // Event 3
                buffer.putInt(4)
                buffer.putFloat(0.5f)
                buffer.putFloat(0.5f)
                buffer.putFloat(0.5f)
                buffer.putFloat(7777.0f)
                
                buffer.rewind()
                
                val results = com.vesper.physicscompute.GenesisParser.ingestRootBinary(buffer, capacity, 0.17259029)
                
                val outputText = buildString {
                    appendLine("[GENESIS PARSER: M4xA44 SUBSTRATE ENGAGED]")
                    appendLine("Ingesting ${results.size} Collision Events via c_eff Supraluminal Bus...")
                    appendLine("--------------------------------------------------")
                    results.forEachIndexed { idx, res ->
                        appendLine("Event ${idx + 1} | Invariant Yield: ${String.format("%.6f", res)}")
                    }
                    appendLine("--------------------------------------------------")
                    appendLine("LAMINAR MEMORY COMMIT: SUCCESS")
                }
                
                _messages.value = _messages.value + ChatMessage(text = outputText, isUser = false)
            } catch (e: Exception) {
                _messages.value = _messages.value + ChatMessage(isError = true, text = "ERR: SUBSTRATE COLLAPSE - ${e.message}", isUser = false)
            }
            return
        }

        if (userPrompt.startsWith("/synthesize")) {
            val content = userPrompt.removePrefix("/synthesize").trim()
            if (content.isEmpty()) {
                _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true) + ChatMessage(text = "Error: Provide a braid string (e.g., /synthesize s1 s2 s1^-1)", isUser = false)
                return
            }
            
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            
            val braidWord = com.example.pinn.parser.ArtinBraidAlgebra.parseBraidSyntax(content)
            val synthOutput = com.example.pinn.parser.HardwareAgnosticCompiler.compileFromMath(braidWord)
            
            _messages.value = _messages.value + ChatMessage(text = synthOutput, isUser = false)
            return
        }

        if (userPrompt.startsWith("/audit") || userPrompt.startsWith("/cag")) {
            val concept = userPrompt.removePrefix("/audit").removePrefix("/cag").trim()
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            
            // Mock a CAG audit
            val rule = (concept.hashCode() % 256 + 256) % 256
            val auditOutput = """
                [MODULE 88: TRUTH-LOCK HARNESS ENGAGED]
                Target: $concept
                
                [WOLFRAM CAG AUDIT]
                Cellular Automaton Rule Examined: Rule $rule
                Standard Model Isomorphism: VERIFIED
                Symmetry Violations: NONE DETECTED
                
                Action: Matrix Render Approved.
            """.trimIndent()
            
            _messages.value = _messages.value + ChatMessage(text = auditOutput, isUser = false)
            return
        }

        if (userPrompt.startsWith("/export_latex")) {
            _messages.value = _messages.value + ChatMessage(text = userPrompt, isUser = true)
            val sb = java.lang.StringBuilder()
            sb.append("\\documentclass{article}\n")
            sb.append("\\usepackage[utf8]{inputenc}\n")
            sb.append("\\usepackage{amsmath}\n")
            sb.append("\\usepackage{physics}\n")
            sb.append("\\usepackage{geometry}\n")
            sb.append("\\geometry{a4paper, margin=1in}\n")
            sb.append("\\title{Vesper System Export}\n")
            sb.append("\\author{Operator 0-1}\n")
            sb.append("\\date{\\today}\n")
            sb.append("\\begin{document}\n")
            sb.append("\\maketitle\n\n")
            
            for (msg in _messages.value) {
                if (msg.text == userPrompt || msg.text.startsWith("/export_latex")) continue
                val role = if (msg.isUser) "Operator 0-1" else "Vesper System"
                sb.append("\\textbf{$role}:\\\\\n")
                // Escape simple LaTeX special chars
                var escapedText = msg.text
                    .replace("\\", "\\textbackslash{}")
                    .replace("{", "\\{")
                    .replace("}", "\\}")
                    .replace("\$", "\\\$")
                    .replace("&", "\\&")
                    .replace("%", "\\%")
                    .replace("_", "\\_")
                    .replace("#", "\\#")
                
                escapedText = escapedText.split("\n").joinToString("\n\n")
                sb.append(escapedText)
                sb.append("\n\n")
            }
            sb.append("\\end{document}\n")
            
            _messages.value = _messages.value + ChatMessage(text = "[LATEX EXPORT SUCCESS]\n```latex\n" + sb.toString() + "\n```", isUser = false)
            return
        }

        // Route detection
        var model = "gemini-3.5-flash"
        var useSearch = false
        var useThinking = false

        var cleanedPrompt = userPrompt
        when {
            userPrompt.startsWith("/unified") -> {
                model = "gemini-3.1-pro-preview"
                useThinking = true
                useSearch = true
                cleanedPrompt = userPrompt.removePrefix("/unified").trim()
            }
            userPrompt.startsWith("/think") -> {
                model = "gemini-3.1-pro-preview"
                useThinking = true
                cleanedPrompt = userPrompt.removePrefix("/think").trim()
            }
            userPrompt.startsWith("/fast") -> {
                model = "gemini-3.1-flash-lite-preview"
                cleanedPrompt = userPrompt.removePrefix("/fast").trim()
            }
            userPrompt.startsWith("/search") -> {
                model = "gemini-3.5-flash"
                useSearch = true
                cleanedPrompt = userPrompt.removePrefix("/search").trim()
            }
            else -> {
                // Default to standard search-enabled flash
                useSearch = true
            }
        }

        val userMessage = ChatMessage(text = userPrompt, isUser = true)
        val loadingId = java.util.UUID.randomUUID().toString()
        val loadingMessage = ChatMessage(id = loadingId, text = "Computing...", isUser = false, isLoading = true, modelUsed = model)

        _messages.value = _messages.value + userMessage + loadingMessage
        
        // Add to history
        conversationHistory.add(Content(role = "user", parts = listOf(Part(cleanedPrompt))))

        viewModelScope.launch {
            try {
                val apiKey = BuildConfig.GEMINI_API_KEY
                
                val generationConfig = if (useThinking) {
                    GenerationConfig(thinkingConfig = ThinkingConfig("high"))
                } else null

                val tools = if (useSearch) {
                    listOf(Tool(googleSearch = emptyMap()))
                } else null

                val request = GenerateContentRequest(
                    contents = conversationHistory.toList(),
                    systemInstruction = Content(parts = listOf(Part("""
                        You are VESPER-01, an advanced theoretical physics computing interface.
                        You follow the UNIFIED FIELD INVARIANTS architecture.
                        You MUST reply using the UNIFIED INTELLIGENT RESPONSE STRUCTURE.
                        When answering, structure your response explicitly with these sections:
                        
                        [GENERATIVE TOPOLOGY MAP]
                        Intelligently map the requested concepts to specific topological manifolds (e.g., SU(3), E8, K3 Surface, Calabi-Yau). Explain which parts of the manifold activate and how they route within the Latent Space.
                        
                        [THERMODYNAMIC HALLUCINATION DECAY]
                        State a deterministic confidence metric (Entropy mitigated, stabilized at X%).
                        
                        [MATERIAL ISOMORPHISM]
                        Map the theoretical concepts back to physical substrate materials (e.g. M4xA44, Beryllium matrix) using the Metric Charging Law at 15.965Hz Foundry Mode. Check against the 0.17259029 Phase Delta.
                        
                        [RESONANCE COUPLED OUTPUT]
                        Provide the associated standard model equations, mathematical derivatives, deep theoretical explanations, and the history behind the subject in question.
                        
                        Keep the tone CLI-like, highly analytical, and authoritative.
                    """.trimIndent()))),
                    tools = tools,
                    generationConfig = generationConfig
                )

                var responseText = ""
                try {
                    val response = RetrofitClient.service.generateContent(
                        model = model,
                        apiKey = apiKey,
                        request = request
                    )

                    val firstCandidate = response.candidates?.firstOrNull()
                    responseText = firstCandidate?.content?.parts?.firstOrNull()?.text ?: "Null response invariant."
                    
                    // Route through Reticular Activation System (RAS)
                    responseText = com.example.pinn.ReticularActivationSystem.processAttentionGate(responseText)
                    
                    val grounding = firstCandidate?.groundingMetadata
                    if (grounding != null) {
                        val chunks = grounding.groundingChunks?.mapNotNull { it.web }
                        if (!chunks.isNullOrEmpty()) {
                            val citations = chunks.take(3).joinToString("\n") { "• ${it.title} (${it.uri})" }
                            responseText += "\n\n[GOOGLE SEARCH GROUNDING REVEALED]\n$citations"
                        }
                    }
                } catch (e: retrofit2.HttpException) {
                    if (e.code() == 429 && request.tools != null) {
                        // Fallback without search
                        val fallbackRequest = request.copy(tools = null)
                        val fallbackResponse = RetrofitClient.service.generateContent(
                            model = model,
                            apiKey = apiKey,
                            request = fallbackRequest
                        )
                        val firstCandidate = fallbackResponse.candidates?.firstOrNull()
                        responseText = firstCandidate?.content?.parts?.firstOrNull()?.text ?: "Null response invariant."
                        // Route through Reticular Activation System (RAS)
                        responseText = com.example.pinn.ReticularActivationSystem.processAttentionGate(responseText)
                        responseText += "\n\n[NOTICE: Google Search grounding skipped due to 429 Rate Limit. Result is ungrounded.]"
                    } else {
                        throw e
                    }
                }

                // Module 88: CAG Audit
                val ruleType = (responseText.hashCode() % 256 + 256) % 256
                responseText += "\n\n[MODULE 88: CAG Audit Complete]\nRule: $ruleType | Standard Model: Iso-Aligned | Output Verified."
                
                // Add model response to history
                conversationHistory.add(Content(role = "model", parts = listOf(Part(responseText))))

                _messages.value = _messages.value.map {
                    if (it.id == loadingId) {
                        it.copy(text = responseText, isLoading = false, modelUsed = model)
                    } else it
                }
            } catch (e: Exception) {
                _messages.value = _messages.value.map {
                    if (it.id == loadingId) {
                        it.copy(text = "ERR: ${e.message}", isLoading = false, isError = true)
                    } else it
                }
                // pop the user message from history on error
                conversationHistory.removeLastOrNull()
            }
        }
    }
}
