package com.example.vmal

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

/**
 * Structural Memory Buffer
 * Implements a fixed-size byte array to store computational states,
 * adhering to strict mathematical memory constraints.
 */
class StructuralMemory(val size: Int) {
    private val buffer = ByteArray(size)

    fun readByte(address: Int): Byte {
        require(address in 0 until size) { "Segment Fault: Accessing unallocated memory." }
        return buffer[address]
    }

    fun writeByte(address: Int, value: Byte) {
        require(address in 0 until size) { "Segment Fault: Accessing unallocated memory." }
        buffer[address] = value
    }

    // A computational state is just a snapshot of the buffer
    fun snapshotState(): ByteArray {
        return buffer.copyOf()
    }

    // Restore state from a saved snapshot
    fun restoreState(state: ByteArray) {
        require(state.size <= size) { "State size exceeds memory capacity." }
        state.copyInto(buffer)
    }
}

/**
 * Virtual Clock Oscillator
 * Drives the Virtual CPU using FOUNDRY_RESONANCE_HZ.
 */
class VirtualOscillator {
    private var time = 0L

    suspend fun tick(isRunning: () -> Boolean, cycleAction: suspend () -> Unit) {
        while (isRunning()) {
            cycleAction()
            time++
            // Approximate the FOUNDRY_RESONANCE_HZ constraints
            delay((1000f / FOUNDRY_RESONANCE_HZ).toLong())
        }
    }
}

/**
 * ALU (Arithmetic Logic Unit) Mapping
 * Isolates the logic mapping for virtual CPU execution.
 */
class VirtualALU {
    data class ALUResult(val result: Byte, val carry: Boolean = false, val overflow: Boolean = false)

    fun add(a: Byte, b: Byte): ALUResult {
        val sumInt = (a.toInt() and 0xFF) + (b.toInt() and 0xFF)
        val sumByte = sumInt.toByte()
        val carry = sumInt > 255
        val overflow = ((a.toInt() xor sumByte.toInt()) and (b.toInt() xor sumByte.toInt()) and 0x80) != 0
        return ALUResult(sumByte, carry, overflow)
    }

    fun sub(a: Byte, b: Byte): ALUResult {
        val diffInt = (a.toInt() and 0xFF) - (b.toInt() and 0xFF)
        val diffByte = diffInt.toByte()
        val carry = (a.toInt() and 0xFF) < (b.toInt() and 0xFF)
        val overflow = ((a.toInt() xor b.toInt()) and (a.toInt() xor diffByte.toInt()) and 0x80) != 0
        return ALUResult(diffByte, carry, overflow)
    }

    fun and(a: Byte, b: Byte): ALUResult = ALUResult((a.toInt() and b.toInt()).toByte())
    fun or(a: Byte, b: Byte): ALUResult = ALUResult((a.toInt() or b.toInt()).toByte())
    fun xor(a: Byte, b: Byte): ALUResult = ALUResult((a.toInt() xor b.toInt()).toByte())
    fun not(a: Byte): ALUResult = ALUResult((a.toInt().inv()).toByte())
}

class RegisterFile {
    var programCounter: Int = 0
    var accumulator: Byte = 0
    var status: Byte = 0 // Status Register (bit 0: Zero, bit 1: Negative, bit 2: Carry, bit 3: Overflow)

    fun isZeroFlagSet(): Boolean = (status.toInt() and 0x01) != 0

    fun updateFlags(result: Byte, carry: Boolean, overflow: Boolean) {
        var newStatus = 0
        if (result.toInt() == 0) newStatus = newStatus or 0x01
        if (result < 0) newStatus = newStatus or 0x02
        if (carry) newStatus = newStatus or 0x04
        if (overflow) newStatus = newStatus or 0x08
        status = newStatus.toByte()
    }
}

class InstructionDecoder(private val alu: VirtualALU, private val cpu: VirtualCPU) {
    // Basic Instruction Set Architecture (ISA) mapping
    fun decodeAndExecute(opcode: Int, operand: Byte) {
        var aluResult: VirtualALU.ALUResult? = null
        
        when (opcode) {
            0x0 -> { /* NOP (No Operation) */ }
            0x1 -> aluResult = alu.add(cpu.registers.accumulator, operand)
            0x2 -> aluResult = alu.sub(cpu.registers.accumulator, operand)
            0x3 -> aluResult = alu.and(cpu.registers.accumulator, operand)
            0x4 -> aluResult = alu.or(cpu.registers.accumulator, operand)
            0x5 -> aluResult = alu.xor(cpu.registers.accumulator, operand)
            0x6 -> aluResult = alu.not(cpu.registers.accumulator)
            0x7 -> { cpu.registers.accumulator = operand; aluResult = VirtualALU.ALUResult(operand) } // LOAD immediate
            0x8 -> cpu.memory.writeByte(operand.toInt(), cpu.registers.accumulator) // STORE to address
            0x9 -> { val loaded = cpu.memory.readByte(operand.toInt()); cpu.registers.accumulator = loaded; aluResult = VirtualALU.ALUResult(loaded) } // LOAD from address
            0xA -> cpu.registers.programCounter = operand.toInt() - 1 // JUMP (subtract 1 because it increments after)
            0xB -> if (cpu.registers.isZeroFlagSet()) cpu.registers.programCounter = operand.toInt() - 1 // JUMP_IF_ZERO
            0xF -> cpu.halt() // HALT
            else -> { /* Unknown Opcode or Reserved */ }
        }
        
        aluResult?.let { res ->
            if (opcode in 0x1..0x6) {
                cpu.registers.accumulator = res.result
            }
            // Update status flags for operations that modify accumulator
            cpu.registers.updateFlags(res.result, res.carry, res.overflow)
        }
    }
}

/**
 * Virtual CPU
 * Implements the virtual fetching cycle processing the Structural Memory.
 */
class VirtualCPU(val memory: StructuralMemory) {
    val registers = RegisterFile()
    private val alu = VirtualALU()
    private val decoder = InstructionDecoder(alu, this)
    private val oscillator = VirtualOscillator()

    var isRunning: Boolean = false
    
    private val _cpuState = MutableStateFlow(CPUState(registers.programCounter, registers.accumulator, registers.status))
    val cpuState: StateFlow<CPUState> = _cpuState.asStateFlow()

    data class CPUState(val pc: Int, val acc: Byte, val status: Byte)

    // Virtual Fetching Cycle
    suspend fun start() {
        registers.programCounter = 0
        isRunning = true
        oscillator.tick({ isRunning }) {
            fetchCycle()
        }
    }

    fun halt() {
        isRunning = false
    }

    fun step() {
        if (registers.programCounter >= memory.size || !isRunning) {
            isRunning = false
            return
        }

        // 1. Fetch
        val instruction = memory.readByte(registers.programCounter)
        
        // 2. Decode
        val opcode = (instruction.toInt() and 0xF0) shr 4
        val operand = (instruction.toInt() and 0x0F).toByte()

        // 3. Execute
        decoder.decodeAndExecute(opcode, operand)

        // Proceed to next instruction
        registers.programCounter++
        
        _cpuState.value = CPUState(registers.programCounter, registers.accumulator, registers.status)
    }

    private fun fetchCycle() {
        step()
    }
}
