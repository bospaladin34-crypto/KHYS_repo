package com.example.vmal

import kotlin.math.pow

/**
 * Core Physics Calculation Engine
 * Integrates theoretical physics formulas, providing high-fidelity computational
 * integrity for the Virtual Mathematical Abstraction Layer (VMAL).
 */
object PhysicsEngine {
    
    /**
     * Calculates the Lagrangian (L = T - V)
     * T = Kinetic Energy
     * V = Potential Energy
     */
    fun calculateLagrangian(kineticEnergy: Float, potentialEnergy: Float): Float {
        return kineticEnergy - potentialEnergy
    }
    
    /**
     * Calculates the Hamiltonian (H = T + V)
     * Represents the total energy of the system.
     */
    fun calculateHamiltonian(kineticEnergy: Float, potentialEnergy: Float): Float {
        return kineticEnergy + potentialEnergy
    }

    /**
     * Integrates the Action (S = ∫ L dt) over a time step dt.
     */
    fun integrateAction(lagrangian: Float, dt: Float): Float {
        return lagrangian * dt
    }
    
    /**
     * Computes kinetic energy (T = 1/2 m v^2)
     */
    fun computeKineticEnergy(mass: Float, velocity: Float): Float {
        return 0.5f * mass * velocity.pow(2)
    }

    /**
     * Applies a Lagrangian integration step to a TensorState.
     * Uses Action to define waveFunctionPsi and Hamiltonian to define appliedPower.
     */
    fun <T> applyLagrangianStep(
        tensorState: TensorState<T>,
        velocity: Float,
        potentialEnergy: Float,
        dt: Float,
        transformation: (T) -> T
    ) {
        val kineticEnergy = computeKineticEnergy(tensorState.mass, velocity)
        val lagrangian = calculateLagrangian(kineticEnergy, potentialEnergy)
        val action = integrateAction(lagrangian, dt)
        
        // Map theoretical values back to the Metric Charging Law requirements
        val waveFunctionPsi = action * VESPER_PHASE_DELTA
        val appliedPower = calculateHamiltonian(kineticEnergy, potentialEnergy)
        
        tensorState.applyTransformation(
            waveFunctionPsi = waveFunctionPsi,
            appliedPower = appliedPower,
            dt = dt,
            transformation = transformation
        )
    }
}

/**
 * DSL extension to apply Lagrangian mechanics within a manifold block or directly on a TensorState.
 */
fun <T> TensorState<T>.evolveLagrangian(
    velocity: () -> Float,
    potentialEnergy: () -> Float,
    dt: Float,
    transformation: (T) -> T
) {
    PhysicsEngine.applyLagrangianStep(
        tensorState = this,
        velocity = velocity(),
        potentialEnergy = potentialEnergy(),
        dt = dt,
        transformation = transformation
    )
}
