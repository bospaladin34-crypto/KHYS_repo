package com.example.vmal

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.withFrameMillis
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

/**
 * Advanced State Renderer for visualizing TensorStates and ensuring adherence to the
 * Module 89 thermodynamic bounds (Metric Charging Law).
 */
@Composable
fun <T> TensorStateRenderer(
    tensorState: TensorState<T>,
    modifier: Modifier = Modifier,
    label: String = "TENSOR STATE"
) {
    val stateValue by tensorState.state.collectAsState()
    
    // 15.965Hz Foundry Mode Engine Time-Domain
    var timeDomain by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(Unit) {
        var lastFrameTime = 0L
        while(true) {
            withFrameMillis { frameTime ->
                if (lastFrameTime == 0L) lastFrameTime = frameTime
                val dt = (frameTime - lastFrameTime) / 1000f
                lastFrameTime = frameTime
                timeDomain += dt
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF0F1A24)) // Deep background
            .border(1.dp, Color(0xFF00FFCC).copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                color = Color(0xFF00FFCC),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Δg_00 ACTIVE",
                    color = Color.Yellow,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    modifier = Modifier
                        .background(Color.Yellow.copy(alpha = 0.1f))
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                )
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Thermodynamic Live Stats
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            ThermodynamicStat("VALUE", stateValue.toString())
            ThermodynamicStat("COHERENCE", String.format("%.3f", tensorState.coherence))
            ThermodynamicStat("ENTROPY", String.format("%.3f", tensorState.entropy))
        }
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            ThermodynamicStat("MASS", String.format("%.2f", tensorState.mass))
            ThermodynamicStat("VOLUME", String.format("%.2f", tensorState.volume))
            ThermodynamicStat("DENSITY", String.format("%.2f", tensorState.density))
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Visual Topology Renderer
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color.Black.copy(alpha = 0.5f))
                .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val (width, height) = size
                val center = Offset(width / 2f, height / 2f)
                
                // Draw a phase wave representing the state
                val path = Path()
                val waveAmplitude = 30f * tensorState.coherence
                
                path.moveTo(0f, center.y)
                var x = 0f
                while (x < width) {
                    // Combine state value and time domain with entropy modulation
                    val frequency = VESPER_PHASE_DELTA * 10f + (tensorState.entropy * 0.1f)
                    val y = center.y + sin((x * 0.05f) + (timeDomain * frequency)) * waveAmplitude
                    path.lineTo(x, y)
                    x += 5f
                }
                
                // Render wave
                drawPath(
                    path = path,
                    color = Color(0xFF00FFCC).copy(alpha = tensorState.coherence),
                    style = Stroke(width = 2f)
                )
                
                // Draw coherence boundary
                drawRect(
                    color = if (tensorState.coherence < 0.3f) Color.Red.copy(alpha = 0.2f) else Color.Transparent,
                    size = size
                )
            }
        }
    }
}

@Composable
private fun ThermodynamicStat(label: String, value: String) {
    Column {
        Text(
            text = label,
            color = Color.White.copy(alpha = 0.5f),
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp
        )
        Text(
            text = value,
            color = Color.White,
            fontFamily = FontFamily.Monospace,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
