package com.example.vmal.security

/**
 * MODULE 88 & 89 COMPLIANT: Amplituhedron CLI Parser
 *
 * A command-line interface parser that allows passing custom geometry parameters
 * directly into the Amplituhedron scattering engine.
 */
class AmplituhedronCLIParser {

    /**
     * Parses a CLI-style string configuration to override parameters and execute scattering.
     * Example input: "scatter --payload [data] --particles 12 --helicity 6 --spacetime 4"
     */
    fun parseAndExecute(commandString: String, powerState: Float): List<String> {
        val args = commandString.split("\\s+".toRegex())

        // Amplituhedron defaults
        var particlesN = 8
        var helicityK = 4
        var spaceTimeM = 4

        // Payload default
        var targetPayload = "NULL_PAYLOAD"

        var i = 0
        while (i < args.size) {
            when (args[i].lowercase()) {
                "--particles", "-n" -> {
                    if (i + 1 < args.size) {
                        particlesN = args[i + 1].toIntOrNull() ?: particlesN
                        i++
                    }
                }
                "--helicity", "-k" -> {
                    if (i + 1 < args.size) {
                        helicityK = args[i + 1].toIntOrNull() ?: helicityK
                        i++
                    }
                }
                "--spacetime", "-m" -> {
                    if (i + 1 < args.size) {
                        spaceTimeM = args[i + 1].toIntOrNull() ?: spaceTimeM
                        i++
                    }
                }
                "--payload", "-p" -> {
                    if (i + 1 < args.size) {
                        targetPayload = args[i + 1]
                        i++
                    }
                }
            }
            i++
        }

        val engine = AmplituhedronScatterEngine(
            particlesN = particlesN,
            helicityK = helicityK,
            spaceTimeM = spaceTimeM
        )

        return engine.scatterPayload(
            basePayloadSignature = targetPayload,
            externalPower = powerState
        )
    }
}
