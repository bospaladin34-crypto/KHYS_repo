package com.example.vmal

/**
 * Text-to-binary assembler for the VirtualCPU.
 * Converts assembly-like instructions into the binary format understood by the instruction decoder.
 */
class Assembler {
    
    interface PhysicsLibrary {
        val constants: Map<String, Int>
        val macros: Map<String, (List<String>) -> String>
    }

    private val libraries = mutableListOf<PhysicsLibrary>()
    private val constantMap = mutableMapOf<String, Int>()

    fun registerLibrary(library: PhysicsLibrary) {
        libraries.add(library)
        constantMap.putAll(library.constants)
    }

    companion object {
        // Pre-defined assembly macros for common physics calculations
        val MACROS = mapOf(
            // Vector addition (2D). Assumes operands are addresses.
            // Usage: VEC_ADD2D result_addr v1_addr v2_addr
            "VEC_ADD2D" to { args: List<String> ->
                val res = args[0].toInt()
                val v1 = args[1].toInt()
                val v2 = args[2].toInt()
                """
                LDA $v1
                ADD $v2
                STA $res
                LDA ${v1 + 1}
                ADD ${v2 + 1}
                STA ${res + 1}
                """.trimIndent()
            },
            // Kinematics step velocity: v_new = v_old + a (assuming dt=1 step)
            // Usage: KIN_VEL res_addr v_addr a_addr
            "KIN_VEL" to { args: List<String> ->
                val res = args[0].toInt()
                val v = args[1].toInt()
                val a = args[2].toInt()
                """
                LDA $v
                ADD $a
                STA $res
                """.trimIndent()
            },
            // Simple integration: pos_new = pos_old + velocity (assuming dt=1 step)
            // Usage: KIN_POS res_addr pos_addr v_addr
            "KIN_POS" to { args: List<String> ->
                val res = args[0].toInt()
                val pos = args[1].toInt()
                val v = args[2].toInt()
                """
                LDA $pos
                ADD $v
                STA $res
                """.trimIndent()
            }
        )
    }

    private fun expandMacros(sourceCode: String): String {
        val expandedCode = java.lang.StringBuilder()
        for (line in sourceCode.lines()) {
            val trimmedLine = line.substringBefore(";").trim().uppercase()
            if (trimmedLine.isEmpty()) continue

            val parts = trimmedLine.split("\\s+".toRegex())
            val mnemonic = parts[0]

            var macroExpansion: String? = null
            
            // Check custom macros first
            for (lib in libraries) {
                if (lib.macros.containsKey(mnemonic)) {
                    try {
                        macroExpansion = lib.macros[mnemonic]!!(parts.drop(1))
                    } catch (e: Exception) {
                        throw IllegalArgumentException("Error expanding macro $mnemonic: ${e.message}")
                    }
                    break
                }
            }
            
            if (macroExpansion == null && MACROS.containsKey(mnemonic)) {
                try {
                    macroExpansion = MACROS[mnemonic]!!(parts.drop(1))
                } catch (e: Exception) {
                    throw IllegalArgumentException("Error expanding macro $mnemonic: ${e.message}")
                }
            }

            if (macroExpansion != null) {
                expandedCode.appendLine(macroExpansion)
            } else {
                expandedCode.appendLine(trimmedLine)
            }
        }
        return expandedCode.toString()
    }

    fun assemble(sourceCode: String): ByteArray {
        val expandedSource = expandMacros(sourceCode)
        val lines = expandedSource.lines()
        val binary = mutableListOf<Byte>()

        for ((index, line) in lines.withIndex()) {
            // Strip comments and convert to uppercase
            val trimmedLine = line.substringBefore(";").trim().uppercase()
            if (trimmedLine.isEmpty()) continue

            val parts = trimmedLine.split("\\s+".toRegex())
            val mnemonic = parts[0]
            
            val operandStr = if (parts.size > 1) parts[1] else "0"
            val operand = try {
                if (constantMap.containsKey(operandStr)) {
                    constantMap[operandStr]!!
                } else if (operandStr.startsWith("0X")) {
                    operandStr.substring(2).toInt(16)
                } else {
                    operandStr.toInt()
                }
            } catch (e: NumberFormatException) {
                throw IllegalArgumentException("Invalid operand format at line ${index + 1}: $operandStr")
            }

            val opcode = when (mnemonic) {
                "NOP" -> 0x0
                "ADD" -> 0x1
                "SUB" -> 0x2
                "AND" -> 0x3
                "OR"  -> 0x4
                "XOR" -> 0x5
                "NOT" -> 0x6
                "LDI" -> 0x7
                "STA" -> 0x8
                "LDA" -> 0x9
                "JMP" -> 0xA
                "JZ"  -> 0xB
                "HLT" -> 0xF
                else -> throw IllegalArgumentException("Unknown mnemonic at line ${index + 1}: $mnemonic")
            }

            // Combine opcode (upper 4 bits) and operand (lower 4 bits)
            val instruction = ((opcode shl 4) or (operand and 0x0F)).toByte()
            binary.add(instruction)
        }

        return binary.toByteArray()
    }
}
