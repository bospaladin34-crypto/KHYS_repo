package com.nephilim.core

class NephilimJni {
    init {
        try {
            System.loadLibrary("physicscompute")
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    external fun initEngine(): Boolean
    external fun braid(inData: FloatArray): FloatArray
}
