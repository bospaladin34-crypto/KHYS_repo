package com.nephilim.core

data class NephilimSpec(
    val name: String = "Unknown",
    val goldenRatio: Double = 1.618033988749895,
    val resonantFrequency: Double = 15.965,
    val dimension: Int = 48,
    val internalSymmetry: String = "SU5_aperiodic",
    val phasonField: String = "Phi",
    val substrate: String = "M4xA44",
    val nuP: Double? = null,
    val tensors: Int? = null,
    val ness: Boolean = true
)

object SpecParser {
    fun parse(content: String): NephilimSpec {
        var name = "Unknown"
        var goldenRatio = 1.618033988749895
        var resonantFrequency = 15.965
        var dimension = 48
        var internalSymmetry = "SU5_aperiodic"
        var phasonField = "Phi"
        var substrate = "M4xA44"
        var nuP: Double? = null
        var tensors: Int? = null
        var ness = true

        content.lines().forEach { line ->
            val trimmed = line.trim()
            if (trimmed.startsWith("name:")) {
                name = trimmed.removePrefix("name:").trim()
            } else if (trimmed.startsWith("golden_ratio:")) {
                goldenRatio = trimmed.removePrefix("golden_ratio:").trim().toDoubleOrNull() ?: goldenRatio
            } else if (trimmed.startsWith("resonant_frequency:")) {
                resonantFrequency = trimmed.removePrefix("resonant_frequency:").trim().toDoubleOrNull() ?: resonantFrequency
            } else if (trimmed.startsWith("dimension:")) {
                dimension = trimmed.removePrefix("dimension:").trim().toIntOrNull() ?: dimension
            } else if (trimmed.startsWith("internal_symmetry:")) {
                internalSymmetry = trimmed.removePrefix("internal_symmetry:").trim()
            } else if (trimmed.startsWith("phason_field:")) {
                phasonField = trimmed.removePrefix("phason_field:").trim()
            } else if (trimmed.startsWith("substrate:")) {
                substrate = trimmed.removePrefix("substrate:").trim()
            } else if (trimmed.startsWith("nu_p:")) {
                nuP = trimmed.removePrefix("nu_p:").trim().toDoubleOrNull()
            } else if (trimmed.startsWith("tensors:")) {
                tensors = trimmed.removePrefix("tensors:").trim().toIntOrNull()
            } else if (trimmed.startsWith("ness:")) {
                ness = trimmed.removePrefix("ness:").trim().toBooleanStrictOrNull() ?: true
            }
        }

        return NephilimSpec(
            name = name,
            goldenRatio = goldenRatio,
            resonantFrequency = resonantFrequency,
            dimension = dimension,
            internalSymmetry = internalSymmetry,
            phasonField = phasonField,
            substrate = substrate,
            nuP = nuP,
            tensors = tensors,
            ness = ness
        )
    }
}
