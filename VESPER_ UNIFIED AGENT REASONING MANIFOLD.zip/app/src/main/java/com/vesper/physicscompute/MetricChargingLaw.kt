package com.vesper.physicscompute

import kotlin.math.abs

/**
 * Metric Charging Law Evaluator (Module 89)
 * Calculates material viability using: Δg_00 = ∫(Ψ · P_a) / (V · ρ) dt
 */
object MetricChargingLaw {
    private const val REQUIRED_PHASE_DELTA = 0.17259029
    private const val FOUNDRY_FREQ_HZ = 15.965

    data class MaterialLimits(
        val name: String,
        val energyDensity: Double, // Ψ
        val thermalLimit: Double,  // P_a
        val volume: Double,        // V
        val massDensity: Double,   // ρ
        val dt: Double             // time scalar
    )

    data class EvaluationResult(
        val name: String,
        val deltaG00: Double,
        val isViable: Boolean,
        val report: String
    )

    fun evaluateSubstrate(material: MaterialLimits): EvaluationResult {
        // Compute the metric charging law integral (simplified linear summation for discrete dt)
        val termNumerator = material.energyDensity * material.thermalLimit
        val termDenominator = material.volume * material.massDensity
        
        // Δg_00 = (Ψ · P_a) / (V · ρ) * dt
        val deltaG00 = (termNumerator / termDenominator) * material.dt
        
        // Ensure the evaluated material can sustain the 0.17259029 Phase Delta
        // We do this by checking if the intrinsic structural resonance allows the phase delta
        // For the M4xA44, the required threshold mapping binds deltaG00 near the Required Phase Delta.
        val phaseDegradation = abs(deltaG00 - REQUIRED_PHASE_DELTA)
        
        // Let's say if the difference is within a certain tolerance, it's viable,
        // otherwise it suffers thermodynamic degradation.
        val tolerance = 0.05
        val isViable = phaseDegradation <= tolerance
        
        val status = if (isViable) "VIABLE" else "UNOBTAINABLE [Thermodynamic Degradation]"
        
        val report = """
            |--- MATERIAL EVALUATION: ${material.name} ---
            |Parameters:
            |  Energy Density (Ψ): ${material.energyDensity}
            |  Thermal Limit (P_a): ${material.thermalLimit}
            |  Substrate Volume (V): ${material.volume}
            |  Mass Density (ρ): ${material.massDensity}
            |  Time Bound (dt): ${material.dt}
            |
            |Computation:
            |  Δg_00 = ∫(Ψ · P_a) / (V · ρ) dt
            |  Calculated Δg_00 = %.8f
            |
            |Target Phase Delta: $REQUIRED_PHASE_DELTA
            |Phase Degradation Slip: %.8f
            |Status: $status
        """.trimMargin().format(deltaG00, phaseDegradation)
        
        return EvaluationResult(material.name, deltaG00, isViable, report)
    }
}
