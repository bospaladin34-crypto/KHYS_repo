package com.vesper.physicscompute

import java.nio.ByteBuffer

object GenesisParser {
    init {
        // Load the M4xA44 Substrate
        System.loadLibrary("physicscompute")
    }

    /**
     * @param buffer The direct-allocated ByteBuffer containing raw event data.
     * @param capacity Total byte size of the buffer.
     * @param phaseDelta Mapped to \nu_p = 0.17259029.
     */
    external fun ingestRootBinary(buffer: ByteBuffer, capacity: Int, phaseDelta: Double): FloatArray
}
