import { ComputeShard, ComputeResult } from './physics';
import { processComputeShard } from './engine';

/**
 * Message schema for the Worker incoming messages.
 */
export interface WorkerInputMessage {
    type: 'COMPUTE_SHARD';
    payload: ComputeShard;
}

/**
 * Message schema for the Worker outgoing messages.
 */
export interface WorkerOutputMessage {
    type: 'COMPUTE_RESULT' | 'COMPUTE_ERROR';
    payload?: ComputeResult;
    error?: string;
}

// Web Worker context event listener. 
// Depending on Node environment vs Browser, this matches standard Web Worker API semantics.
self.onmessage = (event: MessageEvent<WorkerInputMessage>) => {
    const { type, payload } = event.data;

    if (type === 'COMPUTE_SHARD') {
        try {
            // Execute the intensive loop
            const result = processComputeShard(payload);
            
            // Send back the computed shard result
            const successMsg: WorkerOutputMessage = {
                type: 'COMPUTE_RESULT',
                payload: result
            };
            self.postMessage(successMsg);
        } catch (error) {
            // Forward errors to the main thread securely
            const errorMsg: WorkerOutputMessage = {
                type: 'COMPUTE_ERROR',
                error: error instanceof Error ? error.message : 'Unknown exception caught in shard worker.'
            };
            self.postMessage(errorMsg);
        }
    }
};
