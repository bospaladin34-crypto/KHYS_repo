export interface Vector3D {
    x: number;
    y: number;
    z: number;
}

/**
 * Represents the fundamental state of a particle or calculation node
 * in the network resonance engine.
 */
export interface ParticleState {
    id: string;
    position: Vector3D;
    velocity: Vector3D;
    mass: number;
    charge: number;
    /**
     * Vesper-specific quantum phase/resonance value used for synchronization.
     */
    quantumPhase: number; 
}

/**
 * High-performance field matrix.
 * Flattens the 3D space into a 1D Float32Array for better cache locality
 * and faster operations in V8/Node.js environments.
 */
export interface FieldMatrix {
    width: number;
    height: number;
    depth: number;
    resolution: number;
    /**
     * 1D array representing a flattened 3D grid. Keep as Float32Array
     * when manipulating in memory for compute performance.
     */
    tensorData: Float32Array | number[];
}

/**
 * Constants governing the simulation and engine constraints.
 */
export interface PhysicsConstants {
    gravity: number;
    coulombForce: number;
    planckBase: number;
    friction: number;
}

/**
 * Core configuration required to boot a simulation shard on a network node.
 */
export interface SimulationConfig {
    simulationId: string;
    timeStep: number;
    maxParticles: number;
    constants: PhysicsConstants;
    targetIterations: number;
}

/**
 * A shard of computational work that the Replit relay can distribute
 * to connected Android (Vesper) nodes.
 */
export interface ComputeShard {
    shardId: string;
    targetNodeHash: string;
    config: SimulationConfig;
    particles: ParticleState[];
    localField: FieldMatrix;
}

/**
 * Standardized result payload returned from a node after processing a ComputeShard.
 */
export interface ComputeResult {
    shardId: string;
    computingNodeHash: string;
    particles: ParticleState[];
    computeTimeMs: number;
    energyConsumed: number;
}
