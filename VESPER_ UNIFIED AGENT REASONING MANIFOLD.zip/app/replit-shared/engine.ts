import { ComputeShard, ComputeResult, ParticleState } from './physics';
import { ParticlePool } from './object-pool';
import { validateSimulationConfig, validateParticleState } from './schema-validator';

// Object pool instantiated per-worker/engine instance
const particlePool = new ParticlePool(100000);

/**
 * Processes a computational shard by running the physics simulation for 
 * the target number of iterations over the provided particles.
 */
export function processComputeShard(shard: ComputeShard): ComputeResult {
    const startTime = performance.now();
    
    // Safety check constraints before heavy lifting
    validateSimulationConfig(shard.config);
    
    const { timeStep, targetIterations, constants } = shard.config;
    let currentParticles = shard.particles;

    for (let iter = 0; iter < targetIterations; iter++) {
        const nextParticles: ParticleState[] = [];
        
        for (let i = 0; i < currentParticles.length; i++) {
            const p1 = currentParticles[i];
            validateParticleState(p1);
            
            // Acquire fresh state from pool 
            const nextP = particlePool.acquire();
            nextP.id = p1.id;
            nextP.mass = p1.mass;
            nextP.charge = p1.charge;
            nextP.quantumPhase = p1.quantumPhase;
            
            let forceX = 0;
            let forceY = 0;
            let forceZ = 0;
            
            // N-body gravity/coulomb interactions
            for (let j = 0; j < currentParticles.length; j++) {
                if (i === j) continue;
                
                const p2 = currentParticles[j];
                const dx = p2.position.x - p1.position.x;
                const dy = p2.position.y - p1.position.y;
                const dz = p2.position.z - p1.position.z;
                
                const distSq = dx * dx + dy * dy + dz * dz;
                // Prevent singularities manually
                if (distSq < 0.000001) continue;
                
                const dist = Math.sqrt(distSq);
                
                // Gravity calculation
                const fGrav = (constants.gravity * p1.mass * p2.mass) / distSq;
                // Coulomb electrostatics
                const fCoulomb = (constants.coulombForce * p1.charge * p2.charge) / distSq;
                
                const fTotal = fGrav - fCoulomb;
                
                forceX += (dx / dist) * fTotal;
                forceY += (dy / dist) * fTotal;
                forceZ += (dz / dist) * fTotal;
            }
            
            // F = ma -> a = F/m
            const ax = forceX / p1.mass;
            const ay = forceY / p1.mass;
            const az = forceZ / p1.mass;
            
            // Apply friction & compute new velocities
            const frictionMult = 1.0 - constants.friction;
            nextP.velocity.x = (p1.velocity.x + ax * timeStep) * frictionMult;
            nextP.velocity.y = (p1.velocity.y + ay * timeStep) * frictionMult;
            nextP.velocity.z = (p1.velocity.z + az * timeStep) * frictionMult;
            
            // Update positions based on new velocities
            nextP.position.x = p1.position.x + nextP.velocity.x * timeStep;
            nextP.position.y = p1.position.y + nextP.velocity.y * timeStep;
            nextP.position.z = p1.position.z + nextP.velocity.z * timeStep;
            
            nextParticles.push(nextP);
        }
        
        // Return previous iteration's objects to the pool to prevent GC spikes,
        // unless it's the very first iteration (which is the input array)
        if (iter > 0) {
            particlePool.releaseBulk(currentParticles);
        }
        
        currentParticles = nextParticles;
    }
    
    const computeTimeMs = performance.now() - startTime;
    
    // Abstract energy heuristic based on iterations and particle count
    const energyConsumed = (currentParticles.length * targetIterations) * constants.planckBase;
    
    return {
        shardId: shard.shardId,
        computingNodeHash: shard.targetNodeHash,
        particles: currentParticles,
        computeTimeMs,
        energyConsumed
    };
}
