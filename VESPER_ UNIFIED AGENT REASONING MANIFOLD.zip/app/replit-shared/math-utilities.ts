import { Vector3D, FieldMatrix } from './physics';

/**
 * Calculates the magnitude (length) of a 3D vector.
 */
export function vectorMagnitude(v: Vector3D): number {
    return Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
}

/**
 * Normalizes a 3D vector to a length of 1.
 * If the magnitude is 0, it returns a zero vector.
 */
export function normalizeVector(v: Vector3D): Vector3D {
    const mag = vectorMagnitude(v);
    if (mag === 0) return { x: 0, y: 0, z: 0 };
    return {
        x: v.x / mag,
        y: v.y / mag,
        z: v.z / mag
    };
}

/**
 * Adds two 3D vectors together.
 */
export function addVectors(v1: Vector3D, v2: Vector3D): Vector3D {
    return {
        x: v1.x + v2.x,
        y: v1.y + v2.y,
        z: v1.z + v2.z
    };
}

/**
 * Subtracts the second vector from the first.
 */
export function subtractVectors(v1: Vector3D, v2: Vector3D): Vector3D {
    return {
        x: v1.x - v2.x,
        y: v1.y - v2.y,
        z: v1.z - v2.z
    };
}

/**
 * Multiplies a vector by a scalar.
 */
export function scaleVector(v: Vector3D, scalar: number): Vector3D {
    return {
        x: v.x * scalar,
        y: v.y * scalar,
        z: v.z * scalar
    };
}

/**
 * Computes the dot product of two vectors.
 */
export function dotProduct(v1: Vector3D, v2: Vector3D): number {
    return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z;
}

/**
 * Computes the cross product of two 3D vectors.
 */
export function crossProduct(v1: Vector3D, v2: Vector3D): Vector3D {
    return {
        x: v1.y * v2.z - v1.z * v2.y,
        y: v1.z * v2.x - v1.x * v2.z,
        z: v1.x * v2.y - v1.y * v2.x
    };
}

/**
 * Calculates the distance squared between two vectors.
 * Useful for fast physics calculations where actual distance isn't needed.
 */
export function distanceSquared(v1: Vector3D, v2: Vector3D): number {
    const dx = v1.x - v2.x;
    const dy = v1.y - v2.y;
    const dz = v1.z - v2.z;
    return dx * dx + dy * dy + dz * dz;
}

/**
 * Maps 3D coordinates (x, y, z) to a 1D index for the FieldMatrix tensorData.
 */
export function getFieldIndex(field: FieldMatrix, x: number, y: number, z: number): number {
    return x + field.width * (y + field.height * z);
}

/**
 * Applies a mathematical operation (addition, scaling, etc.) to a FieldMatrix.
 * Optimized for cache locality utilizing the 1D Float32Array representation.
 */
export function scaleScalarField(field: FieldMatrix, scalar: number): void {
    const data = field.tensorData;
    for (let i = 0; i < data.length; i++) {
        data[i] *= scalar;
    }
}

/**
 * Adds the values of two FieldMatrices. 
 * Both matrices must have the exact same dimensions.
 */
export function addScalarFields(field1: FieldMatrix, field2: FieldMatrix): void {
    if (field1.tensorData.length !== field2.tensorData.length) {
        throw new Error("FieldMatrix dimension mismatch for addition.");
    }
    const data1 = field1.tensorData;
    const data2 = field2.tensorData;
    for (let i = 0; i < data1.length; i++) {
        data1[i] += data2[i];
    }
}
