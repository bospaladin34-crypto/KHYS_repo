import { ParticleState } from './physics';

/**
 * A high-performance object pool for ParticleState instances to minimize 
 * garbage collection overhead during intensive simulation iterations.
 */
export class ParticlePool {
    private pool: ParticleState[];
    private initialCapacity: number;

    constructor(initialCapacity: number = 10000) {
        this.initialCapacity = initialCapacity;
        this.pool = new Array<ParticleState>(initialCapacity);
        this.initializePool();
    }

    /**
     * Pre-allocates ParticleState objects to fill the initial capacity.
     */
    private initializePool(): void {
        for (let i = 0; i < this.initialCapacity; i++) {
            this.pool[i] = this.createNewParticle();
        }
    }

    /**
     * Creates a new instance of ParticleState with zeroed/safe default values.
     */
    private createNewParticle(): ParticleState {
        return {
            id: '',
            position: { x: 0, y: 0, z: 0 },
            velocity: { x: 0, y: 0, z: 0 },
            mass: 1, // Defaulting to 1 to prevent division by zero gracefully
            charge: 0,
            quantumPhase: 0
        };
    }

    /**
     * Acquires a ParticleState object from the pool.
     * If the pool is empty, it dynamically allocates a new one to prevent blocking,
     * but this indicates the capacity should ideally be increased.
     */
    public acquire(): ParticleState {
        const particle = this.pool.pop();
        if (particle !== undefined) {
            return particle;
        }
        // Fallback allocation if pool is exhausted
        return this.createNewParticle();
    }

    /**
     * Releases a ParticleState object back into the pool for future reuse.
     * Resets its state to prevent stale data leaking between compute frames.
     */
    public release(particle: ParticleState): void {
        this.resetParticle(particle);
        this.pool.push(particle);
    }

    /**
     * Releases an array of ParticleState objects back into the pool efficiently.
     */
    public releaseBulk(particles: ParticleState[]): void {
        for (let i = 0; i < particles.length; i++) {
            this.release(particles[i]);
        }
        // Optional: clear the originating array if we want to ensure no references remain
        particles.length = 0;
    }

    /**
     * Resets a particle to a "clean" resting state.
     */
    private resetParticle(particle: ParticleState): void {
        particle.id = '';
        particle.position.x = 0;
        particle.position.y = 0;
        particle.position.z = 0;
        particle.velocity.x = 0;
        particle.velocity.y = 0;
        particle.velocity.z = 0;
        particle.mass = 1;
        particle.charge = 0;
        particle.quantumPhase = 0;
    }

    /**
     * Returns the current number of available objects in the pool.
     */
    public get availableCount(): number {
        return this.pool.length;
    }
    
    /**
     * Extends the pool manually if the network needs to scale up the shard load dynamically.
     */
    public expand(amount: number): void {
        for (let i = 0; i < amount; i++) {
            this.pool.push(this.createNewParticle());
        }
    }
}
