import { SimulationConfig, ParticleState, FieldMatrix, PhysicsConstants } from './physics';

export class ValidationError extends Error {
    constructor(message: string) {
        super(message);
        this.name = 'ValidationError';
    }
}

/**
 * Validates a SimulationConfig object to ensure all parameters fall within physically valid bounds.
 */
export function validateSimulationConfig(config: SimulationConfig): void {
    if (!config.simulationId || config.simulationId.trim() === '') {
        throw new ValidationError("SimulationConfig must have a valid simulationId.");
    }
    
    if (config.timeStep <= 0 || config.timeStep > 1) {
        throw new ValidationError(`Invalid timeStep: ${config.timeStep}. It must be between 0 (exclusive) and 1 (inclusive).`);
    }
    
    if (config.maxParticles <= 0 || config.maxParticles > 1000000) {
        throw new ValidationError(`Invalid maxParticles: ${config.maxParticles}. Must be between 1 and 1,000,000.`);
    }

    if (config.targetIterations <= 0) {
        throw new ValidationError(`Invalid targetIterations: ${config.targetIterations}. Must be greater than 0.`);
    }

    validatePhysicsConstants(config.constants);
}

/**
 * Validates PhysicsConstants for physically meaningful ranges within the engine.
 */
export function validatePhysicsConstants(constants: PhysicsConstants): void {
    if (constants.gravity < 0) {
        throw new ValidationError(`Invalid gravity: ${constants.gravity}. Must be non-negative.`);
    }
    
    if (constants.coulombForce < 0) {
        throw new ValidationError(`Invalid coulombForce: ${constants.coulombForce}. Must be non-negative.`);
    }

    if (constants.planckBase <= 0) {
        throw new ValidationError(`Invalid planckBase: ${constants.planckBase}. Must be strictly positive.`);
    }

    if (constants.friction < 0 || constants.friction > 1) {
        throw new ValidationError(`Invalid friction: ${constants.friction}. Must be between 0 and 1.`);
    }
}

/**
 * Validates a ParticleState to ensure coordinates, mass, and velocity are within acceptable engine limits.
 */
export function validateParticleState(particle: ParticleState): void {
    if (!particle.id || particle.id.trim() === '') {
        throw new ValidationError("ParticleState must have a valid id.");
    }

    if (particle.mass <= 0) {
        throw new ValidationError(`Invalid mass for particle ${particle.id}: ${particle.mass}. Must be strictly positive.`);
    }

    // Engine's conceptual speed limit (scaled appropriately for local nodes)
    const maxVelocity = 300000000; 
    if (
        Math.abs(particle.velocity.x) > maxVelocity ||
        Math.abs(particle.velocity.y) > maxVelocity ||
        Math.abs(particle.velocity.z) > maxVelocity
    ) {
        throw new ValidationError(`Velocity components for particle ${particle.id} exceed the maximum engine speed.`);
    }

    // Phase constraint check based on the Metric Charging Law parameters
    if (Math.abs(particle.quantumPhase) > Math.PI * 2) {
        throw new ValidationError(`Quantum phase for particle ${particle.id} should be within standard 2-Pi bounds.`);
    }
}

/**
 * Validates a FieldMatrix for dimensional consistency.
 */
export function validateFieldMatrix(field: FieldMatrix): void {
    if (field.width <= 0 || field.height <= 0 || field.depth <= 0) {
        throw new ValidationError("FieldMatrix dimensions must be strictly positive.");
    }

    if (field.resolution <= 0) {
        throw new ValidationError("FieldMatrix resolution must be greater than 0.");
    }

    const expectedLength = field.width * field.height * field.depth;
    if (field.tensorData.length !== expectedLength) {
        throw new ValidationError(`FieldMatrix tensorData length mismatch. Expected ${expectedLength}, got ${field.tensorData.length}.`);
    }
}
