const fs = require('fs');
let content = fs.readFileSync('./app/src/main/java/com/example/ui/VesperDashboard.kt', 'utf8');
content = content.replace(/}\n}\n$/g, "}\n");
fs.writeFileSync('./app/src/main/java/com/example/ui/VesperDashboard.kt', content);
